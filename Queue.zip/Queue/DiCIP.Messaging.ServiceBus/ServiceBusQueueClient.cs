﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ServiceBus.Messaging;
using Microsoft.ServiceBus;
using System.IO;
using System.Transactions;
using System.Xml.Serialization;
using DiCIP.Common.Models.Message;
using DiCIP.Common.AppException;

namespace DiCIP.Messaging.ServiceBus
{
    public class ServiceBusQueueClient // : IQueueClient
    {
        private QueueClient _serviceBusClient;
        private bool _disposed;

        public ServiceBusQueueClient(QueueClient serviceBusClient)
        {
            _serviceBusClient = serviceBusClient;
        }

        #region The IQueueClient interface

        public ICIPMessage PeekMessage()
        {
            ICIPMessage message = null;
            try
            {
                if (_disposed)
                    throw new ObjectDisposedException(GetType().Name);

                using (BrokeredMessage received = _serviceBusClient.Peek())
                {
                    message =  ServiceBusManager.ConvertMessage(received);
                }

            }
            catch (Exception ex)
            {
                throw new DiCIPException(QueueErrorCode.QueueError," Error at PeekMessage method", ex);
            }
            return message;
        }

        public IEnumerable<ICIPMessage> PeekMessages(int maxCount = int.MaxValue)
        {
            foreach (BrokeredMessage msg in _serviceBusClient.PeekBatch(maxCount))
            {
                yield return ServiceBusManager.ConvertMessage(msg);
            }
        }

        public ICIPMessage ReceiveMessage(TimeSpan maxWaitingTime)
        {

            if (_disposed)
                throw new ObjectDisposedException(GetType().Name);
            try
            {
                using (BrokeredMessage received = _serviceBusClient.Receive(maxWaitingTime))
                {
                    return ServiceBusManager.ConvertMessage(received);
                }
            }
            catch (Exception ex)
            {
                throw new DiCIPException(QueueErrorCode.QueueError, " Error at ReceiveMessage method", ex);
            }
        }

        public IEnumerable<ICIPMessage> ReceiveMessages(int maxCount, TimeSpan maxWaitTime)
        {
            if (_disposed)
                throw new ObjectDisposedException(GetType().Name);
            List<ICIPMessage> messages = new List<ICIPMessage>();
            try
            {
                foreach (BrokeredMessage serviceBusMessage in _serviceBusClient.ReceiveBatch(maxCount, maxWaitTime))
                {
                    messages.Add(ServiceBusManager.ConvertMessage(serviceBusMessage));
                }
            }
            catch (Exception ex)
            {
                throw new DiCIPException(QueueErrorCode.QueueError, " Error at ReceiveMessages method", ex);
            }
            return messages;
        }

        public void AbandonMessage(ICIPMessage message)
        {
            if (message == null)
                return;
            if (_disposed)
                throw new ObjectDisposedException(GetType().Name);
            // ToDo : Add LockToken to CIPMSMQMessage
            //_serviceBusClient.Abandon(message.LockToken);
        }

        public void CompleteMessage(ICIPMessage message)
        {
            if (message == null)
                return;

            if (_disposed)
                throw new ObjectDisposedException(GetType().Name);
            // ToDo : Add GUID locktoken to CIPMSMQMessage
            //_serviceBusClient.Complete(message.LockToken);
        }

        public void CompleteMessages(IEnumerable<ICIPMessage> messages)
        {
            if (messages == null)
                return;
            try
            {
                foreach (var message in messages)
                {
                    CompleteMessage(message);
                }
            }
            catch (Exception ex)
            {
                throw new DiCIPException(QueueErrorCode.QueueError, " Error at CompleteMessages method", ex);
            }
        }


        public string SendMessage(ICIPMessage message, bool persist = true, int delayInSeconds = 0)
        {
            string messageId = null;
            if (message == null)
                return messageId;
            if (_disposed)
                throw new ObjectDisposedException(GetType().Name);
            try
            {
                // SB does not like local transactions, so act out side of existing transactions.:
                // Error message: "Local transactions are not supported with other resource managers/DTC."
                using (TransactionScope tr = new TransactionScope(TransactionScopeOption.Suppress))
                {
                    BrokeredMessage serviceBusMessage = ServiceBusManager.ConvertMessage(message);
                    messageId = serviceBusMessage.MessageId;
                    if (delayInSeconds > 0)
                    {
                        serviceBusMessage.ScheduledEnqueueTimeUtc = DateTime.UtcNow.AddSeconds(delayInSeconds);
                    }
                    _serviceBusClient.RetryPolicy = new RetryExponential(TimeSpan.FromSeconds(5), TimeSpan.FromSeconds(30), 10);

                    _serviceBusClient.Send(serviceBusMessage);
                    
                }
                return messageId;
            }
            catch (Exception ex)
            {
                throw new DiCIPException(QueueErrorCode.QueueError, " Error at SendMessage method", ex);
            }
            finally
            {
                if (_serviceBusClient != null)
                {
                    _serviceBusClient.Close();
                }
            }
        }

        public async Task SendMessageAsync(ICIPMessage message, bool persist = true, int delayInSeconds = 0)
        {
            if (message == null)
                return;
            if (_disposed)
                throw new ObjectDisposedException(GetType().Name);
            try
            {
               // SB does not like local transactions, so act out side of existing transactions.:
                // Error message: "Local transactions are not supported with other resource managers/DTC."
                BrokeredMessage serviceBusMessage = ServiceBusManager.ConvertMessage(message);
                if (delayInSeconds > 0)
                {
                    serviceBusMessage.ScheduledEnqueueTimeUtc = DateTime.UtcNow.AddSeconds(delayInSeconds);
                }
                _serviceBusClient.RetryPolicy = new RetryExponential(TimeSpan.FromSeconds(5), TimeSpan.FromSeconds(30), 10);
                await _serviceBusClient.SendAsync(serviceBusMessage);
            }
            catch (Exception ex)
            {
                throw new DiCIPException(QueueErrorCode.QueueError, " Error at SendMessageAsync method", ex);
            }
        }

        public void SendMessages(IEnumerable<ICIPMessage> messages, bool persist = true, int delayInSeconds = 0)
        {
            if (messages == null)
                return;
            if (_disposed)
                throw new ObjectDisposedException(GetType().Name);
            try
            {
                // SB does not like local transactions, so act out side of existing transactions.:
                // Error message: "Local transactions are not supported with other resource managers/DTC."
                using (TransactionScope tr = new TransactionScope(TransactionScopeOption.Suppress))
                {
                    IList<BrokeredMessage> serviceBusMessages = new List<BrokeredMessage>();
                    foreach (var message in messages)
                    {
                        BrokeredMessage serviceBusMessage = ServiceBusManager.ConvertMessage(message);
                        if (delayInSeconds > 0)
                        {
                            serviceBusMessage.ScheduledEnqueueTimeUtc = DateTime.UtcNow.AddSeconds(delayInSeconds);
                        }
                        serviceBusMessages.Add(serviceBusMessage);
                    }
                    _serviceBusClient.SendBatchSafe(serviceBusMessages);
                }
            }
            catch (Exception ex)
            {
                throw new DiCIPException(QueueErrorCode.QueueError, " Error at SendMessages method", ex);
            }
        }
        /*
        public async void SendMessagesAsync(IEnumerable<ICIPMessage> messages, bool persist = true, int delayInSeconds = 0)
        {
            if (messages == null)
                return;
            if (_disposed)
                throw new ObjectDisposedException(GetType().Name);
            try
            {
                // SB does not like local transactions, so act out side of existing transactions.:
                // Error message: "Local transactions are not supported with other resource managers/DTC."
                IList<BrokeredMessage> serviceBusMessages = new List<BrokeredMessage>();
                foreach (var message in messages)
                {
                    BrokeredMessage serviceBusMessage = ServiceBusManager.ConvertMessage(message);
                    if (delayInSeconds > 0)
                    {
                        serviceBusMessage.ScheduledEnqueueTimeUtc = DateTime.UtcNow.AddSeconds(delayInSeconds);
                    }
                    serviceBusMessages.Add(serviceBusMessage);
                }
                await _serviceBusClient.SendBatchAsync(serviceBusMessages);
            }
            catch (Exception ex)
            {
                throw new DiCIPException(QueueStatusCode.QueueError, " Error at SendMessages method", ex);
            }

        }
        */
        #endregion The IQueueClient interface

        #region The IDisposable interface

        public void Dispose()
        {
            if (!_serviceBusClient.IsClosed)
            {
                try
                {
                    _serviceBusClient.Close();  //or better CloseAsync ?
                }
                catch (Exception)
                {
                    _serviceBusClient.Abort();
                    throw;
                }
            }
            _disposed = true;
        }

        #endregion The IDisposable interface
    }
}
