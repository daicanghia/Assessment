﻿using DiCIP.Common.AppException;
using DiCIP.Common.Models.Message;
using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Text;
using System.Xml.Serialization;

namespace DiCIP.Messaging.ServiceBus
{
    public class ServiceBusManager //: IQueueProvider
    {
        public static readonly TimeSpan QUEUE_TIMEOUT = new TimeSpan(0, 5, 0);
        public static readonly int MAX_DELIVERY_COUNT = 1500;
        // Retry policy (minimumbackoff, maximumbackoff, maximumretrycount
        // partition or not (5 * 16) or 5gb only



        private NamespaceManager _namespaceManager;
        private MessagingFactory _messagingFactory;

        private string _sbConnectionString;

        public string SbConnectionString
        {
            get
            {
                if (!string.IsNullOrEmpty(_sbConnectionString))
                    return _sbConnectionString;
                _sbConnectionString = ConfigurationManager.AppSettings["ServerMSMQ"];

                return _sbConnectionString;
            }
            set
            {
                _sbConnectionString = value;
            }
        }

        private NamespaceManager NamespaceManager =>
            _namespaceManager ?? (_namespaceManager = NamespaceManager.CreateFromConnectionString(SbConnectionString));

        private MessagingFactory MessagingFactory =>
            _messagingFactory ?? (_messagingFactory = MessagingFactory.CreateFromConnectionString(SbConnectionString));

        public bool SupportsUnlimitedReceiveLocks => false;

        public void InitializeAtStartup()
        {
        }

        #region Queue
        public ServiceBusQueueClient CreateQueue(string queueName)
        {
            // Retry policy for individual queue
            // Partition or not --> 5g or 80gb
            // Receive mode : peeklock  --> required DiUnite or DiConnect must call complete or abandon when finishing processing message
            //      Currently MSMQ uses receiveanddelete mode --> not well for distributed queues
            // Maxdeliverycount --> move to deadletter
            // LockDuration --> become visible after that duration
            // Message Time to live --> also move to deadletter
            // Duplicate message detection --> message ID created by client not as MSMQ.
            if (!QueueExists(queueName))
            {
                QueueDescription queueDescription = new QueueDescription(queueName);
                queueDescription.LockDuration = QUEUE_TIMEOUT;
                queueDescription.MaxDeliveryCount = MAX_DELIVERY_COUNT;
                queueDescription.EnableBatchedOperations = true;
                queueDescription.MaxSizeInMegabytes = 1024 * 5; // app.config?

                NamespaceManager.CreateQueue(queueDescription);
            }
            return GetQueue(queueName);
        }

        private ServiceBusQueueClient GetQueue(string queueName)
        {
            QueueClient serviceBusClient = GetQueueClient(queueName);
            return new ServiceBusQueueClient(serviceBusClient);
        }

        public bool QueueExists(string queueName)
        {
            return NamespaceManager.QueueExists(queueName);
        }

        public void DeleteQueue(string queueName)
        {
            NamespaceManager.DeleteQueue(queueName);
        }

        public QueueClient GetQueueClient(string queueName)
        {
            return QueueClient.CreateFromConnectionString(SbConnectionString, queueName,ReceiveMode.ReceiveAndDelete); // IMPORTANT
        }

        public IEnumerable<string> GetQueueNames()
        {
            {
                foreach (QueueDescription qd in NamespaceManager.GetQueues())
                {
                    yield return qd.Path;
                }
            }
        }

        public int GetQueueSize(string name)
        {
            QueueDescription queue = NamespaceManager.GetQueue(name);
            if (queue != null)
                return (int)queue.MessageCount;
            return -1;
        }

        public void Shutdown()
        {
            //handeled in ServiceBusManager
        }

        #endregion


        public static T GetBody<T>(BrokeredMessage brokeredMessage)
        {
            var stream = brokeredMessage.GetBody<Stream>();
            System.Runtime.Serialization.DataContractSerializer serializer = new System.Runtime.Serialization.DataContractSerializer(typeof(T));
            System.Xml.XmlDictionaryReader reader = System.Xml.XmlDictionaryReader.CreateBinaryReader(stream, System.Xml.XmlDictionaryReaderQuotas.Max);
            object deserializedBody = serializer.ReadObject(reader);
            T msgBase = (T)deserializedBody;
            return msgBase;
        }

        internal static ICIPMessage ConvertMessage(BrokeredMessage serviceBusMessage)
        {
            //CIPMSMQMessage ret = null;
            ICIPMessage ret = null;

            if (serviceBusMessage != null)
            {
                try
                {
                    var body = serviceBusMessage.GetBody<Stream>();

                    dynamic jsonBody = JsonConvert.DeserializeObject(new StreamReader(body, true).ReadToEnd());
                    var mb = new CIPMessageBody(jsonBody);
                    ret = new CIPMSMQMessage(serviceBusMessage.MessageId, mb);
                }
                catch (Exception sysEx)
                {
                    string errorMessage = string.Format("Cannot convert message from BrokeredMessage to CIPMSMQMessage");
                    DiCIPException appEx = new DiCIPException(errorMessage, sysEx);
                    throw appEx;
                }
            }
            return ret;
        }

        internal static BrokeredMessage ConvertMessage(ICIPMessage message)
        {
            BrokeredMessage serviceBusMessage = null;
            if (message != null)
            {
                try
                {
                    // message.GetBody().MessageBody = message.GetBody();
                    serviceBusMessage = new BrokeredMessage(new MemoryStream(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message.GetBody()))))
                    {
                        ContentType = "application/json",
                        MessageId = message.GetMessageID(),
                        TimeToLive = TimeSpan.FromDays(1)
                        // TimeToLive = TimeSpan.FromMinutes(2)
                    };

                    // ToDo : get "string RequestId", "KeyValuePair<string, string> From" , "List<KeyValuePair<string, string>> To", "Token" from serviceBusMessage
                    //serviceBusMessage = new BrokeredMessage(message.GetBody().MessageBody);
                    //serviceBusMessage.MessageId = message.GetMessageID();

                    //serviceBusMessage.Properties["Priority"] = (int)message.GetMessagePriority();
                }
                catch (Exception sysEx)
                {
                    string errorMessage = string.Format("Cannot convert message from CIPMSMQMessage to BrokeredMessage");
                    DiCIPException appEx = new DiCIPException(errorMessage, sysEx);
                    throw appEx;
                }
                return serviceBusMessage;
            }
            return null;
        }
        internal static MemoryStream SerializeToStream(object o)
        {
            MemoryStream stream = new MemoryStream();
            XmlSerializer x = new XmlSerializer(o.GetType());
            x.Serialize(stream, o);
            return stream;
        }
    }
}
