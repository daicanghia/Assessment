﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DiCIP.Messaging;
using Microsoft.ServiceBus.Messaging;

namespace DiCIP.Messaging.ServiceBus
{
    public static class ServiceBusExtensions
    {
        /// <summary>
        /// Uses QueueClient.SendBath() in batches of specified items. BatchSize defaults to 1000 items.
        /// The maximum size of the batch is the same as the maximum size of a single message (currently 256 Kb).
        /// http://msdn.microsoft.com/en-us/library/microsoft.servicebus.messaging.queueclient.sendbatch.aspx
        /// </summary>
        /// <param name="client"></param>
        /// <param name="messages">Collection of BrokeredMessages</param>
        /// <param name="batchSize">Maximum items to send in one batch</param>
        public static void SendBatchSafe(this QueueClient client, IEnumerable<BrokeredMessage> messages, int batchSize = 1000)
        {
            if (messages == null)
                return;

            List<BrokeredMessage> batch = new List<BrokeredMessage>(batchSize);

            var enumerator = messages.GetEnumerator();
            int count = 0;

            while (enumerator.MoveNext())
            {
                count++;
                batch.Add(enumerator.Current);

                if (count % batchSize == 0)
                {
                    Send(client, batch);
                    batch.Clear();
                }
            }

            if (batch.Count > 0)
                Send(client, batch);
        }

        private static void Send(QueueClient client, IEnumerable<BrokeredMessage> batch)
        {
            client.SendBatch(batch);
        }

        /// <summary>
        /// Completes a collection of BrokeredMessage.LockTokens. Maximum batch size is 4500. 
        /// </summary>
        /// <param name="client"></param>
        /// <param name="lockToken">Collection of Guids, available from BrokeredMessage.LockToken.</param>
        /// <param name="batchSize">Maximum items to complete in one batch. Will not exceed 4500 due to the 256 Kb limit.</param>
        public static void CompleteBatchSafe(this QueueClient client, IEnumerable<Guid> lockToken, int batchSize = 4000)
        {
            if (client == null || lockToken == null)
                return;

            if (batchSize > 4500)
                batchSize = 4500;

            List<Guid> batch = new List<Guid>(batchSize);

            var enumerator = lockToken.GetEnumerator();
            int count = 0;

            while (enumerator.MoveNext())
            {
                count++;
                batch.Add(enumerator.Current);

                if (count % batchSize == 0)
                {
                    client.CompleteBatch(batch);
                    batch.Clear();
                }
            }

            if (batch.Count > 0)
                client.CompleteBatch(batch);
        }

        /// <summary>
        /// Uses TopicClient.SendBath() in batches of specified items. BatchSize defaults to 1000 items.
        /// The maximum size of the batch is the same as the maximum size of a single message (currently 256 Kb).
        /// http://msdn.microsoft.com/en-us/library/microsoft.servicebus.messaging.queueclient.sendbatch.aspx
        /// </summary>
        /// <param name="client"></param>
        /// <param name="messages">Collection of BrokeredMessages</param>
        /// <param name="batchSize">Maximum items to send in one batch</param>
        public static void SendBatchSafe(this TopicClient client, IEnumerable<BrokeredMessage> messages, int batchSize = 1000)
        {
            if (client == null || messages == null)
                return;

            List<BrokeredMessage> batch = new List<BrokeredMessage>(batchSize);

            var enumerator = messages.GetEnumerator();
            int count = 0;

            while (enumerator.MoveNext())
            {
                count++;
                batch.Add(enumerator.Current);

                if (count % batchSize == 0)
                {
                    client.SendBatch(batch);
                    batch.Clear();
                }
            }

            if (batch.Count > 0)
                client.SendBatch(batch);
        }
    }
}
