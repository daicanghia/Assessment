﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiUniversalAdapter.Common.Configuration
{
    public interface IProcessSettings
    {
        /**
        * Process ID in GUID 
        */
        string ProcessID { get; set; }
        /**
         * File name with full path
         */
        string RuntimeProcessFileName { get; set; }
        /**
         * Max Number of DiUniversalAdapter Runtime Processes are allowed to start
         */
        int MaxRuntimeProcesses { get; set; }
        /**
       * Number of DiUniversalAdapter Runtime Processes will be started when the  server starts
       */
        int RuntimeProcesses { get; set; }
        /**
         * The queue used to store all requests sent to DiUniversalAdapter Runtime Service
         */
        string InboundQueue { get; set; }
        /**
         * The queue used to store all request results
         */
        string OutboundQueue { get; set; }
        /**
         * The queue used to store and log all failed requests
         */
        string ErrorQueue { get; set; }

        //The queue used to manage DiUniversalAdapter Runtime Process
        string CollaborativeQueue { get; set; }
        //How often Runtime Process check and receive request in queues, Default to 100 milliseconds
        int ReceivingRequestTimerInMillisecons { get; set; }
        int ReceivingResultTimerInMillisecons { get; set; }
        int ReceivingCommandTimerInMillisecons { get; set; }
        bool IsDebugMode { get; set; }
        int TimerInMillisecons { get; set; }
        string ProcessFileName { get; set; }
        int Processes { get; set; }
        int RuntimeStartThreads { get; set; }
        string SchedulerActive { get; set; }
    }

    /**
      * Classes used to hold DiUniversalAdapter Runtime Process settings
     */
    public class RuntimeProcessSettings : IProcessSettings
    {
        /**
        * Process ID in GUID 
        */
        public string ProcessID { get; set; }
        /**
         * File name with full path
         */
        public string RuntimeProcessFileName { get; set; }
        
        /**
         * Max Number of DiUniversalAdapter Runtime Processes are allowed to start
         */
        public int MaxRuntimeProcesses { get; set; }

        /**
       * Number of DiUniversalAdapter Runtime Processes will be started when the  server starts
       */
        public int RuntimeProcesses { get; set; }
        /**
         * The queue used to store all requests sent to DiUniversalAdapter Runtime Service
         */
        public string InboundQueue { get; set; }

        /**
         * The queue used to store all request results
         */
        public string OutboundQueue { get; set; }

        /**
         * The queue used to store and log all failed requests
         */
        public string ErrorQueue { get; set; }

        //The queue used to manage DiUniversalAdapter Runtime Process
        public string CollaborativeQueue { get; set; }

        //How often Runtime Process check and receive request in queues, Default to 100 milliseconds
        public int ReceivingRequestTimerInMillisecons { get; set; }

        public int ReceivingResultTimerInMillisecons { get; set; }

        public int ReceivingCommandTimerInMillisecons { get; set; }

        public int RuntimeStartThreads { get; set; }

        public int RuntimeProcessTimeOutInMillisecons { get; set; }
        //public string SchedulerRuntimeProcessFileName { get; set; }
        public string SchedulerActive { get; set; }

        public int SchedulerReceivingRequestTimerInMillisecons { get; set; }

        public bool IsDebugMode { get; set; }

        public string ProcessFileName { get; set; }
       
        public int Processes { get; set; }

        public int TimerInMillisecons { get; set; }



        //public int TimerInMillisecons { get; set; } 

        public RuntimeProcessSettings()
        {
            this.IsDebugMode = false;        
        }

    }

    public class RunningProcessSettings : IProcessSettings
    {
        /**
        * Process ID in GUID 
        */
        public string ProcessID { get; set; }
        /**
         * File name with full path
         */
        public string RuntimeProcessFileName { get; set; }

        /**
         * Max Number of DiUniversalAdapter Runtime Processes are allowed to start
         */
        public int MaxRuntimeProcesses { get; set; }

        /**
       * Number of DiUniversalAdapter Runtime Processes will be started when the  server starts
       */
        public int RuntimeProcesses { get; set; }
        /**
         * The queue used to store all requests sent to DiUniversalAdapter Runtime Service
         */
        public string InboundQueue { get; set; }

        /**
         * The queue used to store all request results
         */
        public string OutboundQueue { get; set; }

        /**
         * The queue used to store and log all failed requests
         */
        public string ErrorQueue { get; set; }

        //The queue used to manage DiUniversalAdapter Runtime Process
        public string CollaborativeQueue { get; set; }

        //How often Runtime Process check and receive request in queues, Default to 100 milliseconds
        public int ReceivingRequestTimerInMillisecons { get; set; }

        public int ReceivingResultTimerInMillisecons { get; set; }

        public int ReceivingCommandTimerInMillisecons { get; set; }

        public int RuntimeStartThreads { get; set; }

        public int RuntimeProcessTimeOutInMillisecons { get; set; }

        public bool IsDebugMode { get; set; }
        //public int TimerInMillisecons { get; set; } 
        public string ProcessFileName { get; set; }

        public int Processes { get; set; }

        public int TimerInMillisecons { get; set; }


        //public string RunningProcessFileName { get; set; }

        //public int RunningProcesses { get; set; }
        public string SchedulerActive { get; set; }
        public RunningProcessSettings()
        {
            this.IsDebugMode = false;
        }

    }

    /**
   * Classes used to hold information related to DiUniversalAdapter Runtime Process
   */
    public class RuntimeProcessInfo
    {
        public string ProcessID { get; set; }
        public RuntimeProcessStatus ProcessStatus { get; set; }
        public string RuntimeMessage { get; set; }
        public RuntimeProcessInfo()
        {

        }
    }
    
    /**
     * DiUniversalAdapterRuntimeProcessStatus
     */
    public enum RuntimeProcessStatus
    {
        NotStarted = 0,
        Failed2Start,
        Started,
        Running,
        Pausing,
        Stopped

    }
    public enum CIPNotficationType
    {
        Information = 1,
        Error,
        Exception,
        UnhandledException
    }
    public enum RuntimeActionTaken
    {
        None,
        Pausing,
        Stoping
    }

    public enum RequestType
    {
        Request,
        RequestResult,
        RequestError
    }

    public enum RuntimeAppSettings
    {
        IsRunning,
        SchedulerRuntimeProcessFileName,
        SchedulerRuntimeProcesses,
        SchedulerActive,
        RunningProcessFileName,
        RunningProcesses,
        RuntimeProcessFileName,
        MaxRuntimeProcesses,
        RuntimeProcesses,
        InboundQueue,
        OutboundQueue,
        ErrorQueue,
        CollaborativeQueue,
        ReceivingResultTimerInMillisecons,
        ReceivingRequestTimerInMillisecons,
        ReceivingCommandTimerInMillisecons,
        RuntimeStartThreads,
        RuntimeProcessTimeOutInMillisecons,
        SchedulerReceivingRequestTimerInMillisecons,
        SchedulerReceivingRequestTimerInMilliseconsMin,
        SchedulerReceivingRequestTimerInMilliseconsMax,
        Debug,
        NotificationEmails,
        RunningSetting,
        RuntimeSetting
    }
}