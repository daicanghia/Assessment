﻿using DiUniversalAdapter.Common.AppException;
using DiUniversalAdapter.Common.Configuration;
using DiUniversalAdapter.Common.ExceptionHandler;
using DiUniversalAdapter.Common.Helper;
using DiUniversalAdapter.Common.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web;

namespace DiUniversalAdapter.Common.RuntimeContainer
{
    /**
     * Class provide data and functionalities used to manage DiUniversalAdapter Runtime Process
     */
    public class RuntimeProcessContainer : Process
    {

        private new bool Disposed { get; set; }
        public IProcessSettings ProcessSettings { get; set; }
        public RuntimeProcessInfo ProcessInfo { get; set; }

        public string ContainerId { get; set; }

        public RuntimeActionTaken ActionTaken { get; set; }

        public RuntimeProcessContainer()
            : base()
        {
            this.Disposed = false;
            this.ProcessInfo = new RuntimeProcessInfo();
            this.ProcessInfo.ProcessStatus = RuntimeProcessStatus.NotStarted;
            this.ActionTaken = RuntimeActionTaken.None;
        }

        protected override void Dispose(bool disposing)
        {
            if (!this.Disposed)
            {

                if (disposing)
                {
                    this.ProcessSettings = null;
                    this.ProcessInfo = null;
                }
                this.Disposed = true;
                base.Dispose(disposing);
            }
        }


        public new void Start()
        {
            try
            {
#if AUTOTEST
                this.StartInfo.WindowStyle = ProcessWindowStyle.Normal;
#else
                this.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
#endif
                this.EnableRaisingEvents = true;
                this.StartInfo.UseShellExecute = false;
                this.Exited += new EventHandler(RuntimeProcessExited);
                this.StartInfo.FileName = this.ProcessSettings.RuntimeProcessFileName;
                this.ProcessSettings.ProcessID = this.ContainerId;

                //Generate and pass arguments to the process
                DiUniversalAdapterServiceHelper helper = new DiUniversalAdapterServiceHelper();
                this.StartInfo.Arguments = helper.GenerateParameters(this.ProcessSettings);

                base.Start();
            }
            catch (OutOfMemoryException outOfMemoryEx)
            {
                this.ProcessInfo.ProcessStatus = RuntimeProcessStatus.Failed2Start;
                this.ProcessInfo.RuntimeMessage = outOfMemoryEx.Message;
                //Code to handle exception here. Don't need to throw exception;
                DiUniversalAdapterExceptionHandler.HandleException(null, outOfMemoryEx);

            }
            catch (Exception unknownEx)
            {
                this.ProcessInfo.ProcessStatus = RuntimeProcessStatus.Failed2Start;
                this.ProcessInfo.RuntimeMessage = unknownEx.Message;
                //Code to handle exception here. Don't need to throw exception ;
                DiUniversalAdapterExceptionHandler.HandleException(null, unknownEx);
            }
        }
        public void Pause()
        {
            try
            {
                this.ActionTaken = RuntimeActionTaken.Pausing;
            }
            catch (DiUniversalAdapterServiceException appEx)
            {
                DiUniversalAdapterExceptionHandler.HandleException(null, appEx);
            }
            catch (Exception sysEx)
            {
                DiUniversalAdapterExceptionHandler.HandleException(null, sysEx);
            }
        }
        public void StopWitoutNotice()
        {
            try
            {
                base.Kill();
            }
            catch (Exception sysEx)
            {
                DiUniversalAdapterExceptionHandler.HandleException(null, sysEx);
            }
        }
        public void Stop()
        {
            try
            {
                this.ActionTaken = RuntimeActionTaken.Stoping;
            }
            catch (DiUniversalAdapterServiceException appEx)
            {
                DiUniversalAdapterExceptionHandler.HandleException(null, appEx);
            }
            catch (Exception sysEx)
            {
                DiUniversalAdapterExceptionHandler.HandleException(null, sysEx);
            }
        }
        #region Private Methods---------------------------------------------------------

        private void RuntimeProcessExited(object sender, System.EventArgs e)
        {
            RuntimeProcessContainer runtimeProcess = (RuntimeProcessContainer)sender;
            runtimeProcess.ProcessInfo.ProcessStatus = RuntimeProcessStatus.Stopped;

            try
            {
                //Send email notification first.
                string stoppedPID = runtimeProcess.ProcessInfo.ProcessID;
                int exitCode = runtimeProcess.ExitCode;

                EmailNotificationHelper emailNotifier = new EmailNotificationHelper();
                NotificationInfo notificationInfo = emailNotifier.GetProcessStatusNotification(
                    stoppedPID, exitCode, DiCIP.Common.Configuration.CIPService.DiUniversalAdapter, -1, RuntimeProcessStatus.Stopped);
                emailNotifier.NotifyUsingEmail(notificationInfo, emailNotifier.GetRecipients(""));
            }
            catch (Exception)
            {

            }


        }
        private void Process2Stop(object sender, System.EventArgs e)
        {
            RuntimeProcessContainer runtimeProcess = (RuntimeProcessContainer)sender;
            runtimeProcess.ProcessInfo.ProcessStatus = RuntimeProcessStatus.Stopped;




        }
        #endregion Private Methods------------------------------------------------------
    }
}