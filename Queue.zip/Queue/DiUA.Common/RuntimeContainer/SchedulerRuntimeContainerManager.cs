﻿using DiUniversalAdapter.Common.AppException;
using DiUniversalAdapter.Common.Configuration;
using DiUniversalAdapter.Common.ExceptionHandler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Web;

namespace DiUniversalAdapter.Common.RuntimeContainer
{
    /**
   * RuntimeContainerManager is singleton class to ensure that the container is only initilized one time and
   * there is only instance.
   */
    public class SchedulerRuntimeContainerManager : IDisposable
    {
        private static SchedulerRuntimeContainerManager ContainerManager = null;

        private bool Disposed { get; set; }
        private Dictionary<string, SchedulerRuntimeProcessContainer> RuntimeContainers = null;

        private IProcessSettings RuntimeProcessSettings { get; set; }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public static SchedulerRuntimeContainerManager GetInstance()
        {
            if (ContainerManager == null)
            {
                ContainerManager = new SchedulerRuntimeContainerManager();
            }
            return ContainerManager;
        }

        private SchedulerRuntimeContainerManager()
        {
            this.Disposed = false;
        }
        public void Dispose()
        {
            Dispose(true);

        }
        protected virtual void Dispose(bool disposing)
        {
            if (!this.Disposed)
            {
                if (disposing)
                {
                    RuntimeProcessSettings = null;

                    if (this.RuntimeContainers != null)
                    {
                        foreach (SchedulerRuntimeProcessContainer runtimeContainer in this.RuntimeContainers.Values)
                        {
                            runtimeContainer.Dispose();
                        }
                    }

                }
                this.Disposed = true;
            }
        }

        /**
         * Initialize Schedule Runtime Container
         */
        [MethodImpl(MethodImplOptions.Synchronized)]
        public void Initialize(IProcessSettings processSettings)
        {
            try
            {
                //Initialize Schedule Runtime Process pool.
                this.RuntimeContainers = new Dictionary<string, SchedulerRuntimeProcessContainer>();
                this.RuntimeProcessSettings = processSettings;

                if (processSettings.Processes <= 0)
                {
                    throw new DiUniversalAdapterServiceException("Schedule Service cannot be started without starting DiCentral.UniversalAdapter.Schedule.Service Process!");
                }
                for (int i = 0; i < processSettings.Processes; i++)
                {
                    StartProcess(processSettings);
                    Thread.Sleep(200);
                }

            }
            catch (DiUniversalAdapterServiceException appEx)
            {
                throw appEx;
                //DiUniversalAdapterExceptionHandler.HandleException(null, appEx);
            }
            catch (Exception sysEx)
            {
                //DiUniversalAdapterExceptionHandler.HandleException(null, sysEx);
                throw new DiUniversalAdapterServiceException("Cannot start Schedule Service Process!", sysEx);
            }
        }

        /**
         * Start Schedule Runtime Process
         */
        public void StartSchedulerRuntimeProcess(int noOfProcesses)
        {
            try
            {
                if (this.RuntimeContainers == null)
                {
                    throw new DiUniversalAdapterServiceException("Schedule Runtime Process Container has not been initialized!");
                }

                int runningProcesses = GetProcessesByStatus(RuntimeProcessStatus.Running);

                if (noOfProcesses <= 0)
                {
                    throw new DiUniversalAdapterServiceException("Invalid request!");
                }
                for (int i = 0; ((i < noOfProcesses) && (i + runningProcesses) < this.RuntimeProcessSettings.MaxRuntimeProcesses); i++)
                {
                    StartProcess(this.RuntimeProcessSettings);
                }

            }
            catch (DiUniversalAdapterServiceException appEx)
            {
                DiUniversalAdapterExceptionHandler.HandleException(null, appEx);
            }
            catch (Exception sysEx)
            {
                DiUniversalAdapterExceptionHandler.HandleException(null, sysEx);
            }
        }

        public void StartOneRuntimeProcess()
        {
            try
            {
                if (this.RuntimeContainers == null)
                {
                    throw new DiUniversalAdapterServiceException("Schedule Runtime Process Container has not been initialized!");
                }

                StartProcess(this.RuntimeProcessSettings);
            }
            catch (DiUniversalAdapterServiceException appEx)
            {
                DiUniversalAdapterExceptionHandler.HandleException(null, appEx);
            }
            catch (Exception sysEx)
            {
                DiUniversalAdapterExceptionHandler.HandleException(null, sysEx);
            }
        }

        /// <summary>
        /// Stops DiUniversalAdapter Runtime Processes.</summary>
        /// <param name="noOfProcesses"> Numbe of runtime process to be stoped</param>
        /// <returns>
        /// None </returns>
        /// <seealso cref="SchedulerRuntimeProcessInfo">
        /// Refer to  RuntimeProcessSettings for details</seealso> 
        public void StopSchedulerRuntimeProcess()
        {
            if (this.RuntimeContainers == null)
            {
                throw new DiUniversalAdapterServiceException("Iligal call made. Schedule Runtime Process Container has not been initialized!");
            }

            Dictionary<string, SchedulerRuntimeProcessContainer>.ValueCollection runtimeProcesses = this.RuntimeContainers.Values;
            foreach (SchedulerRuntimeProcessContainer runtimeContainer in runtimeProcesses)
            {
                try
                {
                    runtimeContainer.StopWitoutNotice();

                }
                catch (Exception)
                {

                }
            }
            if (this.RuntimeContainers != null)
            {
                this.RuntimeContainers.Clear();
            }

        }
        public void StopSchedulerRuntimeProcess(int noOfProcesses)
        {
            if (this.RuntimeContainers == null)
            {
                throw new DiUniversalAdapterServiceException("Iligal call made. Schedule Runtime Process Container has not been initialized!");
            }

            if (noOfProcesses <= 0)
            {
                throw new DiUniversalAdapterServiceException("Invalid request made to StopSchedulerRuntimeProcess method");
            }

            Dictionary<string, SchedulerRuntimeProcessContainer>.ValueCollection runtimeProcesses = this.RuntimeContainers.Values;
            int count = 0;
            foreach (SchedulerRuntimeProcessContainer runtimeContainer in runtimeProcesses)
            {
                if ((count < noOfProcesses) && runtimeContainer.ProcessInfo.ProcessStatus != RuntimeProcessStatus.Stopped)
                {
                    count++;
                    runtimeContainer.Stop();
                }
            }
        }
        /// <summary>
        /// Puase DiUniversalAdapter Runtime Processes.</summary>
        /// <param name="noOfProcesses"> Numbe of runtime process to be stoped</param>
        /// <returns>
        /// None </returns>
        /// <seealso cref="SchedulerRuntimeProcessInfo">
        /// Refer to  RuntimeProcessSettings for details</seealso> 
        public void PauseSchedulerRuntimeProcess(int noOfProcesses)
        {

            if (this.RuntimeContainers == null)
            {
                throw new DiUniversalAdapterServiceException("Iligal call made. Schedule Runtime Process Container has not been initialized!");
            }

            if (noOfProcesses <= 0)
            {
                throw new DiUniversalAdapterServiceException("Invalid request made to StopSchedulerRuntimeProcess method");
            }

            Dictionary<string, SchedulerRuntimeProcessContainer>.ValueCollection runtimeProcesses = this.RuntimeContainers.Values;
            int count = 0;
            foreach (SchedulerRuntimeProcessContainer runtimeContainer in runtimeProcesses)
            {
                if ((count < noOfProcesses) && runtimeContainer.ProcessInfo.ProcessStatus == RuntimeProcessStatus.Running)
                {
                    count++;
                    runtimeContainer.Pause();
                }
            }
        }
        /// <summary>
        /// Get overall status of all DiUniversalAdapter Runtime Process.</summary>
        /// <param name="processNumbers"> Numbe of runtime process to start</param>
        /// <param name="processSettings"> Runtime process settings</param>
        /// <seealso cref="SchedulerRuntimeProcessSettings">
        /// Refer to  RuntimeProcessSettings for details</seealso> 
        /// <returns>
        /// Information related to all DiUniversalAdapter Runtime Processes</returns>
        /// <seealso cref="SchedulerRuntimeProcessInfo">
        /// Refer to  RuntimeProcessSettings for details</seealso> 
        public List<RuntimeProcessInfo> GetSchedulerRuntimeProcessStatus()
        {
            if (this.RuntimeContainers == null)
            {
                throw new DiUniversalAdapterServiceException("Iligal call made. Schedule Runtime Process Container has not been initialized!");
            }

            List<RuntimeProcessInfo> runtimeCcontainers = new List<RuntimeProcessInfo>();
            Dictionary<string, SchedulerRuntimeProcessContainer>.ValueCollection runtimeProcesses = this.RuntimeContainers.Values;
            foreach (SchedulerRuntimeProcessContainer runtimeProcess in runtimeProcesses)
            {
                runtimeCcontainers.Add(runtimeProcess.ProcessInfo);
            }

            return runtimeCcontainers;
        }


        #region Private Methods---------------------------------------------------------

        private void StartProcess(IProcessSettings processSettings)
        {
            try
            {
                //Start the process
                Thread startRuntimeProcess = new Thread(new ParameterizedThreadStart(StartProcessWorker));
                startRuntimeProcess.Start(processSettings);

            }
            /**This is reserved to catch exception of extra code if any. 
            *Exception  throws within starting thread will be handled within the thread
            */
            catch (DiUniversalAdapterServiceException appEx)
            {
                throw appEx;
                //DiUniversalAdapterExceptionHandler.HandleException(null, appEx);
            }
            catch (Exception sysEx)
            {
                //DiUniversalAdapterExceptionHandler.HandleException(null, sysEx);
                throw new DiUniversalAdapterServiceException("Cannot start Schedule Runtime Process!", sysEx);
            }
        }

        private void StartProcessWorker(Object processSettings)
        {
            SchedulerRuntimeProcessContainer SchedulerRuntimeProcess = new SchedulerRuntimeProcessContainer();

            try
            {
                IProcessSettings runtimeSettings = (IProcessSettings)processSettings;
                SchedulerRuntimeProcess.ProcessSettings = runtimeSettings;
                string GUID = Guid.NewGuid().ToString();
                SchedulerRuntimeProcess.ProcessInfo.ProcessID = GUID;
                this.RuntimeContainers.Add(GUID, SchedulerRuntimeProcess);
                SchedulerRuntimeProcess.ContainerId = GUID;
                SchedulerRuntimeProcess.Start();


            }
            catch (DiUniversalAdapterServiceException appEx)
            {
                string message = appEx.Message;
                //No need to handle the exception as it has already been handled.
            }
            catch (ThreadStateException threadStateEx)
            {
                SchedulerRuntimeProcess.ProcessInfo.ProcessStatus = RuntimeProcessStatus.Failed2Start;
                SchedulerRuntimeProcess.ProcessInfo.RuntimeMessage = "Invalid thread!";
                //Code to handle exception here. ;
                DiUniversalAdapterExceptionHandler.HandleException(null, threadStateEx);
            }
            catch (Exception unknownEx)
            {
                SchedulerRuntimeProcess.ProcessInfo.ProcessStatus = RuntimeProcessStatus.Failed2Start;
                SchedulerRuntimeProcess.ProcessInfo.RuntimeMessage = "Cannot start Schedule Runtime Process!";
                //Code to handle exception here. ;
                DiUniversalAdapterExceptionHandler.HandleException(null, unknownEx);
            }

        }
        #endregion---------------------------------------------------------

        private int GetProcessesByStatus(RuntimeProcessStatus status)
        {
            int no = 0;
            try
            {
                List<SchedulerRuntimeProcessContainer> containerList = this.RuntimeContainers.Values.ToList();

                var queryProcesses = from process in containerList
                                     where process.ProcessInfo.ProcessStatus == status
                                     select process;
                List<SchedulerRuntimeProcessContainer> runningProcessList = queryProcesses.ToList();
                no = runningProcessList.Count;
            }
            catch (Exception ex)
            {
                DiUniversalAdapterExceptionHandler.HandleException(null, ex);
            }
            return no;

        }

    }
}