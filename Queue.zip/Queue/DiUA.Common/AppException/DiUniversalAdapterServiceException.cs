﻿using System;

namespace DiUniversalAdapter.Common.AppException
{

    public enum RuntimeProcessExitCode
    {
        NoError = 0,
        InvalidParamsReceived,

        InvalidAppSettings,
        ConnecttionError,
        CannotStartRuntimeThreads,
        CannotStartRuntimeProcess,
        ProcessStopped,

    }

    /// <summary>
    /// DiUniversalAdapter Service Error Code
    /// </summary>
    public enum DiUniversalAdapterServiceErrorCode
    {
        NoError,
        A2AR02001001001E,
        A2AR02001001002E,
        A2AR02001001003E,
        A2AR02001001004E,
        A2AR02001002001E,
        A2AR02001002002E,
        A2AR02001002003E,
        A2AR02001002004E,
    }

    [Serializable]
    public class DiUniversalAdapterServiceException : System.Exception
    {

        public string ErrorMessage
        {
            get
            {
                return base.Message;
            }
        }

        public DiUniversalAdapterServiceErrorCode DiUniversalAdapterServiceErrorCode { get; set; }

        public string ErrorStackTrace
        {
            get
            {
                if (base.InnerException != null)
                {
                    return base.InnerException.StackTrace.ToString();
                }
                else
                {

                    if (base.StackTrace != null)
                    {
                        return base.StackTrace.ToString();
                    }
                    else
                    {
                        return "";
                    }
                }
            }
        }
        public DiUniversalAdapterServiceException()
            : base()
        {

        }
        public DiUniversalAdapterServiceException(string errorMessage)
          : base(errorMessage)
        {

        }
        public DiUniversalAdapterServiceException(System.Exception sysEx)
            : base("Error", sysEx)
        {

        }
        public DiUniversalAdapterServiceException(string errorMessage, System.Exception sysEx)
            : base(errorMessage, sysEx)
        {
        }
    }
}
