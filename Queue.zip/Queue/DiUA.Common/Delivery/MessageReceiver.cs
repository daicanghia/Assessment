﻿using DiCIP.Common.Models.Message;
using DiUniversalAdapter.Common.AppException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Web;

namespace DiUniversalAdapter.Common.Delivery
{
    public delegate void MessageHandler(object sender, ICIPMessage message);

    class MessageReceiver : IObserver<ICIPMessage>, IDisposable
    {
        private IDisposable TheUnsubscriber;

        //It is  request guid
        public string MessageReceiverGuid;

        //Using event
        private event MessageHandler OnMessageReceived;

        //Using call back
        public Action<ICIPMessage> CallBack { get; set; }
        private bool Disposed { get; set; }

        public MessageReceiver(string guid, MessageHandler eventHandler)
        {
            this.MessageReceiverGuid = guid;
            this.OnMessageReceived = eventHandler;
        }

        public MessageReceiver(string guid, Action<ICIPMessage> callBack)
        {
            this.MessageReceiverGuid = guid;
            this.CallBack = callBack;
        }

        ~MessageReceiver()
        {
            this.Dispose(false);
        }
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        internal void RegisterEvent(MessageHandler eventHander)
        {
            try
            {
                this.OnMessageReceived += eventHander;
            }
            catch (Exception sysEx)
            {
                throw new DiUniversalAdapterServiceException(sysEx);
            }
        }
        [MethodImpl(MethodImplOptions.Synchronized)]
        internal virtual void Subscribe(IObservable<ICIPMessage> messageTracker)
        {
            try
            {
                if (messageTracker != null)
                {
                    this.TheUnsubscriber = messageTracker.Subscribe(this);
                }
            }
            catch (Exception sysEx)
            {
                throw new DiUniversalAdapterServiceException(sysEx);
            }
        }

        public virtual void OnCompleted()
        {
            try
            {
                this.Unsubscribe();
            }
            catch (Exception sysEx)
            {
                throw new DiUniversalAdapterServiceException(sysEx);
            }
        }

        public virtual void OnError(Exception e)
        {
            throw new DiUniversalAdapterServiceException(e);

        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        internal void AsyncNotify(ICIPMessage message)
        {
            try
            {

                Task task = new Task(() => this.CallBack.Invoke(message));
                task.Start();

#if AUTOTEST
                string id = this.MessageReceiverGuid;
                DiUniversalAdapterDeliveryService.LogResultReceived(message.GetRequestID());
#endif
            }
            catch (Exception sysEx)
            {

                throw new DiUniversalAdapterServiceException(string.Format("Cannot deliver result for request {0}", message.GetRequestID()), sysEx);
            }
        }
        [MethodImpl(MethodImplOptions.Synchronized)]
        internal void SyncNotify(ICIPMessage message)
        {
            try
            {

                OnNext(message);
#if AUTOTEST
                string id = this.MessageReceiverGuid;
                DiUniversalAdapterDeliveryService.LogResultReceived(message.GetRequestID());
#endif
            }
            catch (Exception sysEx)
            {

                throw new DiUniversalAdapterServiceException(string.Format("Cannot deliver result for request {0}", message.GetRequestID()), sysEx);
            }
        }
        [MethodImpl(MethodImplOptions.Synchronized)]
        public virtual void OnNext(ICIPMessage value)
        {
            try
            {
                OnMessageReceived(this, value);

            }
            catch (Exception sysEx)
            {
                throw new DiUniversalAdapterServiceException(sysEx);

            }
        }


        internal virtual void Unsubscribe()
        {
            try
            {
                TheUnsubscriber.Dispose();
            }
            catch (Exception)
            {
                ;
            }
        }

        #region protected  Methods-----------------------------------------------------
        protected virtual void Dispose(bool disposing)
        {
            if (!this.Disposed)
            {
                if (disposing)
                {
                    try
                    {

                    }
                    catch (Exception)
                    {

                    }
                }
                this.Disposed = true;
            }
        }
        #endregion protected Methods--------------------------------------------------
    }
}