﻿using DiCIP.Common.Models.Message;
using DiUniversalAdapter.Common.AppException;
using DiUniversalAdapter.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DiUniversalAdapter.Common.Delivery
{
    class MessageTracker : IObservable<ICIPMessage>, IDisposable
    {
        #region Testing Code--------------------------------------------------
#if AUTOTEST

        public List<IObserver<ICIPMessage>> GetMessageReceivers()
        {
            return TheMessageReceivers.Values.ToList<IObserver<ICIPMessage>>();
        }

        public void ResetMessageReceivers()
        {
            TheMessageReceivers.Clear();
        }
#endif
        #endregion Testing Code-----------------------------------------------


        private readonly object SyncLock = new object();
        private IDictionary<string, IObserver<ICIPMessage>> TheMessageReceivers;

        private bool Disposed { get; set; }
        public MessageTracker()
        {
            TheMessageReceivers = new Dictionary<string, IObserver<ICIPMessage>>();
        }
        ~MessageTracker()
        {
            this.Dispose(false);
        }
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }
        public IDisposable Subscribe(IObserver<ICIPMessage> messageReceiver)
        {
            try
            {
                lock (SyncLock)
                {
                    string key = ((MessageReceiver)messageReceiver).MessageReceiverGuid;
                    TheMessageReceivers[key] = messageReceiver;
                }
                return new MessageReceivingUnsubscriber(TheMessageReceivers, messageReceiver, SyncLock);

            }
            catch (Exception sysEx)
            {
                throw new DiUniversalAdapterServiceException(string.Format("Cannot register Message Receiver {0}", ((MessageReceiver)messageReceiver).MessageReceiverGuid), sysEx);
            }
        }

        private class MessageReceivingUnsubscriber : IDisposable
        {
            private IDictionary<string, IObserver<ICIPMessage>> TheObservers;
            private IObserver<ICIPMessage> TheObserver;
            private object SyncLock;

            public MessageReceivingUnsubscriber(IDictionary<string, IObserver<ICIPMessage>> observers, IObserver<ICIPMessage> observer, object SyncLock)
            {
                this.SyncLock = SyncLock;

                this.TheObservers = observers;
                this.TheObserver = observer;
            }

            public void Dispose()
            {
                lock (SyncLock)
                {
                    string key = ((MessageReceiver)TheObserver).MessageReceiverGuid;
                    if (TheObserver != null && TheObservers.ContainsKey(key))
                    {
                        TheObservers.Remove(key);
                    }
                }
            }
        }

        internal void AsyncNotify(ICIPMessage message)
        {
            try
            {
                if (message != null)
                {
                    string key = message.GetRequestID();
                    IObserver<ICIPMessage> messageReceiver = GetMessageReceiver(key);
                    if (messageReceiver != null)
                    {
                        //Using call back
                        ((MessageReceiver)messageReceiver).AsyncNotify(message);
                    }
                    else
                    {
                       // RequestResult result = (RequestResult)message.GetBody();
                        throw new DiUniversalAdapterServiceException(string.Format("Cannot deliver output file {0} to request {1}", /*result.FileName*/"", key));
                    }
                }
            }
            catch (Exception sysEx)
            {
                throw new DiUniversalAdapterServiceException(string.Format("Cannot deliver result for request {0}", message.GetRequestID()), sysEx);
            }
        }


        internal void SyncNotify(ICIPMessage message)
        {
            try
            {
                if (message != null)
                {
                    string key = message.GetRequestID();
                    IObserver<ICIPMessage> messageReceiver = GetMessageReceiver(key);
                    if (messageReceiver != null)
                    {
                        //Using call back
                        ((MessageReceiver)messageReceiver).SyncNotify(message);
                    }
                    else
                    {
                      //  RequestResult result = (RequestResult)message.GetBody();
                        throw new DiUniversalAdapterServiceException(string.Format("Cannot deliver output file {0} to request {1}", /*result.FileName*/"", key));
                    }

                }
            }
            catch (Exception sysEx)
            {
                throw new DiUniversalAdapterServiceException(string.Format("Cannot deliver result for request {0}", message.GetRequestID()), sysEx);
            }
        }
        public void Complete(IObserver<ICIPMessage> messageReceiver)
        {
            try
            {
                messageReceiver.OnCompleted();

            }
            catch (Exception sysEx)
            {
                throw new DiUniversalAdapterServiceException(sysEx);
            }

        }

        internal IObserver<ICIPMessage> GetMessageReceiver(string receiverGuid)
        {
            try
            {
                lock (SyncLock)
                {
                    if (TheMessageReceivers.ContainsKey(receiverGuid))
                    {
                        return TheMessageReceivers[receiverGuid];
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            catch (Exception sysEx)
            {
                throw new DiUniversalAdapterServiceException(sysEx);
            }
        }


        public void Unsubscribe(IObserver<ICIPMessage> messageReceiver)
        {
            lock (SyncLock)
            {
                string key = ((MessageReceiver)messageReceiver).MessageReceiverGuid;

                if (TheMessageReceivers.ContainsKey(key))
                {
                    TheMessageReceivers.Remove(key);
                }
            }
        }

        #region protected  Methods-----------------------------------------------------
        protected virtual void Dispose(bool disposing)
        {
            if (!this.Disposed)
            {
                if (disposing)
                {
                    lock (SyncLock)
                    {
                        TheMessageReceivers.Clear();
                    }
                }
                this.Disposed = true;
            }
        }
        #endregion protected Methods--------------------------------------------------
    }
}