﻿using DiCIP.Common.Models.Message;
using DiUniversalAdapter.Common.AppException;
using DiUniversalAdapter.Common.ExceptionHandler;
using DiUniversalAdapter.Common.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Timers;
using System.Web;

namespace DiUniversalAdapter.Common.Delivery
{
    class DiUniversalAdapterResultReceiver
    {
        private static DiUniversalAdapterResultReceiver TheResultReceiver = null;
        private static System.Timers.Timer QueueWorkerTimmer = null;
        private static int ConfigTimmerIntervalInMilliseconds = 200;

        private DiUniversalAdapterResultReceiver(int timerInilliseconds)
        {
            try
            {
                ConfigTimmerIntervalInMilliseconds = timerInilliseconds;

                QueueWorkerTimmer = new System.Timers.Timer();
                QueueWorkerTimmer.Elapsed += new ElapsedEventHandler(ReceiveResults);
                QueueWorkerTimmer.Interval = ConfigTimmerIntervalInMilliseconds;
                QueueWorkerTimmer.Start();

            }
            catch (Exception sysEx)
            {
                throw new DiUniversalAdapterServiceException("Cannot initialize DiUniversalAdapter Delivery Service!", sysEx);
            }
        }
        [MethodImpl(MethodImplOptions.Synchronized)]
        public static DiUniversalAdapterResultReceiver InitializeResultReceiver(int timerInilliseconds)
        {
            if (TheResultReceiver == null)
            {
                TheResultReceiver = new DiUniversalAdapterResultReceiver(timerInilliseconds);
            }
            return TheResultReceiver;
        }
        [MethodImpl(MethodImplOptions.Synchronized)]
        public static void DeinitializeResultReceiver()
        {

            if (TheResultReceiver != null)
            {
                QueueWorkerTimmer.Stop();
                QueueWorkerTimmer.Dispose();
                QueueWorkerTimmer = null;

                TheResultReceiver = null;
            }
        }

        public static DiUniversalAdapterResultReceiver GetResultReceiver()
        {
            if (TheResultReceiver != null)
            {
                return TheResultReceiver;
            }
            else
            {
                throw new DiUniversalAdapterServiceException("DiUniversalAdapter Result Receiver has not been started. Must call DiUniversalAdapterResultReceiver.InitializeResultReceiver(...) to start the receiver first!");
            }
        }
        public static void StartReceivingResult()
        {
            try
            {
                if (QueueWorkerTimmer != null)
                {
                    QueueWorkerTimmer.Start();
                }
            }
            catch (Exception ex)
            {
                DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("Error occurs at StartReceivingRequest. Something must be wrong in threading! ", ex));
            }

        }
        public static void StopReceivingResult()
        {
            try
            {
                if (QueueWorkerTimmer != null)
                {
                    QueueWorkerTimmer.Stop();
                }
            }
            catch (Exception ex)
            {
                DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("Error occurs at StopReceivingRequest. Something must be wrong in threading! ", ex));
            }
        }

        #region protected  Methods-----------------------------------------------------

        #endregion protected  Methods--------------------------------------------------


        #region private  Methods-------------------------------------------------------
        private void ReceiveResults(object sender, EventArgs e)
        {
            try
            {
                //Stop timer while receiving result from queue
                StopReceivingResult();

                bool hasResultInQueue = true;
                DiUniversalAdapterQueuingHelper theHelper = new DiUniversalAdapterQueuingHelper();
                while (hasResultInQueue)
                {
                    ICIPMessage resultMessage = theHelper.ReceiveResultMessage();
                    if (resultMessage != null)
                    {
                        DiUniversalAdapterDeliveryService.Deliver(resultMessage);
                    }
                    else
                    {
                        //There is no more message in outbound queue
                        hasResultInQueue = false;
                    }
                }
            }
            catch (DiUniversalAdapterServiceException appEx)
            {
                DiUniversalAdapterExceptionHandler.HandleException(null, appEx);
            }
            catch (Exception sysEx)
            {
                DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("Error occurs while receiving result from Outbound queue!", sysEx));
            }

            finally
            {
                StartReceivingResult();

            }

        }
        #endregion private  Methods----------------------------------------------------
    }
}