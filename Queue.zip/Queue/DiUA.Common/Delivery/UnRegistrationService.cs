﻿using DiUniversalAdapter.Common.AppException;
using DiUniversalAdapter.Common.ExceptionHandler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Timers;
using System.Web;

namespace DiUniversalAdapter.Common.Delivery
{
    public class UnRegistrationService
    {
        private static UnRegistrationService TheUnRegistrationService = null;

        private static Timer UnRegistrationTimmer = null;
        //Unregister receivers every 1 minute
        private readonly TimeSpan UnRegistrationTimmerInterval = TimeSpan.FromSeconds(60);
        private static List<MessageReceiver> Receivers = null;
        private static readonly object syncLock = new object();

        private UnRegistrationService()
        {
            int interval = (int)UnRegistrationTimmerInterval.TotalMilliseconds;
            Receivers = new List<MessageReceiver>();
            UnRegistrationTimmer = new System.Timers.Timer();
            UnRegistrationTimmer.Elapsed += new ElapsedEventHandler(UnRegister);
            UnRegistrationTimmer.Interval = UnRegistrationTimmerInterval.TotalMilliseconds;
            UnRegistrationTimmer.Start();
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public static UnRegistrationService StartUnRegistrationService()
        {
            if (TheUnRegistrationService == null)
            {
                TheUnRegistrationService = new UnRegistrationService();

            }
            return TheUnRegistrationService;

        }
        [MethodImpl(MethodImplOptions.Synchronized)]
        public static void StopUnRegistrationService()
        {
            try
            {
                if (TheUnRegistrationService != null)
                {
                    if (UnRegistrationTimmer != null)
                    {
                        UnRegistrationTimmer.Stop();
                        UnRegistrationTimmer.Dispose();
                    }
                    if (Receivers != null)
                    {
                        lock (syncLock)
                        {
                            foreach (MessageReceiver receiver in Receivers)
                            {
                                receiver.Unsubscribe();
                            }
                            Receivers.Clear();

                        }
                    }
                    TheUnRegistrationService = null;
                }
            }
            catch (Exception)
            {
                ;
            }
        }
        public static UnRegistrationService GetUnRegistrationService()
        {
            if (TheUnRegistrationService != null)
            {
                return TheUnRegistrationService;
            }
            else
            {
                throw new DiUniversalAdapterServiceException("DiUniversalAdapter unregistration service has not been started. Must call UnRegistrationService.StartUnRegistrationService to start the service first!");

            }
        }

        internal static void Register(MessageReceiver receiver)
        {
            lock (syncLock)
            {
                try
                {
                    Receivers.Add(receiver);
                }
                catch (Exception syEx)
                {
                    string receiverId = "UNKNOWN";
                    if (receiver != null)
                    {
                        receiverId = receiver.MessageReceiverGuid;
                    }
                    string error = string.Format("Cannot register Unregistration Service for requests {0}. The system will still operate normally!", receiverId);
                    DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException(error, syEx));
                }
            }
        }

        //[MethodImpl(MethodImplOptions.Synchronized)]
        private static void UnRegister(object obj, EventArgs e)
        {
            lock (syncLock)
                try
                {
                    foreach (MessageReceiver receiver in Receivers)
                    {
                        receiver.Unsubscribe();
                    }
                    Receivers.Clear();
                }
                catch (Exception syEx)
                {
                    DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("Cannot unregister Delivery Service for requests. The system will still operate normally!", syEx));

                }
        }
    }
}