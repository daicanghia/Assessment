﻿using DiCIP.Common.Models.Message;
using DiUniversalAdapter.Common.AppException;
using DiUniversalAdapter.Common.ExceptionHandler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Web;

namespace DiUniversalAdapter.Common.Delivery
{
    public class DiUniversalAdapterDeliveryService : IDisposable
    {
        #region Testing Code-----------------------------------------------------
#if AUTOTEST
        static List<string> ResutsReceived = new List<string>();


        [MethodImpl(MethodImplOptions.Synchronized)]
        public static void LogResultReceived(string id)
        {
            ResutsReceived.Add(id);
        }

        public static List<string> GetResutsReceived()
        {
            return ResutsReceived;

        }
        public static void ResetResutsReceived()
        {
            ResutsReceived.Clear();

        }

        public static List<string> GetReceiversRegistered()
        {
            List<string> receiversRegistered = new List<string>();
            if (TheMessageTracker != null)
            {
                List<IObserver<ICIPMessage>> receivers = TheMessageTracker.GetMessageReceivers();
                foreach (IObserver<ICIPMessage> receiver in receivers)
                {
                    if (receiver != null)
                    {
                        receiversRegistered.Add(((MessageReceiver)receiver).MessageReceiverGuid);
                    }
                }
            }
            return receiversRegistered;
        }
        public static void ResetReceiversRegistered()
        {
            if (TheMessageTracker != null)
            {
                TheMessageTracker.ResetMessageReceivers();
            }
        }

#endif
        #endregion Testing Code--------------------------------------------------


        private static object SyncLock = new object();

        private static DiUniversalAdapterDeliveryService TheDeliveryService = null;

        private static MessageTracker TheMessageTracker = null;

        private static UnRegistrationService TheUnRegistrationService = null;

        private static DiUniversalAdapterResultReceiver TheResultReceiver = null;


        private bool Disposed { get; set; }

        private DiUniversalAdapterDeliveryService()
        {
            TheMessageTracker = new MessageTracker();
        }
        ~DiUniversalAdapterDeliveryService()
        {
            this.Dispose(false);
        }
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public static void StartDeliveryService(int timerInilliseconds)
        {
            try
            {
                if (TheDeliveryService == null)
                {
                    TheDeliveryService = new DiUniversalAdapterDeliveryService();
                    TheResultReceiver = DiUniversalAdapterResultReceiver.InitializeResultReceiver(timerInilliseconds);
                    TheUnRegistrationService = UnRegistrationService.StartUnRegistrationService();
                }
            }
            catch (DiUniversalAdapterServiceException)
            {
                throw;
            }
            catch (Exception sysEx)
            {
                throw new DiUniversalAdapterServiceException("Cannot start DiUniversalAdapter Delivery Service", sysEx);
            }
        }
        public static void StopDeliveryService()
        {
            try
            {
                if (TheDeliveryService != null)
                {
                    DiUniversalAdapterResultReceiver.DeinitializeResultReceiver();
                    UnRegistrationService.StopUnRegistrationService();
                    if (TheDeliveryService != null)
                    {
                        TheDeliveryService.Dispose();
                        TheDeliveryService = null;
                    }


                }
            }
            catch (DiUniversalAdapterServiceException)
            {
                throw;
            }
            catch (Exception sysEx)
            {
                throw new DiUniversalAdapterServiceException("Cannot start DiUniversalAdapter Delivery Service", sysEx);
            }
        }


        public static DiUniversalAdapterDeliveryService GetDeliveryManager()
        {
            if (TheDeliveryService != null)
            {
                return TheDeliveryService;
            }
            else
            {
                throw new DiUniversalAdapterServiceException("DiUniversalAdapter Service Delivery has not been started. Must call DiUniversalAdapterDeliveryManager.StartDeliveryService to start the service first!");
            }
        }
        /**
         * Register Delivery Service using call back
         */
        public static void Register(string requestGuid, Action<ICIPMessage> callBack)
        {
            try
            {
                MessageReceiver receiver = new MessageReceiver(requestGuid, callBack);
                receiver.Subscribe(TheMessageTracker);
            }
            catch (DiUniversalAdapterServiceException appEx)
            {
                DiUniversalAdapterExceptionHandler.HandleException(null, appEx);

            }
            catch (Exception sysEx)
            {
                string error = string.Format("Cannot register delivery service for request: {0}!", requestGuid);
                DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException(error, sysEx));
            }

        }
        /**
         * Register Delivery Service using event
         */
        public static void Register(string requestGuid, MessageHandler eventHander)
        {

            try
            {
                MessageReceiver receiver = new MessageReceiver(requestGuid, eventHander);
                receiver.Subscribe(TheMessageTracker);
            }
            catch (DiUniversalAdapterServiceException appEx)
            {
                DiUniversalAdapterExceptionHandler.HandleException(null, appEx);

            }
            catch (Exception sysEx)
            {
                string error = string.Format("Cannot register delivery service for request: {0}!", requestGuid);
                DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException(error, sysEx));

            }
        }

        public static void UnRegister(string requestGuid)
        {
            try
            {

                MessageReceiver receiver = (MessageReceiver)TheMessageTracker.GetMessageReceiver(requestGuid);
                UnRegistrationService.Register(receiver);

            }
            catch (DiUniversalAdapterServiceException appEx)
            {
                DiUniversalAdapterExceptionHandler.HandleException(null, appEx);
            }
            catch (Exception sysEx)
            {
                string error = string.Format("Cannot unregister delivery service for request: {0}! The system will still operate normally!", requestGuid);
                DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException(error, sysEx));
            }
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public static void Deliver(ICIPMessage message)
        {

            try
            {
                TheMessageTracker.AsyncNotify(message);
            }
            catch (DiUniversalAdapterServiceException appEx)
            {
                DiUniversalAdapterExceptionHandler.HandleException(null, appEx);
            }
            catch (Exception sysEx)
            {
                string requestGuid = "UNKNOWN";
                if (message != null)
                {
                    requestGuid = message.GetRequestID();
                }

                string error = string.Format("Cannot deliver result of request {0}!", requestGuid);
                DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException(error, sysEx));
            }
        }

        #region protected  Methods-----------------------------------------------------
        protected virtual void Dispose(bool disposing)
        {
            if (!this.Disposed)
            {
                if (disposing)
                {
                    try
                    {
                        TheMessageTracker.Dispose();
                    }
                    catch (Exception)
                    {
                        //Nothing to worry about if exception occurs here!
                    }
                }
                this.Disposed = true;
            }
        }
        #endregion protected Methods--------------------------------------------------


        #region private  Methods-----------------------------------------------------

        #endregion private  Methods-----------------------------------------------------
    }
}