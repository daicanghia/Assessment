﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiUniversalAdapter.Common.Models
{
    public class NotificationInfo
    {
        protected string ServiceName { get; set; }
        protected string RuntimeProccessName { get; set; }

        public string Subject { get; set; }
        public string Message { get; set; }


        public NotificationInfo(string service, string subject, string message)
        {
            this.ServiceName = service;
            this.Subject = subject;
            this.Message = message;
        }
        public string GetEmailSubject()
        {
            string emailSubject = string.Empty;
            emailSubject = string.Format("{0} >> {1}", this.ServiceName, this.Subject);
            return emailSubject;
        }
    }
}
