﻿using System;
using System.Collections.Generic;
using DiCIP.Common.Models.Message;

namespace DiUniversalAdapter.Common.Models
{
    [Serializable]
    public class BaseRequest : CIPMessageBody
    {
        public BaseRequest()
        {

        }
        public KeyValuePair<string, string> From { get; set; }
        public List<KeyValuePair<string, string>> To { get; set; }
        public string RequestGuid { get; set; }
        //message queue id
        public string messageId { get; set; }
        public string Client { get; set; }
    }
    [Serializable]
    public class Request : BaseRequest
    {

        public string RuntimeKey { get; set; }
        public string Activity { get; set; }
       // public IDictionary<string, string> Parameters { get; set; }

        public Request()
            : base()
        {

        }
        public Request(string processId, string activity)
        {
            this.RuntimeKey = processId;
            this.Activity = activity;
        }
    }
    [Serializable]
    public class RequestResult : BaseRequest
    {
        public Request TheRequest { get; set; }
        public string CurrentActivityID { get; set; }
        public string FileName { get; set; }
        public string Message { get; set; }
        public string ErrorCode { get; set; }
        public string ProcessID { get; set; }
        public RequestResult()
            : base()
        {
            this.Message = null;
        }
        public RequestResult(string processID, string activity, string errorMessasge)
        {
            this.ProcessID = processID;
            this.CurrentActivityID = activity;
            this.Message = errorMessasge;
        }
        ~RequestResult()
        {
            this.ProcessID = null;
            this.CurrentActivityID = null;
            this.Message = null;
        }
    }
    [Serializable]
    public class RequestError : BaseRequest
    {
        public Request TheRequest { get; set; }
        public RequestResult TheResult { get; set; }
        public RequestError()
            : base()
        {

        }
        ~RequestError()
        {
            this.TheRequest = null;
            this.TheResult = null;
        }
    }
}
