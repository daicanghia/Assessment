﻿using DiCIP.Common.AppException;
using DiUniversalAdapter.Common.AppException;
using DiUniversalAdapter.Common.Helper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace DiUniversalAdapter.Common.ExceptionHandler
{
    public class DiUniversalAdapterExceptionHandler
    {
        //DiUniversalAdapter Runtime Service will log errors to <UserFiler>\AppData\Local\DiUniversalAdapter\DiUniversalAdapterRutimeServiceLog.txt by default
        const string DiUniversalAdapterRuntimeServiceErrorLogFolder = "ErrorLog";
        const string DiUniversalAdapterRuntimeServiceLogFile = "DiUniversalAdapterRutimeServiceLog.txt";

        //const string LogFolder = "\\Log\\";
        const string RuntimeProcessLogFile = "DiUniversalAdapterRuntimeProcessLog.txt";

        private static readonly object SyncLock = new object();


        public static void HandleException(StreamWriter outputStream, Exception ex)
        {

            try
            {
                lock (SyncLock)
                {
                    if (outputStream == null)
                    {
                        string outputStreamFile = GetLogFile();

                        File.AppendAllText(outputStreamFile, GetOutputContent(ex));

                    }
                    else
                    {
                        Console.SetOut(outputStream);
                        Console.Out.WriteLine(GetOutputContent(ex));
                    }
                }

            }
            catch (Exception)
            {
                //Nothing to do witht he exception
            }
        }

        private static string GetDefaultOutputStreamFile()
        {
            string serviceLogFolder = AppSettings.GetAppSetting("DiUniversalAdapterServiceLogFolder");
            //string serviceLogFolder = ConfigurationManager.AppSettings["DiUniversalAdapterServiceLogFolder"];
            if (string.IsNullOrEmpty(serviceLogFolder))
            {
                serviceLogFolder = @"C:\DiCentral\DiUniversalAdapter\Logs";
            }

            string DiUniversalAdapterErrorPath = Path.Combine(serviceLogFolder, DiUniversalAdapterRuntimeServiceErrorLogFolder);
            if (!Directory.Exists(DiUniversalAdapterErrorPath))
            {
                Directory.CreateDirectory(DiUniversalAdapterErrorPath);
            }

            return Path.Combine(DiUniversalAdapterErrorPath, DiUniversalAdapterRuntimeServiceLogFile);
        }

        private static string GetLogFile()
        {
            //string LoggingFolder = Environment.CurrentDirectory + LogFolder;
            //string LoggingFolder = Path.Combine(HostingEnvironment.ApplicationPhysicalPath, LogFolder);
           
            //string serviceLogFolder = ConfigurationManager.AppSettings["DiUniversalAdapterServiceLogFolder"];
            string serviceLogFolder = AppSettings.GetAppSetting("DiUniversalAdapterServiceLogFolder");
            if (string.IsNullOrEmpty(serviceLogFolder))
            {
                serviceLogFolder = @"C:\DiCentral\DiUniversalAdapter\Logs";
            }

            if (!Directory.Exists(serviceLogFolder))
            {
                try
                {
                    Directory.CreateDirectory(serviceLogFolder);
                }
                catch (Exception)
                {
                    //throw;
                }
            }

            return Path.Combine(serviceLogFolder, RuntimeProcessLogFile);
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        private static StreamWriter createDefaultOutputStream()
        {
            StreamWriter outStream = null;
           string serviceLogFolder = AppSettings.GetAppSetting("DiUniversalAdapterServiceLogFolder");
            //string serviceLogFolder = ConfigurationManager.AppSettings["DiUniversalAdapterServiceLogFolder"];
            if (string.IsNullOrEmpty(serviceLogFolder))
            {
                serviceLogFolder = @"C:\DiCentral\DiUniversalAdapter\Logs";
            }

            string DiUniversalAdapterErrorPath = Path.Combine(serviceLogFolder, DiUniversalAdapterRuntimeServiceErrorLogFolder);
            if (!Directory.Exists(DiUniversalAdapterErrorPath))
            {
                Directory.CreateDirectory(DiUniversalAdapterErrorPath);
            }

            DiUniversalAdapterErrorPath = Path.Combine(DiUniversalAdapterErrorPath, DiUniversalAdapterRuntimeServiceLogFile);
            outStream = new StreamWriter(DiUniversalAdapterErrorPath, true);
            outStream.AutoFlush = true;

            return outStream;

        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public static string GetOutputContent(Exception ex)
        {
            string errorMessage = "{0}{1} : {2}\r\n";
            string innerErrorMessage = "\t{0} \r\n\t\t {1}\r\n";
            string currentDateTime = String.Format("{0:dd/MM/yyyy HH:mm:ss:ffff} ", DateTime.UtcNow);

            DiCIPException cipEx = null;
            DiUniversalAdapterServiceException appEx = null;

            if (ex != null)
            {
                if (ex.GetType() == typeof(DiCIPException))
                {
                    cipEx = (DiCIPException)ex;
                    DateTime currentTime = DateTime.UtcNow;

                    errorMessage = string.Format(errorMessage, currentDateTime, ex.GetType().Name, cipEx.ErrorMessage);

                    //Get Inner exceptions
                    List<DiCIPException> innerExceptions = cipEx.GetInnerErrors();
                    if (innerExceptions != null)
                    {
                        foreach (DiCIPException innerEx in innerExceptions)
                        {
                            string stackTrace = "";
                            if ((innerEx != null) && (!String.IsNullOrEmpty(innerEx.ErrorStackTrace)))
                            {
                                stackTrace = innerEx.ErrorStackTrace;
                            }
                            string innerError = string.Format(innerErrorMessage, innerEx.ErrorMessage, stackTrace);
                            errorMessage += innerError;
                        }
                    }
                }
                else if (ex.GetType() == typeof(DiUniversalAdapterServiceException))
                {

                    appEx = (DiUniversalAdapterServiceException)ex;
                    errorMessage = string.Format(errorMessage, currentDateTime, appEx.GetType().Name, appEx.ErrorMessage);

                    string stackTrace = "";
                    if (!String.IsNullOrEmpty(appEx.ErrorStackTrace))
                    {
                        stackTrace = appEx.ErrorStackTrace;
                    }
                    errorMessage += string.Format(innerErrorMessage, appEx.ErrorMessage, stackTrace);

                    if (appEx.InnerException != null)
                    {
                        if (!String.IsNullOrEmpty(appEx.InnerException.StackTrace))
                        {
                            stackTrace = appEx.InnerException.StackTrace;
                        }
                        errorMessage += string.Format(innerErrorMessage, appEx.InnerException.Message, stackTrace);
                    }
                }
                else
                {
                    errorMessage = string.Format(errorMessage, currentDateTime, ex.GetType().Name, ex.Message);
                    if (ex.StackTrace != null)
                    {
                        errorMessage += string.Format(innerErrorMessage, ex.Message, ex.StackTrace.ToString());
                    }
                }

            }

            return errorMessage += "\r\n";
        }
    }
}
