﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiUniversalAdapter.Common.Helper
{
    public class AppSettings
    {
        public static string GetAppSetting(string key)
        {
            //var config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            //return config.AppSettings.Settings[key].Value;
            return ConfigurationManager.AppSettings[key];
        }
        public static string GetAppSetting(string group, string key)
        {
            NameValueCollection coll = (NameValueCollection)ConfigurationManager.GetSection(group);
            return coll[key];
        }
    }
}
