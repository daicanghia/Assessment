﻿using DiUniversalAdapter.Common.Models;
using System;
using DiCIP.Common.Configuration;
using DiCIP.Common.Models.Message;
using DiCIP.Common.Models.Message.DiUniversalAdapter;
using DiCIP.Services.QueuingService;
using DiCIP.Common.AppException;
using DiUniversalAdapter.Common.AppException;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace DiUniversalAdapter.Common.Helper
{
    public class DiUniversalAdapterQueuingHelper
    {
        private static readonly DiUniversalAdapterQueuingHelper _instance = new DiUniversalAdapterQueuingHelper();
        public static DiUniversalAdapterQueuingHelper GetQueuingHelperInstance()
        {
            return _instance;
        }
        /**
 * Send result to outboud queue
 */
        public string DeliverResult(RequestResult theResult)
        {
            try
            {
                string messageId = null;

                IQueuingService queuingService = new QueuingService();
                ICIPMessage message2Send = new DiUniversalAdapterMessage(theResult.RequestGuid, (CIPMessageBody)theResult);

                //Send to Outbound queue
                messageId = queuingService.SendMessage(CIPServices.DiUniversalAdapter, CIPQueues.Outbound, message2Send);

                //Console.Out.WriteLine(String.Format("Request Message ID: {0} -- Result Message ID: {1}\n", theResult.TheRequest.messageId, messageId));

                return messageId;

            }
            catch (DiCIPException)
            {
                throw;
            }
            catch (Exception sysEx)
            {
                throw new DiUniversalAdapterServiceException("Cannot send request result to Outbound queue", sysEx);
            }
        }

        /// <summary>
        /// Send result to Collaborative queue
        /// </summary>
        /// <param name="theResult"></param>
        /// <returns></returns>
        public string DeliverCollaborativeResult(RequestResult theResult)
        {
            try
            {
                string messageId = null;

                IQueuingService queuingService = new QueuingService();
                ICIPMessage message2Send = new DiUniversalAdapterMessage(theResult.RequestGuid, (CIPMessageBody)theResult);

                //Send to Collaborative queue
                messageId = queuingService.SendMessage(CIPServices.DiUniversalAdapter, CIPQueues.Collaboration, message2Send);

                return messageId;

            }
            catch (DiCIPException)
            {
                throw;
            }
            catch (Exception sysEx)
            {
                throw new DiUniversalAdapterServiceException("Cannot send request result to Collaborative queue", sysEx);
            }
        }

        /**
        * Send result to Error queue
        */
        public string DeliverError(RequestError theError)
        {
            string messageId = null;
            try
            {
                IQueuingService queuingService = new QueuingService();

                ICIPMessage message2Send = new DiUniversalAdapterMessage(theError.TheRequest.RequestGuid, (CIPMessageBody)theError);

                //Send to Outbound queue
                //DeliverResult(theError.TheResult);

                //Send to Error queue
                messageId = queuingService.SendMessage(CIPServices.DiUniversalAdapter, CIPQueues.Error, message2Send);

                return messageId;

            }
            catch (DiCIPException)
            {
                throw;
            }
            catch (Exception sysEx)
            {
                throw new DiUniversalAdapterServiceException("Cannot send error result to queue", sysEx);
            }
        }

        /**
        * Get result from queue by given message id
        */
        public RequestResult RetrieveResultByMessageId(string messageId)
        {
            RequestResult theresult = null;
            try
            {
                IQueuingService queuingService = new QueuingService();

                ICIPMessage messageReceived = queuingService.RetrieveMessageByMesssageId(CIPServices.DiUniversalAdapter, CIPQueues.Outbound, messageId);

                if (messageReceived != null)
                {
                    CIPMessageBody body = messageReceived.GetBody();
                    if (body != null)
                    {
                        theresult = (RequestResult)body;
                    }
                }
            }
            catch (DiCIPException cipEx)
            {
                if ((cipEx.MessageQueueErrorCode == QueueErrorCode.EmptyQueue) || (cipEx.MessageQueueErrorCode == QueueErrorCode.MessageNotFound))
                {
                    return null;
                }
                else
                {
                    throw;
                }
            }
            catch (Exception)
            {
                throw;
            }

            return theresult;
        }

        /**
        * Get result from queue by given request guid
        */
        public RequestResult RetrieveResult(string requestGuid)
        {
            RequestResult theresult = null;
            try
            {
                IQueuingService queuingService = new QueuingService();
                ICIPMessage messageReceived = queuingService.RetrieveMessage(CIPServices.DiUniversalAdapter, CIPQueues.Outbound, requestGuid);

                if (messageReceived != null)
                {
                    CIPMessageBody body = messageReceived.GetBody();
                    if (body != null)
                    {
                        theresult = (RequestResult)body;
                    }
                }
            }
            catch (DiCIPException cipEx)
            {
                if (cipEx.MessageQueueErrorCode == QueueErrorCode.EmptyQueue)
                {
                    return null;
                }
                else
                {
                    throw;
                }
            }
            catch (Exception)
            {
                throw;
            }

            return theresult;
        }

        public RequestResult RetrieveResultByRequestId(string requestGuid)
        {
            RequestResult theresult = null;
            try
            {
                IQueuingService queuingService = new QueuingService();
                ICIPMessage messageReceived = queuingService.RetrieveMessageByRequestId(CIPServices.DiUniversalAdapter, CIPQueues.Outbound, requestGuid);

                if (messageReceived != null)
                {
                    CIPMessageBody body = messageReceived.GetBody();
                    if (body != null)
                    {
                        theresult = (RequestResult)body;
                    }
                }
            }
            catch (DiCIPException cipEx)
            {
                if (cipEx.MessageQueueErrorCode == QueueErrorCode.EmptyQueue)
                {
                    return null;
                }
                else
                {
                    throw;
                }
            }
            catch (Exception)
            {
                throw;
            }

            return theresult;

        }

        /**
        * Receive a message from outbound queue
        */
        public ICIPMessage ReceiveResultMessage()
        {
            try
            {
                IQueuingService queuingService = new QueuingService();
                ICIPMessage theResultMessage = queuingService.ReceiveMessage(CIPServices.DiUniversalAdapter, CIPQueues.Outbound);
                return theResultMessage;
            }
            catch (DiCIPException cipEx)
            {
                //Queue is empty
                if (cipEx.MessageQueueErrorCode == QueueErrorCode.EmptyQueue)
                {
                    return null;
                }
                else
                {
                    throw;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        /**
         * Receive a message from inbound queue
         */
        public Request ReceiveRequest()
        {
            Request theRequest = null;
            try
            {
                IQueuingService queuingService = new QueuingService();
                ICIPMessage messageReceived = queuingService.ReceiveMessage(CIPServices.DiUniversalAdapter, CIPQueues.Inbound);

                if (messageReceived != null)
                {
                    CIPMessageBody body = messageReceived.GetBody();
                    if (body != null && body.MessageBody != null)
                    {
                        theRequest = JsonConvert.DeserializeObject<Request>(body.MessageBody.ToString());
                        theRequest.messageId = messageReceived.GetMessageID();
                    }
                }
            }
            catch (DiCIPException cipEx)
            {
                //Queue is empty
                if (cipEx.MessageQueueErrorCode == QueueErrorCode.EmptyQueue)
                {
                    return null;
                }
                else
                {
                    throw;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return theRequest;
        }

        public Request ReceiveCollaborativeRequest()
        {
            Request theRequest = null;
            try
            {
                IQueuingService queuingService = new QueuingService();
                ICIPMessage messageReceived = queuingService.ReceiveMessage(CIPServices.DiUniversalAdapter, CIPQueues.Collaboration);

                if (messageReceived != null)
                {
                    CIPMessageBody body = messageReceived.GetBody();
                    if (body != null)
                    {
                        theRequest = JsonConvert.DeserializeObject<Request>(body.MessageBody.ToString());
                        theRequest.messageId = messageReceived.GetMessageID();
                    }
                }
            }
            catch (DiCIPException cipEx)
            {
                //Queue is empty
                if (cipEx.MessageQueueErrorCode == QueueErrorCode.EmptyQueue)
                {
                    return null;
                }
                else
                {
                    throw;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return theRequest;
        }

        public string SendRequest(Request request)
        {
            try
            {
                string messageSentId = null;
                ICIPMessage message2Send = new DiUniversalAdapterMessage(request.RequestGuid, (CIPMessageBody)request);

                //Send to Inbound queue
                IQueuingService queuingService = new QueuingService();
                messageSentId = queuingService.SendMessage(CIPServices.DiUniversalAdapter, CIPQueues.Inbound, message2Send);
                return messageSentId;

            }
            catch (DiCIPException)
            {
                throw;
            }
            catch (Exception sysEx)
            {
                throw new DiUniversalAdapterServiceException("Cannot send request to Inbound queue", sysEx);
            }
        }
        public void SendRequest(List<Request> requests)
        {
            try
            {
                if (requests != null && requests.Count > 0)
                {
                    List<ICIPMessage> messList = new List<ICIPMessage>();
                    foreach (var request in requests)
                    {
                        ICIPMessage message2Send = new DiUniversalAdapterMessage(request.RequestGuid, (CIPMessageBody)request);
                        messList.Add(message2Send);
                    }

                    //Send to Inbound queue
                    IQueuingService queuingService = new QueuingService();
                    queuingService.SendMessages(CIPServices.DiUniversalAdapter, CIPQueues.Inbound, messList);
                }
            }
            catch (DiCIPException)
            {
                throw;
            }
            catch (Exception sysEx)
            {
                throw new DiUniversalAdapterServiceException("Cannot send request to Inbound queue", sysEx);
            }
        }

        public string SendCollaborationRequest(Request request)
        {
            try
            {
                string messageSentId = null;
                ICIPMessage message2Send = new DiUniversalAdapterMessage(request.RequestGuid, (CIPMessageBody)request);

                //Send to Collaboration queue
                IQueuingService queuingService = new QueuingService();
                messageSentId = queuingService.SendMessage(CIPServices.DiUniversalAdapter, CIPQueues.Collaboration, message2Send);
                return messageSentId;

            }
            catch (DiCIPException)
            {
                throw;
            }
            catch (Exception sysEx)
            {
                throw new DiUniversalAdapterServiceException("Cannot send request to Collaboration queue", sysEx);
            }
        }

    }
}
