﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace DiUniversalAdapter.Common.Helper
{
    public class DiUniversalAdapterServicesLogger
    {
        protected static string RuntimeDebuggingFolder = "Debug";
        protected static string RuntimeDebuggingFile = "DiUniversalAdapterRuntimeServiceDebugging.txt";

        private static readonly object SyncLock = new object();


        [MethodImpl(MethodImplOptions.Synchronized)]
        public static void LogInfo(string info, DateTime timeNow, bool log)
        {
            if (log)
            {
                try
                {
                    lock (SyncLock)
                    {
                        string logFilePath = GetDebugFile();

                        string timeNowFormat = "";
                        if (timeNow == null)
                        {
                            timeNowFormat = String.Format("{0:dd/MM/yyyy HH:mm:ss:ffff} ", DateTime.UtcNow);
                        }
                        else
                        {
                            timeNowFormat = String.Format("{0:dd/MM/yyyy HH:mm:ss:ffff} ", timeNow);
                        }
                        info = timeNowFormat + info + Environment.NewLine;

                        File.AppendAllText(logFilePath, info);
                    }
                }
                catch (Exception)
                {
                    //Nothing to do if exception occurs!
                }
            }
        }

        private static string GetDebugFile()
        {
            string serviceLogFolder = ConfigurationManager.AppSettings["DiUniversalAdapterServiceLogFolder"];
            if (string.IsNullOrEmpty(serviceLogFolder))
            {
                serviceLogFolder = @"C:\DiCentral\DiUniversalAdapter\Logs";
            }

            string debuggingFolder = Path.Combine(serviceLogFolder, RuntimeDebuggingFolder);
            if (!Directory.Exists(debuggingFolder))
            {
                try
                {
                    Directory.CreateDirectory(debuggingFolder);
                }
                catch (Exception)
                {
                    //Nothing to do with this condition
                }
            }

            return Path.Combine(debuggingFolder, RuntimeDebuggingFile);
        }
    }
}
