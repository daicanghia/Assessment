﻿using DiCIP.Common.AppException;
using DiCIP.Common.Configuration;
using DiCIP.Services.QueuingService;
using DiUniversalAdapter.Common.AppException;
using DiUniversalAdapter.Common.Configuration;
using DiUniversalAdapter.Common.Delivery;
using DiUniversalAdapter.Common.ExceptionHandler;
using DiUniversalAdapter.Common.Helper;
using DiUniversalAdapter.Common.RuntimeContainer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace DiUniversalAdapter.Common.Helper
{
    public class DiUniversalAdapterServiceHelper
    {
        public DiUniversalAdapterServiceHelper()
        {

        }
        public int InitializeDiUniversalAdapterRuntimeContainer()
        {
            //Get application configuration
            var runtimeSetthings = ReadRuntimeAppSettings();
            return InitializeDiUniversalAdapterRuntimeContainer(runtimeSetthings);
        }

        public int InitializeDiUniversalAdapterRunningContainer()
        {
            //Get application configuration
            var runningSetthings = ReadRunningAppSettings();
            return InitializeDiUniversalAdapterRunningContainer(runningSetthings);
        }

        #region Runtime

        public int InitializeDiUniversalAdapterRuntimeContainer(IProcessSettings runtimeSetthings)
        {

            DiUniversalAdapterServicesLogger.LogInfo("Starting DiUniversalAdapter Runtime Container...\r\n", DateTime.Now, true);

            bool cont = true;

            if (runtimeSetthings == null)
            {
                cont = false;
            }

            //Initialize CIP Queuing Service
            if (cont)
            {
                try
                {
                    DiUniversalAdapterServicesLogger.LogInfo("\tStart DiUniversalAdapter Queuing Service...", DateTime.UtcNow, runtimeSetthings.IsDebugMode);

                    InitializeCIPQueuingService(runtimeSetthings);

                    DiUniversalAdapterServicesLogger.LogInfo("\tStart DiUniversalAdapter Queuing Service successfully!\r\n", DateTime.UtcNow, runtimeSetthings.IsDebugMode);


                }
                catch (Exception ex)
                {
                    cont = false;
                    DiUniversalAdapterServicesLogger.LogInfo("\tStart DiUniversalAdapter Queuing Service unsuccessfully!\r\n", DateTime.UtcNow, runtimeSetthings.IsDebugMode);

                    DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("Cannot Initialize CIP Queuing Service!", ex));
                }
            }


            //Initilize DiUniversalAdapter Runtime Container
            if (cont)
            {
                try
                {
                    DiUniversalAdapterServicesLogger.LogInfo("\tStarting DiUniversalAdapter Runtime Container Manager...", DateTime.UtcNow, runtimeSetthings.IsDebugMode);

                    RuntimeContainerManager.GetInstance().Initialize(runtimeSetthings);

                    DiUniversalAdapterServicesLogger.LogInfo("\tStarted DiUniversalAdapter Runtime Container Manager successfully!\r\n", DateTime.UtcNow, runtimeSetthings.IsDebugMode);

                }
                catch (DiUniversalAdapterServiceException appEx)
                {
                    cont = false;
                    DiUniversalAdapterServicesLogger.LogInfo("\tStarted DiUniversalAdapter Runtime Container Manager unsuccessfully!\r\n", DateTime.UtcNow, runtimeSetthings.IsDebugMode);
                    DiUniversalAdapterExceptionHandler.HandleException(null, appEx);

                }
                catch (Exception ex)
                {
                    cont = false;
                    DiUniversalAdapterServicesLogger.LogInfo("\tStarted DiUniversalAdapter Runtime Container Manager unsuccessfully!\r\n", DateTime.UtcNow, runtimeSetthings.IsDebugMode);

                    DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("Cannot InitilizeDiUniversalAdapter Runtime Container!", ex));
                }
            }

            //Scheduler DiUniversalAdapter Runtime Container
            if (cont && "on" == runtimeSetthings.SchedulerActive)
            {
                try
                {
                    DiUniversalAdapterServicesLogger.LogInfo("\tStarting Scheduler Runtime  Container Manager...", DateTime.UtcNow, runtimeSetthings.IsDebugMode);

                    SchedulerRuntimeContainerManager.GetInstance().Initialize(runtimeSetthings);

                    DiUniversalAdapterServicesLogger.LogInfo("\tStarted Scheduler Runtime Container Manager successfully!\r\n", DateTime.UtcNow, runtimeSetthings.IsDebugMode);

                }
                catch (DiUniversalAdapterServiceException appEx)
                {
                    cont = false;
                    DiUniversalAdapterServicesLogger.LogInfo("\tStarted Scheduler Runtime Container Manager unsuccessfully!\r\n", DateTime.UtcNow, runtimeSetthings.IsDebugMode);
                    DiUniversalAdapterExceptionHandler.HandleException(null, appEx);

                }
                catch (Exception ex)
                {
                    cont = false;
                    DiUniversalAdapterServicesLogger.LogInfo("\tStarted Scheduler Runtime Container Manager unsuccessfully!\r\n", DateTime.UtcNow, runtimeSetthings.IsDebugMode);

                    DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("Cannot Initilize Scheduler Runtime Container!", ex));
                }
            }

            //if (cont)
            //{
            //    //Start Result Delivery Service
            //    try
            //    {
            //       DiUniversalAdapterServicesLogger.LogInfo("\tStart DiUniversalAdapter Delivery Service...", DateTime.UtcNow, runtimeSetthings.IsDebugMode);

            //       DiUniversalAdapterDeliveryService.StartDeliveryService(runtimeSetthings.ReceivingResultTimerInMillisecons);

            //       DiUniversalAdapterServicesLogger.LogInfo("\tStart DiUniversalAdapter Delivery Service successfully!\r\n", DateTime.UtcNow, runtimeSetthings.IsDebugMode);

            //    }
            //    catch (Exception ex)
            //    {
            //        cont = false;
            //       DiUniversalAdapterServicesLogger.LogInfo("\tStart DiUniversalAdapter Delivery Service unsuccessfully!\r\n", DateTime.UtcNow, runtimeSetthings.IsDebugMode);

            //       DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("Cannot StartDiUniversalAdapter Result Delivery Service!", ex));
            //    }
            //}

            int processCode = (int)RuntimeProcessExitCode.NoError;

            if (cont)
            {
                DiUniversalAdapterServicesLogger.LogInfo("Started DiUniversalAdapter Runtime Container successfully!\r\n", DateTime.UtcNow, true);
            }
            else
            {
                DiUniversalAdapterServicesLogger.LogInfo("Started DiUniversalAdapter Runtime Container unsuccessfully!\r\n", DateTime.UtcNow, true);
                processCode = (int)RuntimeProcessExitCode.CannotStartRuntimeProcess;
            }
            return processCode;
        }

        public void CloseDiUniversalAdapterRuntimeContainer()
        {
            DiUniversalAdapterServicesLogger.LogInfo("Closing DiUniversalAdapter Runtime Container...\r\n", DateTime.UtcNow, true);

            //Close DiUniversalAdapter Runtime Processes
            try
            {
                DiUniversalAdapterServicesLogger.LogInfo("\tStop DiUniversalAdapter Runtime Processes...", DateTime.UtcNow, true);

                RuntimeContainerManager.GetInstance().StopDiUniversalAdapterRuntimeProcess();

                DiUniversalAdapterServicesLogger.LogInfo("\tStopped DiUniversalAdapter Runtime Processes successfully!\r\n", DateTime.UtcNow, true);
            }
            catch (Exception ex)
            {
                DiUniversalAdapterServicesLogger.LogInfo("\tStopped DiUniversalAdapter Runtime Processes unsuccessfully!\r\n", DateTime.UtcNow, true);

                DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("error occurs while shurting downDiUniversalAdapter Runtime processes!", ex));

            }

            //Close Delivery service
            //try
            //{
            //   DiUniversalAdapterServicesLogger.LogInfo("\tStop Delivery Service...", DateTime.UtcNow, true);

            //   DiUniversalAdapterDeliveryService.StopDeliveryService();

            //   DiUniversalAdapterServicesLogger.LogInfo("\tStopped Delivery Service successfully!\r\n", DateTime.UtcNow, true);
            //}
            //catch (Exception ex)
            //{
            //   DiUniversalAdapterServicesLogger.LogInfo("\tStopped Delivery Service unsuccessfully!\r\n", DateTime.UtcNow, true);

            //   DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("error occurs while shurting down Delivery Service!", ex));
            //}


            try
            {
                DiUniversalAdapterServicesLogger.LogInfo("\tStop Schedule Service...", DateTime.UtcNow, true);

                SchedulerRuntimeContainerManager.GetInstance().StopSchedulerRuntimeProcess();

                DiUniversalAdapterServicesLogger.LogInfo("\tStopped Schedule Service successfully!\r\n", DateTime.UtcNow, true);
            }
            catch (Exception ex)
            {
                DiUniversalAdapterServicesLogger.LogInfo("\tStopped Schedule Service unsuccessfully!\r\n", DateTime.UtcNow, true);

                DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("error occurs while shurting down Delivery Service!", ex));
            }



            //Close CIP queuing service
            try
            {
                DiUniversalAdapterServicesLogger.LogInfo("\tStop CIP Queuing Service...", DateTime.UtcNow, true);

                CloseCIPQueuingService();

                DiUniversalAdapterServicesLogger.LogInfo("\tStopped CIP Queuing Service successfully!\r\n", DateTime.UtcNow, true);
            }
            catch (Exception ex)
            {
                DiUniversalAdapterServicesLogger.LogInfo("\tStopped CIP Queuing Service unsuccessfully!\r\n", DateTime.UtcNow, true);

                DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("error occurs while shurting downDiUniversalAdapter Runtime Service!", ex));
            }

            DiUniversalAdapterServicesLogger.LogInfo("Closed DiUniversalAdapter Runtime Container successfully!\r\n", DateTime.UtcNow, true);


        }

        private RuntimeProcessSettings ReadRuntimeAppSettings()
        {
            RuntimeProcessSettings runtimeSetthings = null;
            try
            {
                DiUniversalAdapterServicesLogger.LogInfo("\tStart reading settings from app configuration file.", DateTime.UtcNow, true);

                runtimeSetthings = new RuntimeProcessSettings();
                runtimeSetthings.MaxRuntimeProcesses = Int32.Parse(AppSettings.GetAppSetting(RuntimeAppSettings.MaxRuntimeProcesses.ToString()));
                runtimeSetthings.ProcessFileName = AppSettings.GetAppSetting(RuntimeAppSettings.SchedulerRuntimeProcessFileName.ToString());
                runtimeSetthings.Processes = Int32.Parse(AppSettings.GetAppSetting(RuntimeAppSettings.SchedulerRuntimeProcesses.ToString()));
                runtimeSetthings.RuntimeProcessFileName = AppSettings.GetAppSetting(RuntimeAppSettings.RuntimeProcessFileName.ToString());
                runtimeSetthings.RuntimeProcesses = Int32.Parse(AppSettings.GetAppSetting(RuntimeAppSettings.RuntimeProcesses.ToString()));
                runtimeSetthings.RuntimeStartThreads = Int32.Parse(AppSettings.GetAppSetting(RuntimeAppSettings.RuntimeStartThreads.ToString()));
                runtimeSetthings.InboundQueue = AppSettings.GetAppSetting(RuntimeAppSettings.InboundQueue.ToString());
                runtimeSetthings.OutboundQueue = AppSettings.GetAppSetting(RuntimeAppSettings.OutboundQueue.ToString());
                runtimeSetthings.ErrorQueue = AppSettings.GetAppSetting(RuntimeAppSettings.ErrorQueue.ToString());
                runtimeSetthings.CollaborativeQueue = AppSettings.GetAppSetting(RuntimeAppSettings.CollaborativeQueue.ToString());

                
                try
                {
                    //runtimeSetthings.TimerInMillisecons = int.Parse(AppSettings.GetAppSetting(RuntimeAppSettings.SchedulerReceivingRequestTimerInMillisecons.ToString()));
                    var minInterval = int.Parse(AppSettings.GetAppSetting(RuntimeAppSettings.SchedulerReceivingRequestTimerInMilliseconsMin.ToString()));
                    var maxInterval = int.Parse(AppSettings.GetAppSetting(RuntimeAppSettings.SchedulerReceivingRequestTimerInMilliseconsMax.ToString()));

                    var avgInterval = new Random().Next(minInterval, maxInterval);
                    runtimeSetthings.TimerInMillisecons = avgInterval;
                }
                catch (Exception)
                {
                    runtimeSetthings.TimerInMillisecons = 1000;
                }

                try
                {
                    runtimeSetthings.ReceivingRequestTimerInMillisecons = int.Parse(AppSettings.GetAppSetting(RuntimeAppSettings.ReceivingRequestTimerInMillisecons.ToString()));
                }
                catch (Exception)
                {
                    //Invalid data configured. default to 100 millisoconds
                    runtimeSetthings.ReceivingRequestTimerInMillisecons = 100;
                }

                try
                {
                    runtimeSetthings.ReceivingResultTimerInMillisecons = int.Parse(AppSettings.GetAppSetting(RuntimeAppSettings.ReceivingResultTimerInMillisecons.ToString()));
                }
                catch (Exception)
                {
                    //Invalid data configured. default to 100 millisoconds
                    runtimeSetthings.ReceivingResultTimerInMillisecons = 100;
                }
               
                //Get debug setting
                try
                {
                    //read parameters from app configure file
                    int debug = Int32.Parse(AppSettings.GetAppSetting(RuntimeAppSettings.Debug.ToString()));
                    runtimeSetthings.IsDebugMode = (debug == 1) ? true : false;

                }
                catch (Exception sysEx)
                {
                    //Logging the exeption
                    DiUniversalAdapterExceptionHandler.HandleException(null,
                                                             new DiUniversalAdapterServiceException("Cannot log information for debugging. Invalide Debug setting reading from app configuration file!", sysEx));
                }
                // set Scheduler active
                try
                {
                    runtimeSetthings.SchedulerActive = AppSettings.GetAppSetting(RuntimeAppSettings.SchedulerActive.ToString());
                }
                catch (Exception)
                {
                    //Invalid data configured. default to 100 millisoconds
                    runtimeSetthings.SchedulerActive = "off";
                }
                DiUniversalAdapterServicesLogger.LogInfo("\tRead settings from app configuration file successfully! \r\n", DateTime.UtcNow, true);

            }
            catch (Exception ex)
            {
                DiUniversalAdapterServicesLogger.LogInfo("\tRead settings from app configuration file unsuccessfully! \r\n", DateTime.UtcNow, true);

                DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("Cannot get application settings from configuration file!", ex));
            }
            return runtimeSetthings;

        }

        #endregion

        #region Running
        public int InitializeDiUniversalAdapterRunningContainer(IProcessSettings runningSetthings)
        {

            DiUniversalAdapterServicesLogger.LogInfo("Starting DiUniversalAdapter Running Container...\r\n", DateTime.Now, true);

            bool cont = true;

            if (runningSetthings == null)
            {
                cont = false;
            }

            //Initialize CIP Queuing Service
            if (cont)
            {
                try
                {
                    DiUniversalAdapterServicesLogger.LogInfo("\tStart DiUniversalAdapter Queuing Service...", DateTime.UtcNow, runningSetthings.IsDebugMode);

                    InitializeCIPQueuingService(runningSetthings);

                    DiUniversalAdapterServicesLogger.LogInfo("\tStart DiUniversalAdapter Queuing Service successfully!\r\n", DateTime.UtcNow, runningSetthings.IsDebugMode);


                }
                catch (Exception ex)
                {
                    cont = false;
                    DiUniversalAdapterServicesLogger.LogInfo("\tStart DiUniversalAdapter Queuing Service unsuccessfully!\r\n", DateTime.UtcNow, runningSetthings.IsDebugMode);

                    DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("Cannot Initialize CIP Queuing Service!", ex));
                }
            }


            //Initilize DiUniversalAdapter Runtime Container
            if (cont)
            {
                try
                {
                    DiUniversalAdapterServicesLogger.LogInfo("\tStarting DiUniversalAdapter Running Container Manager...", DateTime.UtcNow, runningSetthings.IsDebugMode);

                    RuntimeContainerManager.GetInstance().Initialize(runningSetthings);

                    DiUniversalAdapterServicesLogger.LogInfo("\tStarted DiUniversalAdapter Running Container Manager successfully!\r\n", DateTime.UtcNow, runningSetthings.IsDebugMode);

                }
                catch (DiUniversalAdapterServiceException appEx)
                {
                    cont = false;
                    DiUniversalAdapterServicesLogger.LogInfo("\tStarted DiUniversalAdapter Running Container Manager unsuccessfully!\r\n", DateTime.UtcNow, runningSetthings.IsDebugMode);
                    DiUniversalAdapterExceptionHandler.HandleException(null, appEx);

                }
                catch (Exception ex)
                {
                    cont = false;
                    DiUniversalAdapterServicesLogger.LogInfo("\tStarted DiUniversalAdapter Running Container Manager unsuccessfully!\r\n", DateTime.UtcNow, runningSetthings.IsDebugMode);

                    DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("Cannot InitilizeDiUniversalAdapter Runtime Container!", ex));
                }
            }

            //Running DiUniversalAdapter Runtime Container
            if (cont)
            {
                try
                {
                    DiUniversalAdapterServicesLogger.LogInfo("\tStarting Running  Container Manager...", DateTime.UtcNow, runningSetthings.IsDebugMode);

                    SchedulerRuntimeContainerManager.GetInstance().Initialize(runningSetthings);

                    DiUniversalAdapterServicesLogger.LogInfo("\tStarted Running Container Manager successfully!\r\n", DateTime.UtcNow, runningSetthings.IsDebugMode);

                }
                catch (DiUniversalAdapterServiceException appEx)
                {
                    cont = false;
                    DiUniversalAdapterServicesLogger.LogInfo("\tStarted Running Container Manager unsuccessfully!\r\n", DateTime.UtcNow, runningSetthings.IsDebugMode);
                    DiUniversalAdapterExceptionHandler.HandleException(null, appEx);

                }
                catch (Exception ex)
                {
                    cont = false;
                    DiUniversalAdapterServicesLogger.LogInfo("\tStarted Running Container Manager unsuccessfully!\r\n", DateTime.UtcNow, runningSetthings.IsDebugMode);

                    DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("Cannot Initilize Running Container!", ex));
                }
            }

            //if (cont)
            //{
            //    //Start Result Delivery Service
            //    try
            //    {
            //       DiUniversalAdapterServicesLogger.LogInfo("\tStart DiUniversalAdapter Delivery Service...", DateTime.UtcNow, runtimeSetthings.IsDebugMode);

            //       DiUniversalAdapterDeliveryService.StartDeliveryService(runtimeSetthings.ReceivingResultTimerInMillisecons);

            //       DiUniversalAdapterServicesLogger.LogInfo("\tStart DiUniversalAdapter Delivery Service successfully!\r\n", DateTime.UtcNow, runtimeSetthings.IsDebugMode);

            //    }
            //    catch (Exception ex)
            //    {
            //        cont = false;
            //       DiUniversalAdapterServicesLogger.LogInfo("\tStart DiUniversalAdapter Delivery Service unsuccessfully!\r\n", DateTime.UtcNow, runtimeSetthings.IsDebugMode);

            //       DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("Cannot StartDiUniversalAdapter Result Delivery Service!", ex));
            //    }
            //}

            int processCode = (int)RuntimeProcessExitCode.NoError;

            if (cont)
            {
                DiUniversalAdapterServicesLogger.LogInfo("Started DiUniversalAdapter Running Container successfully!\r\n", DateTime.UtcNow, true);
            }
            else
            {
                DiUniversalAdapterServicesLogger.LogInfo("Started DiUniversalAdapter Running Container unsuccessfully!\r\n", DateTime.UtcNow, true);
                processCode = (int)RuntimeProcessExitCode.CannotStartRuntimeProcess;
            }
            return processCode;
        }

        public void CloseDiUniversalAdapterRunningContainer()
        {
            DiUniversalAdapterServicesLogger.LogInfo("Closing DiUniversalAdapter Running Container...\r\n", DateTime.UtcNow, true);

            //Close DiUniversalAdapter Runtime Processes
            try
            {
                DiUniversalAdapterServicesLogger.LogInfo("\tStop DiUniversalAdapter Running Processes...", DateTime.UtcNow, true);

                RuntimeContainerManager.GetInstance().StopDiUniversalAdapterRuntimeProcess();

                DiUniversalAdapterServicesLogger.LogInfo("\tStopped DiUniversalAdapter Running Processes successfully!\r\n", DateTime.UtcNow, true);
            }
            catch (Exception ex)
            {
                DiUniversalAdapterServicesLogger.LogInfo("\tStopped DiUniversalAdapter Running Processes unsuccessfully!\r\n", DateTime.UtcNow, true);

                DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("error occurs while shurting downDiUniversalAdapter Runtime processes!", ex));

            }

            try
            {
                DiUniversalAdapterServicesLogger.LogInfo("\tStop Schedule Service...", DateTime.UtcNow, true);

                SchedulerRuntimeContainerManager.GetInstance().StopSchedulerRuntimeProcess();

                DiUniversalAdapterServicesLogger.LogInfo("\tStopped Schedule Service successfully!\r\n", DateTime.UtcNow, true);
            }
            catch (Exception ex)
            {
                DiUniversalAdapterServicesLogger.LogInfo("\tStopped Schedule Service unsuccessfully!\r\n", DateTime.UtcNow, true);

                DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("error occurs while shurting down Delivery Service!", ex));
            }



            //Close CIP queuing service
            try
            {
                DiUniversalAdapterServicesLogger.LogInfo("\tStop CIP Queuing Service...", DateTime.UtcNow, true);

                CloseCIPQueuingService();

                DiUniversalAdapterServicesLogger.LogInfo("\tStopped CIP Queuing Service successfully!\r\n", DateTime.UtcNow, true);
            }
            catch (Exception ex)
            {
                DiUniversalAdapterServicesLogger.LogInfo("\tStopped CIP Queuing Service unsuccessfully!\r\n", DateTime.UtcNow, true);

                DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("error occurs while shurting downDiUniversalAdapter Runtime Service!", ex));
            }

            DiUniversalAdapterServicesLogger.LogInfo("Closed DiUniversalAdapter Running Container successfully!\r\n", DateTime.UtcNow, true);


        }

        private RunningProcessSettings ReadRunningAppSettings()
        {
            RunningProcessSettings runningSetthings = null;
            try
            {
                DiUniversalAdapterServicesLogger.LogInfo("\tStart reading settings from app configuration file.", DateTime.UtcNow, true);

                runningSetthings = new RunningProcessSettings();
                runningSetthings.MaxRuntimeProcesses = Int32.Parse(AppSettings.GetAppSetting(RuntimeAppSettings.MaxRuntimeProcesses.ToString()));
                runningSetthings.ProcessFileName = AppSettings.GetAppSetting(RuntimeAppSettings.RunningProcessFileName.ToString());
                runningSetthings.Processes = Int32.Parse(AppSettings.GetAppSetting(RuntimeAppSettings.RunningProcesses.ToString()));
                runningSetthings.RuntimeProcessFileName = AppSettings.GetAppSetting(RuntimeAppSettings.RuntimeProcessFileName.ToString());
                runningSetthings.RuntimeProcesses = Int32.Parse(AppSettings.GetAppSetting(RuntimeAppSettings.RuntimeProcesses.ToString()));
                runningSetthings.RuntimeStartThreads = Int32.Parse(AppSettings.GetAppSetting(RuntimeAppSettings.RuntimeStartThreads.ToString()));
                runningSetthings.InboundQueue = AppSettings.GetAppSetting(RuntimeAppSettings.InboundQueue.ToString());
                runningSetthings.OutboundQueue = AppSettings.GetAppSetting(RuntimeAppSettings.OutboundQueue.ToString());
                runningSetthings.ErrorQueue = AppSettings.GetAppSetting(RuntimeAppSettings.ErrorQueue.ToString());
                runningSetthings.CollaborativeQueue = AppSettings.GetAppSetting(RuntimeAppSettings.CollaborativeQueue.ToString());
                try
                {
                    runningSetthings.ReceivingRequestTimerInMillisecons = int.Parse(AppSettings.GetAppSetting(RuntimeAppSettings.ReceivingRequestTimerInMillisecons.ToString()));
                }
                catch (Exception)
                {
                    //Invalid data configured. default to 100 millisoconds
                    runningSetthings.ReceivingRequestTimerInMillisecons = 100;
                }

                try
                {
                    runningSetthings.ReceivingResultTimerInMillisecons = int.Parse(AppSettings.GetAppSetting(RuntimeAppSettings.ReceivingResultTimerInMillisecons.ToString()));
                }
                catch (Exception)
                {
                    //Invalid data configured. default to 100 millisoconds
                    runningSetthings.ReceivingResultTimerInMillisecons = 100;
                }
                try
                {
                    runningSetthings.TimerInMillisecons = int.Parse(AppSettings.GetAppSetting(RuntimeAppSettings.SchedulerReceivingRequestTimerInMillisecons.ToString()));
                }
                catch (Exception)
                {
                    runningSetthings.TimerInMillisecons = 1000;
                }

                //Get debug setting
                try
                {
                    //read parameters from app configure file
                    int debug = Int32.Parse(AppSettings.GetAppSetting(RuntimeAppSettings.Debug.ToString()));
                    runningSetthings.IsDebugMode = (debug == 1);

                }
                catch (Exception sysEx)
                {
                    //Logging the exeption
                    DiUniversalAdapterExceptionHandler.HandleException(null,
                                                             new DiUniversalAdapterServiceException("Cannot log information for debugging. Invalide Debug setting reading from app configuration file!", sysEx));
                }
                DiUniversalAdapterServicesLogger.LogInfo("\tRead settings from app configuration file successfully! \r\n", DateTime.UtcNow, true);

            }
            catch (Exception ex)
            {
                DiUniversalAdapterServicesLogger.LogInfo("\tRead settings from app configuration file unsuccessfully! \r\n", DateTime.UtcNow, true);

                DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("Cannot get application settings from configuration file!", ex));
            }
            return runningSetthings;

        }

        #endregion End Running



        public string GenerateParameters(IProcessSettings settings)
        {
            string arguments = string.Format("{0},{1},{2},{3},{4},{5},{6},{7}",
                                            settings.ProcessID,
                                            settings.InboundQueue,
                                            settings.OutboundQueue,
                                            settings.ErrorQueue,
                                            settings.CollaborativeQueue,
                                            settings.ReceivingRequestTimerInMillisecons.ToString(),
                                            settings.TimerInMillisecons.ToString(),
                                            settings.RuntimeStartThreads.ToString()
                                            );

            return arguments;
        }

        private void CloseCIPQueuingService()
        {
            try
            {
                IQueuingService queuingService = new QueuingService();
                List<CIPServices> services2Stop = new List<CIPServices>();
                services2Stop.Add(CIPServices.DiUniversalAdapter);

                queuingService.StopQueuingService(services2Stop);
            }
            catch (Exception)
            {
                throw;
            }


        }
        private void InitializeCIPQueuingService(IProcessSettings runtimesettings)
        {
            List<DiCIP.Common.Configuration.ISetting> settings = new List<ISetting>();
            try
            {

                //foreach (string key in Enum.GetNames(typeof(CIPMessageType)))
                DiCIP.Common.Configuration.ISetting setting = null;
                foreach (DiCIP.Common.Configuration.CIPMessageType messageType in Enum.GetValues(typeof(DiCIP.Common.Configuration.CIPMessageType)))
                {

                    switch (messageType)
                    {
                        case CIPMessageType.Inbound:
                            setting = new Setting(new KeyValuePair<string, string>(CIPMessageType.Inbound.ToString(), runtimesettings.InboundQueue));
                            settings.Add(setting);
                            break;
                        case CIPMessageType.Outbound:
                            setting = new Setting(new KeyValuePair<string, string>(CIPMessageType.Outbound.ToString(), runtimesettings.OutboundQueue));
                            settings.Add(setting);
                            break;
                        case CIPMessageType.Error:
                            setting = new Setting(new KeyValuePair<string, string>(CIPMessageType.Error.ToString(), runtimesettings.ErrorQueue));
                            settings.Add(setting);
                            break;
                        case CIPMessageType.Collaboration:
                            setting = new Setting(new KeyValuePair<string, string>(CIPMessageType.Collaboration.ToString(), runtimesettings.CollaborativeQueue));
                            settings.Add(setting);
                            break;
                    }
                }


                //DiCIP.Common.Configuration.IConfiguration serviceConfigure = new DiUniversalAdapterConfigure(settings);
                //List<KeyValuePair<string, ICIPConfiguration>> services2Start

                //List<KeyValuePair<string, IConfiguration>> config = new List<KeyValuePair<string, IConfiguration>>();
                //config.Add(new KeyValuePair<string, IConfiguration>(CIPService.DiUniversalAdapter.ToString(), serviceConfigure));

                //IQueuingService queuingService = new QueuingService();
                //queuingService.InitQueuingService(config);
                var serviceConfigure = new DiUniversalAdapterConfigure(settings);
                List<KeyValuePair<string, ICIPConfiguration>>  config = new List<KeyValuePair<string, ICIPConfiguration>>();
                config.Add(new KeyValuePair<string, ICIPConfiguration>(CIPServices.DiUniversalAdapter.ToString(), serviceConfigure));

                IQueuingService queuingService = new QueuingService();
                queuingService.InitQueuingService(config);

            }
            catch (DiCIPException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}