﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace DiUniversalAdapter.Common.Helper
{
    public class DiUniversalAdapterRuntimeLogger
    {
        protected static string RuntimeDebuggingFolder = "Debug";
        protected static string RuntimeDebuggingFile = "DiUniversalAdapterRuntimeProcessDebugging{0}.txt";

        private static readonly object SyncLock = new object();

        [MethodImpl(MethodImplOptions.Synchronized)]
        public static void LogInfo(string processId, string info, bool log)
        {
            if (log)
            {
                try
                {
                    lock (SyncLock)
                    {
                        string logFilePath = GetDebugFile(processId);

                        string timeNow = String.Format("{0:dd/MM/yyyy HH:mm:ss:ffff} ", DateTime.UtcNow);

                        info = timeNow + info + Environment.NewLine;


                        File.AppendAllText(logFilePath, info);
                    }
                }
                catch (Exception)
                {
                    //Nothing to do if exception occurs!
                }
            }
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public static void LogInfo(string processId, string info, DateTime timeNow, bool log)
        {
            if (log)
            {
                try
                {
                    lock (SyncLock)
                    {
                        string logFilePath = GetDebugFile(processId);

                        string timeNowFormat = "";
                        if (timeNow == null)
                        {
                            timeNowFormat = String.Format("{0:dd/MM/yyyy HH:mm:ss:ffff} ", DateTime.UtcNow);
                        }
                        else
                        {
                            timeNowFormat = String.Format("{0:dd/MM/yyyy HH:mm:ss:ffff} ", timeNow);
                        }
                        info = timeNowFormat + info + Environment.NewLine;


                        File.AppendAllText(logFilePath, info);
                    }
                }
                catch (Exception)
                {
                    //Nothing to do if exception occurs!
                }
            }
        }

        private static string GetDebugFile(string processId)
        {
            string serviceLogFolder = ConfigurationManager.AppSettings["DiUniversalAdapterServiceLogFolder"];
            if (string.IsNullOrEmpty(serviceLogFolder))
            {
                serviceLogFolder = @"C:\DiCentral\DiUniversalAdapter\Logs";
            }

            string DebuggingFolder = Path.Combine(serviceLogFolder, RuntimeDebuggingFolder);
            if (!Directory.Exists(DebuggingFolder))
            {
                try
                {
                    Directory.CreateDirectory(DebuggingFolder);
                }
                catch (Exception)
                {
                    //Nothing to do with this condition
                }
            }

            string fileName = RuntimeDebuggingFile;
            if (string.IsNullOrEmpty(processId))
            {
                fileName = string.Format(fileName, "");
            }
            else
            {
                fileName = string.Format(fileName, "_" + processId);
            }

            return Path.Combine(DebuggingFolder, fileName);
        }
    }
}
