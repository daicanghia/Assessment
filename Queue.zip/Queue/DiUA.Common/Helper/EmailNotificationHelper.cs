﻿using DiCIP.Common.Configuration;
using DiUniversalAdapter.Common.AppException;
using DiUniversalAdapter.Common.Communication;
using DiUniversalAdapter.Common.ExceptionHandler;
using DiUniversalAdapter.Common.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using DiUniversalAdapter.Common.Configuration;

namespace DiUniversalAdapter.Common.Helper
{
    public class EmailNotificationHelper
    {
        public void NotifyUsingEmail(NotificationInfo info, string recipients, bool isAsync = true)
        {
            try
            {

                //Send email
                ICommunication emailComm = new CipEmailClient();
                if (isAsync)
                {
                    Thread sendEmailThread = new Thread(() => emailComm.SendNotification(HostInfo.Name + " " + info.Subject, info.Message, recipients));
                    sendEmailThread.IsBackground = false;
                    sendEmailThread.Start();

                }
                else
                {
                    emailComm.SendNotification(info.Subject, info.Message, recipients);
                }

            }
            catch (Exception ex)
            {
                DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("DiUniversalAdapter Service host Error: Cannot send email notification!", ex));
            }
        }

        public NotificationInfo GetProcessStatusNotification(string PID, int processExitCode, CIPService service,
                                                        int noRunningProcess = -1, RuntimeProcessStatus status = RuntimeProcessStatus.Stopped)
        {
            string serviceHostName = this.GetServiceHostName(service);
            string serviceName = this.GetProcessName(service);

            string timeNow = String.Format("{0:dd/MM/yyyy HH:mm:ss:ffff} ", DateTime.UtcNow);
            string message = string.Empty;
            string statusText = this.GetServiceStatus(status);
            switch (status)
            {
                case RuntimeProcessStatus.Stopped:
                    message = string.Format("{0} {1} process {2} {3} with exit code {4} \r\n", timeNow, serviceName, PID, statusText, processExitCode);

                    if (noRunningProcess != -1)
                    {
                        message += string.Format("{0} Total {1} processes are running: {2} .", timeNow, serviceName, noRunningProcess);
                        if (noRunningProcess == 0)
                        {
                            message += string.Format(" Please restart {0} to start new {1} immediately!\r\n", serviceHostName, serviceName);
                        }
                    }
                    break;
                case RuntimeProcessStatus.Started:
                    message = string.Format("{0} {1} process {2} {3} \r\n", timeNow, serviceName, PID, statusText);
                    break;
                case RuntimeProcessStatus.Failed2Start:
                    message = string.Format("{0} {1} process {2}.Please check log file for details. \r\n", timeNow, serviceName, statusText);
                    break;
                default:
                    break;

            }
            string subject = string.Format("{0} {1}", serviceName, statusText);
            return new NotificationInfo(serviceName, subject, message);
        }

        public NotificationInfo GetServiceHostStatusNotification(CIPService service, RuntimeProcessStatus status = RuntimeProcessStatus.Stopped)
        {
            string serviceHostName = this.GetServiceHostName(service);

            string timeNow = String.Format("{0:dd/MM/yyyy HH:mm:ss:ffff} ", DateTime.UtcNow);
            string message = string.Empty;

            string subject = string.Format("{0} {1}", serviceHostName, this.GetServiceStatus(status));

            message = string.Format("{0} {1} {2} \r\n", timeNow, serviceHostName, this.GetServiceStatus(status));

            return new NotificationInfo(serviceHostName, subject, message);
        }

        public string GetErrorEmailMessage(string serviceName, string logFile, Exception ex, CIPNotficationType type = CIPNotficationType.UnhandledException)
        {

            string errorType = string.Empty;
            switch (type)
            {
                case CIPNotficationType.Information:
                    errorType = "Information";
                    break;
                case CIPNotficationType.Error:
                    errorType = "Error";
                    break;
                case CIPNotficationType.Exception:
                    errorType = "Exception";
                    break;
                case CIPNotficationType.UnhandledException:
                    errorType = "UnhandledException ";
                    break;

            }
            string timeNow = String.Format("{0:dd/MM/yyyy HH:mm:ss:ffff} ", DateTime.UtcNow);
            string message = string.Empty;

            //message = string.Format("{0} Unhandled exeption thrown and caught by {1}. Please check log file {2} for details!", timeNow, serviceName, logFile);
            message = string.Format("{0} {1} thrown and caught by {2}. Please check log file {3} for details!", timeNow, errorType, serviceName, logFile);
            if (ex != null)
            {
                //string exCaught = "\r\n<UnhandledException>\r\n\t<Message>{0}</Message>\r\n\t<StackTrace>{1}</StrackTrace>\r\n</UnhandledException>";
                string exCaught = "\r\n<{0}>\r\n\t<Message>{1}</Message>\r\n\t<StackTrace>{2}</StrackTrace>\r\n</{0}>";
                exCaught = string.Format(exCaught, errorType, ex.Message, ex.StackTrace);
                message += exCaught;
            }
            return message;
        }


        public string GetServiceHostName(CIPService service)
        {
            string serviceHostName = "CIP Windows Service Host";
            switch (service)
            {
                case CIPService.DiUniversalAdapter:
                    serviceHostName = "DiUniversalAdapter Windows Service Host";
                    break;
            }
            return serviceHostName;
        }

        public string GetProcessName(CIPService service)
        {
            string serviceName = "CIP Runtime Process";
            switch (service)
            {

                case CIPService.DiUniversalAdapter:
                    serviceName = "DiUniversalAdapter Runtime Process";
                    break;
            }
            return serviceName;
        }

        public string GetServiceStatus(RuntimeProcessStatus status)
        {
            string serviceStatus = status.ToString();
            switch (status)
            {
                case RuntimeProcessStatus.Started:
                    serviceStatus = "started";
                    break;
                case RuntimeProcessStatus.Failed2Start:
                    serviceStatus = "could not start";
                    break;
                case RuntimeProcessStatus.Stopped:
                    serviceStatus = "stopped";
                    break;

            }

            return serviceStatus;
        }

        public string GetRecipients(string defaultRecipients)
        {
            string recipients = "";
            //Default to owner of the code as the last chance :-)!
            if (string.IsNullOrEmpty(defaultRecipients))
            {
                defaultRecipients = "trungdong@dicentral.com";
            }
            try
            {
                recipients = ConfigurationManager.AppSettings[RuntimeAppSettings.NotificationEmails.ToString()];
                if (string.IsNullOrEmpty(recipients))
                {
                    recipients = defaultRecipients;
                }
            }
            catch (Exception sysEx)
            {
                recipients = defaultRecipients;

                string warningMsg = "Cannot read setting {0} from web configuration file. Default setting {1} will be used!";

                warningMsg = string.Format(warningMsg, RuntimeAppSettings.NotificationEmails.ToString(), recipients);

                DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException(warningMsg, sysEx));

            }

            return recipients;
        }
    }
}
