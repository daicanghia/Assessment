﻿using System.Collections.Generic;
using System.Linq;

namespace DiUniversalAdapter.Common.Helper
{
    public class StringHelper
    {
        public const string XmlSchemaDefaultNamespace = "http://www.w3.org/2001/XMLSchema";

        public static List<string> SplitParameters(char[] delimiterChars, string string2Split)
        {
            return (string2Split.Split(delimiterChars)).ToList();
        }
    }
}
