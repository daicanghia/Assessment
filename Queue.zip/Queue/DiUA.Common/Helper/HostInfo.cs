﻿using System.Net;
using System.Net.Sockets;

namespace DiUniversalAdapter.Common.Helper
{
    public class HostInfo
    {
        private static readonly string name = GetLocalIPAddress();
        public static string Name
        {
            get
            {
                return name;
            }
        }

        private static string GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());

            string hostName = string.Empty;
            if (!string.IsNullOrEmpty(host.HostName))
            {
                hostName = host.HostName;
            }

            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return "[" + hostName + "(" + ip.ToString() + ")]";
                }
            }

            return "[" + hostName + "]";
        }
    }
}
