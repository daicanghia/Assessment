﻿using System;
using System.ComponentModel;

namespace DiUniversalAdapter.Common.Worker
{
    /**
     * Using backgroud worker to process data. It is developed as based class
     */
    public abstract class ProcessingWorker : IDisposable
    {
        private bool Disposed { get; set; }
        protected BackgroundWorker Worker;
        protected Exception ErrorException = null;

        protected ProcessingWorker()
        {

        }
        ~ProcessingWorker()
        {
            Dispose(false);
        }
        public void Dispose()
        {
            Dispose(true);

        }
        protected virtual void Dispose(bool disposing)
        {
            if (!this.Disposed)
            {
                if (disposing)
                {
                    if (Worker != null)
                    {
                        this.Worker.Dispose();
                    }

                }
                this.Disposed = true;
            }
        }

        protected void Start()
        {
            this.Worker = new BackgroundWorker();
            this.Worker.DoWork += DoWork;
            this.Worker.RunWorkerCompleted += DoWorkCompleted;
            this.Worker.RunWorkerAsync();
        }
        /**
         * Drived class must implement the method
         */
        protected abstract void DoWork(object sender, DoWorkEventArgs e);


        /**
       * Drived class must implement the method
       */
        protected virtual void DoWorkCompleted(object sender, RunWorkerCompletedEventArgs e)
        {

        }
    }
}
