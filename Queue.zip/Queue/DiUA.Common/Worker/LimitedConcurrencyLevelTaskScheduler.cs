﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DiUniversalAdapter.Common.Worker
{
    /// <summary>
    /// Provides a task scheduler that ensures a maximum concurrency level while
    /// running on top of the ThreadPool.
    /// </summary>
    public class LimitedConcurrencyLevelTaskScheduler : TaskScheduler
    {
        // Indicates whether the current thread is processing work items.
        [ThreadStatic]
        private static bool _currentThreadIsProcessingItems;

        // The list of tasks to be executed  
        private readonly LinkedList<Task> _tasks = new LinkedList<Task>(); // protected by lock(_tasks) 

        private readonly List<Thread> workingThreads = new List<Thread>();

        // The maximum concurrency level allowed by this scheduler.  
        private readonly int _maxDegreeOfParallelism;

        // the cancellation token to cancel working threads
        private readonly CancellationToken _cancelToken;

        // Indicates whether the scheduler is currently processing work items.  
        private volatile int _delegatesQueuedOrRunning = 0;
        //private int _delegatesQueuedOrRunning = 0;

        internal List<Thread> GetWorkingThreads()
        {
            lock (workingThreads)
            {
                return new List<Thread>(workingThreads);
            }
        }

        // Creates a new instance with the specified degree of parallelism.  
        public LimitedConcurrencyLevelTaskScheduler(int maxDegreeOfParallelism, CancellationToken cancelToken)
        {
            if (maxDegreeOfParallelism < 1) throw new ArgumentOutOfRangeException("maxDegreeOfParallelism");
            _maxDegreeOfParallelism = maxDegreeOfParallelism;
            _cancelToken = cancelToken;
        }

        // Queues a task to the scheduler.  
        protected sealed override void QueueTask(Task task)
        {
            // Add the task to the list of tasks to be processed.  If there aren't enough  
            // delegates currently queued or running to process tasks, schedule another.  
            lock (_tasks)
            {
                _tasks.AddLast(task);

                if (_delegatesQueuedOrRunning < _maxDegreeOfParallelism)
                {
                    ++_delegatesQueuedOrRunning;
                    NotifyThreadPoolOfPendingWork();
                }
            }
        }

        // Inform the ThreadPool that there's work to be executed for this scheduler.  
        private void NotifyThreadPoolOfPendingWork()
        {
            var thread = new Thread((state) =>
            {
                //lock (_tasks) Interlocked.Increment(ref _delegatesQueuedOrRunning);

                // Note that the current thread is now processing work items. 
                // This is necessary to enable inlining of tasks into this thread.
                _currentThreadIsProcessingItems = true;

                try
                {
                    // Process all available items in the queue. 
                    while (true)
                    {
                        if (_cancelToken.IsCancellationRequested) break;

                        Task item;
                        lock (_tasks)
                        {
                            // When there are no more items to be processed, 
                            // note that we're done processing, and get out. 
                            if (_tasks.Count == 0)
                            {
                                --_delegatesQueuedOrRunning;
                                //Interlocked.Decrement(ref _delegatesQueuedOrRunning);
                                Trace.WriteLine(Thread.CurrentThread.ManagedThreadId + " " + Thread.CurrentThread.Name + " delegatesQueuedOrRunning: " + _delegatesQueuedOrRunning);
                                break;
                            }

                            // Get the next item from the queue
                            item = _tasks.First.Value;
                            _tasks.RemoveFirst();
                        }

                        // Execute the task we pulled out of the queue 
                        if (!base.TryExecuteTask(item))
                        {
                            Trace.WriteLine(DateTime.UtcNow + "\t" + Thread.CurrentThread.ManagedThreadId + "\tFailed to TryExecuteTask.");
                        }
                        //Thread.Sleep(5000);
                    }
                }
                catch (ThreadAbortException)
                {
                    //ignore
                }
                catch (Exception ex)
                {
                    Trace.WriteLine(Thread.CurrentThread.ManagedThreadId + " EXCEPTION: " + ex.ToString());
                }
                // We're done processing items on the current thread 
                finally
                {
                    _currentThreadIsProcessingItems = false;

                    lock (workingThreads)
                    {
                        workingThreads.Remove(state as Thread);
                    }
                }
            })
            { IsBackground = true, Name = "Worker thread " + _delegatesQueuedOrRunning };

            lock (workingThreads)
            {
                workingThreads.Add(thread);
            }

            thread.Start(thread);
        }

        // Attempts to execute the specified task on the current thread.  
        protected sealed override bool TryExecuteTaskInline(Task task, bool taskWasPreviouslyQueued)
        {
            // If this thread isn't already processing a task, we don't support inlining 
            if (!_currentThreadIsProcessingItems) return false;

            // If the task was previously queued, remove it from the queue 
            if (taskWasPreviouslyQueued)
                // Try to run the task.  
                if (TryDequeue(task))
                    return base.TryExecuteTask(task);
                else
                    return false;
            else
                return base.TryExecuteTask(task);
        }

        // Attempt to remove a previously scheduled task from the scheduler.  
        protected sealed override bool TryDequeue(Task task)
        {
            lock (_tasks) return _tasks.Remove(task);
        }

        // Gets the maximum concurrency level supported by this scheduler.  
        public sealed override int MaximumConcurrencyLevel { get { return _maxDegreeOfParallelism; } }

        // Gets an enumerable of the tasks currently scheduled on this scheduler.  
        protected sealed override IEnumerable<Task> GetScheduledTasks()
        {
            bool lockTaken = false;
            try
            {
                Monitor.TryEnter(_tasks, ref lockTaken);
                if (lockTaken) return _tasks;
                else throw new NotSupportedException();
            }
            finally
            {
                if (lockTaken) Monitor.Exit(_tasks);
            }
        }
    }

    internal class Program
    {
        internal static readonly int MaximumConcurrency = 10;
        internal static CancellationTokenSource CancellationTokenSource = new CancellationTokenSource();
        internal static LimitedConcurrencyLevelTaskScheduler taskScheduler = new LimitedConcurrencyLevelTaskScheduler(MaximumConcurrency, CancellationTokenSource.Token);
        private static TaskFactory factory = new TaskFactory(taskScheduler);

        static void Main(string[] args)
        {
            Trace.Listeners.Add(new TextWriterTraceListener(Console.Out));

            var tasks = new List<Task>();
            for (int i = 0; i < 70; i++)
            {
                var tmpI = i;// avoid closure variable capture issue
                tasks.Add(factory.StartNew(() =>
                {
                    Thread.Sleep(4000);
                    Console.WriteLine(DateTime.UtcNow.ToString() + "\t" + Thread.CurrentThread.ManagedThreadId.ToString() + " " + Thread.CurrentThread.Name + "\tFinished task " + tmpI.ToString());
                }, CancellationTokenSource.Token));
            }
            Console.WriteLine("{0}\tQueued {1} tasks.", DateTime.UtcNow, tasks.Count);
            CancellationTokenSource.CancelAfter(TimeSpan.FromSeconds(6));

            var watch = Stopwatch.StartNew();
            Task t = Task.WhenAll(tasks);
            try
            {
                t.Wait();
            }
            catch (Exception ex)
            {
                Console.WriteLine("\nMessage ---\n{0}", ex.Message);
                Console.WriteLine(
                    "\nHelpLink ---\n{0}", ex.HelpLink);
                Console.WriteLine("\nSource ---\n{0}", ex.Source);
                Console.WriteLine(
                    "\nStackTrace ---\n{0}", ex.StackTrace);
                Console.WriteLine(
                    "\nTargetSite ---\n{0}", ex.TargetSite);
            }
            finally
            {
                watch.Stop();
            }

            if (t.Status == TaskStatus.RanToCompletion)
                Console.WriteLine("All tasks succeeded in {0}.", watch.Elapsed);
            else if (t.Status == TaskStatus.Faulted)
                Console.WriteLine("Some tasks failed after {0}: {1}", watch.Elapsed, t.Exception);

        }
    }

}
