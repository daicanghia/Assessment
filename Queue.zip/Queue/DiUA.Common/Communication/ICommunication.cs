﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiUniversalAdapter.Common.Communication
{
    public interface ICommunication
    {
        void SendNotification(string subject, string body, string To = "");

    }
}
