﻿using DiUniversalAdapter.Common.AppException;
using DiUniversalAdapter.Common.ExceptionHandler;
using System;
using System.Linq;
using System.Net.Mail;

namespace DiUniversalAdapter.Common.Communication
{
    public class CipEmailClient : ICommunication
    {
        /**
         * Send notification synchronously via email
         */
        public void SendNotification(string subject, string body, string recipients)
        {
            MailMessage message = null;
            SmtpClient client = null;
            try
            {
                message = new MailMessage();
                if (!string.IsNullOrEmpty(recipients))
                {
                    recipients = recipients.Replace(",", ";");

                    var listTos = recipients.Split(';');
                    foreach (var to in listTos)
                    {
                        if (to.Contains('@'))
                            message.To.Add(new MailAddress(to));
                    }
                }
                message.Subject = subject;
                message.Body = body;

                using (client = new SmtpClient())
                {
                    client.Send(message);
                }

            }
            catch (Exception sysEx)
            {
                DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("DiUniversalAdapter Service host Error: Cannot send email notification!", sysEx));

            }
        }
    }
}
