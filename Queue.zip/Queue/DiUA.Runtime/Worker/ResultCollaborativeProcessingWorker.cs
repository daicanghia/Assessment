﻿using DiCIP.Common.AppException;
using DiUniversalAdapter.Common.AppException;
using DiUniversalAdapter.Common.ExceptionHandler;
using DiUniversalAdapter.Common.Helper;
using DiUniversalAdapter.Common.Models;
using DiUniversalAdapter.Common.Worker;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiUniversalAdapter.Runtime.Worker
{
    public class ResultCollaborativeProcessingWorker : IDisposable
    {
        bool Disposed { get; set; }
        private RequestResult TheResult { get; set; }
        private RequestError TheError { get; set; }
        private Exception ErrorException = null;

        private bool IsRequestError { get; set; }

        public ResultCollaborativeProcessingWorker(RequestResult theResult)
        {
            this.Disposed = false;
            this.TheResult = theResult;
            this.IsRequestError = false;
        }
        public ResultCollaborativeProcessingWorker(RequestError theError)
        {
            this.Disposed = false;
            this.TheError = theError;
            this.IsRequestError = true;
        }
        ~ResultCollaborativeProcessingWorker()
        {
            Dispose(false);
        }
        public void Dispose()
        {
            Dispose(true);
        }
        protected void Dispose(bool disposing)
        {
            if (!this.Disposed)
            {
                if (disposing)
                {
                    this.TheResult = null;
                }
            }
        }
        public void Start()
        {
            DoWork();
        }
        protected void DoWork()
        {
            try
            {
                DiUniversalAdapterQueuingHelper theHelper = new DiUniversalAdapterQueuingHelper();
                if (this.IsRequestError)
                {
                    DiUniversalAdapterRuntimeLogger.LogInfo(DiUniversalAdapterRuntimeHandler.ProcessID, string.Format("DiUniversalAdapter Runtime starts sending error of request {0} to Error Queue", this.TheError.TheRequest.RequestGuid), DateTime.UtcNow, DiUniversalAdapterRuntimeHandler.IsDebug);
                    //Process and send error to Error Queue
                    theHelper.DeliverError(this.TheError);
                    DiUniversalAdapterRuntimeLogger.LogInfo(DiUniversalAdapterRuntimeHandler.ProcessID, string.Format("DiUniversalAdapter Runtime completes sending error of request {0} to Error Queue\r\n", this.TheError.TheRequest.RequestGuid), DateTime.UtcNow, DiUniversalAdapterRuntimeHandler.IsDebug);

                }
                else
                {
                    if (!this.TheResult.TheRequest.Activity.Equals("END"))
                    {
                        DiUniversalAdapterRuntimeLogger.LogInfo(DiUniversalAdapterRuntimeHandler.ProcessID, string.Format("DiUniversalAdapter Runtime starts sending result of request {0} to Collaboration Queue", this.TheResult.RequestGuid), DateTime.UtcNow, DiUniversalAdapterRuntimeHandler.IsDebug);
                        theHelper.SendCollaborationRequest(this.TheResult.TheRequest);
                        DiUniversalAdapterRuntimeLogger.LogInfo(DiUniversalAdapterRuntimeHandler.ProcessID, string.Format("DiUniversalAdapter Runtime completes sending result of request {0} to Collaboration Queue\r\n", this.TheResult.RequestGuid), DateTime.UtcNow, DiUniversalAdapterRuntimeHandler.IsDebug);
                    }
                    // trung need to fix
                    else
                    {
                        DiUniversalAdapterRuntimeLogger.LogInfo(DiUniversalAdapterRuntimeHandler.ProcessID, string.Format("DiUniversalAdapter Runtime starts sending result of request {0} to Outbound Queue", this.TheResult.RequestGuid), DateTime.UtcNow, DiUniversalAdapterRuntimeHandler.IsDebug);
                        //Process and send result to Outbound Queue
                        theHelper.DeliverResult(this.TheResult);
                        DiUniversalAdapterRuntimeLogger.LogInfo(DiUniversalAdapterRuntimeHandler.ProcessID, string.Format("DiUniversalAdapter Runtime completes sending result of request {0} to Outbound Queue\r\n", this.TheResult.RequestGuid), DateTime.UtcNow, DiUniversalAdapterRuntimeHandler.IsDebug);
                    }

                }
            }
            catch (DiCIPException cipEx)
            {
                this.ErrorException = cipEx;
            }
            catch (DiUniversalAdapterServiceException uniteEx)
            {
                this.ErrorException = uniteEx;
            }
            catch (Exception sysEx)
            {
                string error = "";
                if (this.IsRequestError)
                {
                    error = "Cannot send error result for request {0} to Error queue. Unknow error occured at DoWork of ResultProcessingWorker!";
                    if (this.TheError != null)
                    {
                        error = string.Format(error, this.TheError.TheRequest.RequestGuid);
                    }
                    else
                    {
                        error = string.Format(error, "UNKNOWN");
                    }

                }
                else
                {
                    error = "Cannot send result for request {0} to Outbound queue. Unknow error occured at DoWork of ResultProcessingWorker!";
                    if (this.TheResult != null)
                    {
                        error = string.Format(error, this.TheResult.RequestGuid);

                    }
                    else
                    {
                        error = string.Format(error, "UNKNOWN");
                    }

                }
                this.ErrorException = new DiUniversalAdapterServiceException(error, sysEx);
            }
            finally
            {
                DoWorkCompleted();
            }

        }
        private void DoWorkCompleted()
        {
            //If there is error occured. Handle it!
            if (this.ErrorException != null)
            {
                DiUniversalAdapterRuntimeLogger.LogInfo(DiUniversalAdapterRuntimeHandler.ProcessID, "Cannot send the result to Outbound Queue!\r\n", DateTime.UtcNow, DiUniversalAdapterRuntimeHandler.IsDebug);

                //Cannot send message to queue. The must be somgthing wrong

                DiUniversalAdapterExceptionHandler.HandleException(null, this.ErrorException);
            }
        }
    }
}
