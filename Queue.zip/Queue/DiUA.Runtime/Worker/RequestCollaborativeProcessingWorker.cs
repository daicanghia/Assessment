﻿//using DiCIP.Common.AppException;
//using DiUniversalAdapter.Common.AppException;
//using DiUniversalAdapter.Common.ExceptionHandler;
//using DiUniversalAdapter.Common.Helper;
//using DiUniversalAdapter.Common.Models;
//using DiUniversalAdapter.Common.Worker;
//using DiUniversalAdapter.Runtime.Helper;
//using DiUniversalAdapter.Runtime.RunProject;
//using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Diagnostics;
//using System.Linq;
//using System.Runtime.CompilerServices;
//using System.Text;
//using System.Threading;

//namespace DiUniversalAdapter.Runtime.Worker
//{
//    public class RequestCollaborativeProcessingWorker : ProcessingWorker
//    {
//        bool Disposed { get; set; }
//        public Request TheRequest { get; set; }
//        public RequestResult TheResult { get; set; }

//        public Action AutoEvent { get; set; }

//        public RequestCollaborativeProcessingWorker(Request theRequest) : base()
//        {
//            this.Disposed = false;
//            this.TheRequest = theRequest;
//        }
//        public RequestCollaborativeProcessingWorker()
//            : base()
//        {

//        }

//        protected override void Dispose(bool disposing)
//        {
//            if (!this.Disposed)
//            {
//                if (disposing)
//                {
//                    this.TheRequest = null;
//                    this.TheResult = null;

//                }
//                this.Disposed = true;
//                base.Dispose(disposing);
//            }
//        }
//        public new void Start()
//        {
//            base.Start();
//        }
//        protected override void DoWork(object sender, DoWorkEventArgs e)
//        {
//            try
//            {



//                DiUniversalAdapterRuntimeLogger.LogInfo(DiUniversalAdapterRuntimeHandler.ProcessID, string.Format("RunProjectModule starts processing request: {0} with Activity :{1} ", this.TheRequest.RequestGuid, this.TheRequest.Activity), DateTime.UtcNow, DiUniversalAdapterRuntimeHandler.IsDebug);
//                RunProjectModule rpm = new RunProjectModule(this.TheRequest);
//                rpm.IsDebug = DiUniversalAdapterRuntimeHandler.IsDebug;
//                rpm.Run();

//                //this.TheResult.TheRequest = new Request(this.TheRequest.ProcessId, this.TheRequest.Activities);
//                this.TheResult = rpm.RequestResultInformation; //ResquestResultInformation;
//                //this.TheResult.RequestGuid = this.TheRequest.RequestGuid;
//                this.TheResult.ProcessID = Process.GetCurrentProcess().Id.ToString();
//                this.TheResult.TheRequest = new Request();
//                this.TheRequest.Activity = this.TheResult.CurrentActivityID;
//                this.TheResult.TheRequest = this.TheRequest;
//               // DiUniversalAdapterRuntimeLogger.LogInfo(DiUniversalAdapterRuntimeHandler.ProcessID, string.Format("RunProjectModule completes processing request : {0} with Activity :{1}", this.TheRequest.RequestGuid, this.TheRequest.Activity), DateTime.UtcNow, DiUniversalAdapterRuntimeHandler.IsDebug);
//                DiUniversalAdapterRuntimeLogger.LogInfo(DiUniversalAdapterRuntimeHandler.ProcessID, string.Format("RunProjectModule completes processing Collaborative request: {0} with Activity :{1} handled by PID : {2} ", this.TheRequest.RequestGuid, this.TheRequest.Activity, this.TheResult.ProcessID), DateTime.UtcNow, DiUniversalAdapterRuntimeHandler.IsDebug);

//            }
//            catch (DiCIPException cipEx)
//            {
//                this.ErrorException = cipEx;
//            }
//            catch (DiUniversalAdapterServiceException uniteEx)
//            {
//                this.ErrorException = uniteEx;
//            }
//            catch (Exception sysEx)
//            {
//                this.ErrorException = new DiUniversalAdapterServiceException(string.Format("RunProjectModule cannot process the request {0} ", this.TheRequest.RequestGuid), sysEx);
//            }
//        }
//        protected override void DoWorkCompleted(object sender, RunWorkerCompletedEventArgs e)
//        {
//            try
//            {
//                RequestError error = null;
//                //The request is processed processfully. Sent the result to queue.
//                if ((this.ErrorException == null) && (e.Error == null))
//                {
//                    RuntimeProcessHelper theHelper = new RuntimeProcessHelper();
//                    theHelper.ProcessCollaborationResult(this.TheResult);

//#if AUTOTEST
//                    string messasge = string.Format("Request {0} has been processed sucessfully!\n", this.TheRequest.RequestGuid);
//                    Console.Out.WriteAsync(messasge);
//#endif
//                }
//                else
//                {
//                    string debugInfo = "Cannot complete processing request {0}!";
//                    if (this.TheRequest != null)
//                    {
//                        debugInfo = string.Format(debugInfo, this.TheRequest.RequestGuid);
//                    }
//                    else
//                    {
//                        debugInfo = string.Format(debugInfo, "UNKNOWN");
//                    }

//                    DiUniversalAdapterRuntimeLogger.LogInfo(DiUniversalAdapterRuntimeHandler.ProcessID, debugInfo, DateTime.UtcNow, DiUniversalAdapterRuntimeHandler.IsDebug);

//                    error = new RequestError();
//                    error.TheRequest = this.TheRequest;

//                    if (e.Error != null)
//                    {
//                        error.TheResult = new RequestResult(this.TheRequest.ProcessId, this.TheRequest.Activity, e.Error.ToString());
//                    }
//                    else if (this.ErrorException != null)
//                    {
//                        error.TheResult = new RequestResult(this.TheRequest.ProcessId, this.TheRequest.Activity, this.ErrorException.ToString());
//                    }

//                    error.TheResult.RequestGuid = this.TheRequest.RequestGuid;

//                    //Send error to Error Queue
//                    RuntimeProcessHelper theHelper = new RuntimeProcessHelper();
//                    theHelper.ProcessCollaborationError(error);

//                    //Log error
//                    if (this.ErrorException != null)
//                    {
//                        DiUniversalAdapterExceptionHandler.HandleException(null, this.ErrorException);

//                    }
//                    else if (e.Error != null)
//                    {
//                        string unknownError = string.Format("Request {0} has been processed unsucessfully. Unknown error occured!\n", this.TheRequest.RequestGuid);
//                        DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException(unknownError, e.Error));
//                    }

//#if AUTOTEST
//                    string messasge = string.Format("Request {0} has been processed unsucessfully!\n", this.TheRequest.RequestGuid);
//                    Console.Out.WriteAsync(messasge);
//#endif
//                }

//            }
//            catch (DiCIPException cipEx)
//            {
//                DiUniversalAdapterExceptionHandler.HandleException(null, cipEx);
//            }
//            catch (DiUniversalAdapterServiceException uniteEx)
//            {
//                DiUniversalAdapterExceptionHandler.HandleException(null, uniteEx);
//            }
//            catch (Exception sysEx)
//            {
//                //Handle the exception and that's all.
//                string error = "Cannot send result for request {0} to queue. Unknow error occured at RequestCollaborativeProcessingWorker!";
//                if (this.TheRequest != null)
//                {
//                    error = string.Format(error, this.TheRequest.RequestGuid);
//                }
//                else
//                {
//                    error = string.Format(error, "UNKNOWN");
//                }

//                this.ErrorException = new DiUniversalAdapterServiceException(error, sysEx);
//                DiUniversalAdapterExceptionHandler.HandleException(null, this.ErrorException);

//#if AUTOTEST
//                string messasge = string.Format("Request {0} has been processed but cannot send result to Outbound queue!\n", this.TheRequest.RequestGuid);
//                Console.Out.WriteAsync(error);
//#endif
//            }
//            finally
//            {
//                if (this.TheResult != null
//                    && this.TheResult.Message != null
//                    && (this.TheResult.Message.Contains("Out of memory")))
//                {
//                    System.Threading.Thread.Sleep(60000);
//                    Environment.Exit(0);
//                }
//                else
//                {
//                    //DiUniversalAdapterRuntimeHandler.StartReceivingRequest();
//                    // DiUniversalAdapterRuntimeHandler.StartReceiving();
//                    //AutoEvent.Set();
//                    AutoEvent();
//                }
//            }
//        }
//    }
//}
