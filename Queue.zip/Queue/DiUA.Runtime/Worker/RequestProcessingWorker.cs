﻿using DiCIP.Common.AppException;
using DiCIP.Common.Configuration;
using DiUniversalAdapter.Common.AppException;
using DiUniversalAdapter.Common.ExceptionHandler;
using DiUniversalAdapter.Common.Helper;
using DiUniversalAdapter.Common.Models;
using DiUniversalAdapter.Runtime.Helper;
//using DiUniversalAdapter.Runtime.RunProject;
using System;
using System.Diagnostics;
using System.Runtime;

namespace DiUniversalAdapter.Runtime.Worker
{
    /**
     * worker used to process request
     */
    public class RequestProcessingWorker : IDisposable
    {
        bool Disposed { get; set; }
        private CIPMessageType Qtype;
        public Request TheRequest { get; set; }
        public RequestResult TheResult { get; set; }

        private Exception ErrorException = null;
        public RequestProcessingWorker(Request theRequest, CIPMessageType qtype)
        {
            this.Disposed = false;
            this.TheRequest = theRequest;
            this.Qtype = qtype;
        }
        //public RequestProcessingWorker()
        //{

        //}

        private string QueueName
        {
            get
            {
                switch (Qtype)
                {
                    case CIPMessageType.Inbound:
                        return CIPMessageType.Inbound.ToString();
                    case CIPMessageType.Collaboration:
                        return CIPMessageType.Collaboration.ToString();

                    default: throw new Exception("wrong message type! ");
                }
            }
        }

        ~RequestProcessingWorker()
        {
            Dispose(false);
        }
        public void Dispose()
        {
            Dispose(true);
        }

        protected void Dispose(bool disposing)
        {
            if (!this.Disposed)
            {
                if (disposing)
                {
                    this.TheRequest = null;
                    this.TheResult = null;
                }
            }
        }
        public void Start()
        {
            DoWork();
        }

        /// <summary>
        /// Do Work
        /// </summary>
        private void DoWork()
        {
            try
            {
                DiUniversalAdapterRuntimeLogger.LogInfo(DiUniversalAdapterRuntimeHandler.ProcessID,
                    string.Format("RunProjectModule starts processing {0} request: {1} with RuntimeKey: {2} Activity :{3} ",
                    this.QueueName, this.TheRequest.RequestGuid, this.TheRequest.RuntimeKey, this.TheRequest.Activity), 
                    DateTime.UtcNow,DiUniversalAdapterRuntimeHandler.IsDebug);
                    
                //RunProjectModule rpm = new RunProjectModule(this.TheRequest);
                //rpm.IsDebug = DiUniversalAdapterRuntimeHandler.IsDebug;
                ////rpm.IsInboundReq = (CIPMessageType.Inbound == Qtype);
                ////GCSettings.LargeObjectHeapCompactionMode = GCLargeObjectHeapCompactionMode.CompactOnce;
                ////GC.Collect();
                //rpm.Run();
                //this.TheResult = rpm.RequestResultInformation;
                ////this.TheResult.RequestGuid = this.TheRequest.RequestGuid;
                //this.TheResult.ProcessID = Process.GetCurrentProcess().Id.ToString();
                //this.TheResult.TheRequest = new Request();
                //// Set activity has been done to next request
                //this.TheRequest.Activity = this.TheResult.CurrentActivityID;
                //this.TheResult.TheRequest = this.TheRequest;

                //DiUniversalAdapterRuntimeLogger.LogInfo(DiUniversalAdapterRuntimeHandler.ProcessID,
                //    string.Format("RunProjectModule completes processing {0} request: {1} with RuntimeKey: {2} Activity :{3} handled by PID : {4} ",
                //    this.QueueName, this.TheRequest.RequestGuid, this.TheRequest.RuntimeKey, this.TheRequest.Activity, this.TheResult.ProcessID),
                //    DateTime.UtcNow, DiUniversalAdapterRuntimeHandler.IsDebug);

            }
            catch (DiCIPException cipEx)
            {
                this.ErrorException = cipEx;
            }
            catch (DiUniversalAdapterServiceException uniteEx)
            {
                this.ErrorException = uniteEx;
            }
            catch (Exception sysEx)
            {
                this.ErrorException = new DiUniversalAdapterServiceException(string.Format("RunProjectModule cannot process the request {0} ", this.TheRequest.RequestGuid), sysEx);
            }
            finally
            {
                DoWorkCompleted();
            }
        }

        /// <summary>
        /// Complete Work processing
        /// </summary>
        private void DoWorkCompleted()
        {
            try
            {
                RequestError error = null;
                //The request is processed processfully. Sent the result to queue.
                if (this.ErrorException == null)
                {
                    RuntimeProcessHelper theHelper = new RuntimeProcessHelper();
                    theHelper.ProcessResult(this.TheResult);
                }
                else
                {
                    string debugInfo = "Cannot complete processing request {0}!";
                    if (this.TheRequest != null)
                    {
                        debugInfo = string.Format(debugInfo, this.TheRequest.RequestGuid);
                    }
                    else
                    {
                        debugInfo = string.Format(debugInfo, "UNKNOWN");
                    }

                    DiUniversalAdapterRuntimeLogger.LogInfo(DiUniversalAdapterRuntimeHandler.ProcessID, debugInfo,
                        DateTime.UtcNow, DiUniversalAdapterRuntimeHandler.IsDebug);

                    error = new RequestError();
                    error.TheRequest = this.TheRequest;
                    error.TheResult = new RequestResult(this.TheRequest.RuntimeKey, this.TheRequest.Activity, this.ErrorException.ToString());
                    error.TheResult.RequestGuid = this.TheRequest.RequestGuid;

                    //Send error to Error Queue
                    RuntimeProcessHelper theHelper = new RuntimeProcessHelper();
                    theHelper.ProcessError(error);

                    //Log error
                    DiUniversalAdapterExceptionHandler.HandleException(null, this.ErrorException);
                }

            }
            catch (DiCIPException cipEx)
            {
                DiUniversalAdapterExceptionHandler.HandleException(null, cipEx);
            }
            catch (DiUniversalAdapterServiceException uniteEx)
            {
                DiUniversalAdapterExceptionHandler.HandleException(null, uniteEx);
            }
            catch (Exception sysEx)
            {
                //Handle the exception and that's all.
                string error = "Cannot send result for request {0} to" + 
                    ((this.Qtype == CIPMessageType.Inbound)? 
                    CIPMessageType.Collaboration.ToString() : 
                    CIPMessageType.Outbound.ToString()) + 
                    "queue. Unknow error occured at RequestProcessingWorker!";
                if (this.TheRequest != null)
                {
                    error = string.Format(error, this.TheRequest.RequestGuid);
                }
                else
                {
                    error = string.Format(error, "UNKNOWN");
                }

                this.ErrorException = new DiUniversalAdapterServiceException(error, sysEx);
                DiUniversalAdapterExceptionHandler.HandleException(null, this.ErrorException);
            }
            finally
            {
                if (this.TheResult != null
                    && this.TheResult.Message != null
                    && (this.TheResult.Message.Contains("Out of memory")))
                {
                    System.Threading.Thread.Sleep(60000);
                    Environment.Exit(0);
                }
                else
                {
                    // do nothing
                }
            }
        }
    }
}
