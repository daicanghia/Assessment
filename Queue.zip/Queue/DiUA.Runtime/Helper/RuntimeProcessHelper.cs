﻿using DiCIP.Common.AppException;
using DiCIP.Common.Configuration;
using DiCIP.Services.QueuingService;
using DiUniversalAdapter.Common.AppException;
using DiUniversalAdapter.Common.Configuration;
using DiUniversalAdapter.Common.Helper;
using DiUniversalAdapter.Common.Models;
using DiUniversalAdapter.Runtime.Worker;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DiUniversalAdapter.Runtime.Helper
{
    /**
    * Statelessheler calss for thread-safe
    */
    public class RuntimeProcessHelper
    {

        public IProcessSettings ProcessReceivedParams(string[] args)
        {
            IProcessSettings runtimeSettings;

            if (args == null || args.Count() < 1)
            {
                runtimeSettings = null;
            }
            else
            {
                char[] delimiterChars = { ',' };
                List<string> arguments = StringHelper.SplitParameters(delimiterChars, args[0]);
                if ((arguments == null) || (arguments.Count != 8))
                {
                    runtimeSettings = null;
                }
                else
                {
                    runtimeSettings = new RuntimeProcessSettings();
                    runtimeSettings.ProcessID = arguments[0];
                    runtimeSettings.InboundQueue = arguments[1];
                    runtimeSettings.OutboundQueue = arguments[2];
                    runtimeSettings.ErrorQueue = arguments[3];
                    runtimeSettings.CollaborativeQueue = arguments[4];
                    runtimeSettings.ReceivingRequestTimerInMillisecons = int.Parse(arguments[5]);
                    runtimeSettings.TimerInMillisecons = int.Parse(arguments[6]);
                    runtimeSettings.RuntimeStartThreads = int.Parse(arguments[7]);
                }
            }
            return runtimeSettings;
        }
        public IQueuingService EstablishConnections(IProcessSettings runtimeSettings)
        {
            List<ISetting> settings = new List<ISetting>();
            try
            {
                //foreach (string key in Enum.GetNames(typeof(CIPMessageType)))
                ISetting setting = null;
                foreach (CIPMessageType messageType in System.Enum.GetValues(typeof(CIPMessageType)))
                {
                    switch (messageType)
                    {
                        case CIPMessageType.Inbound:
                            setting = new Setting(new KeyValuePair<string, string>(CIPMessageType.Inbound.ToString(), runtimeSettings.InboundQueue));
                            settings.Add(setting);
                            break;
                        case CIPMessageType.Outbound:
                            setting = new Setting(new KeyValuePair<string, string>(CIPMessageType.Outbound.ToString(), runtimeSettings.OutboundQueue));
                            settings.Add(setting);
                            break;
                        case CIPMessageType.Error:
                            setting = new Setting(new KeyValuePair<string, string>(CIPMessageType.Error.ToString(), runtimeSettings.ErrorQueue));
                            settings.Add(setting);
                            break;
                        case CIPMessageType.Collaboration:
                            setting = new Setting(new KeyValuePair<string, string>(CIPMessageType.Collaboration.ToString(), runtimeSettings.CollaborativeQueue));
                            settings.Add(setting);
                            break;
                    }
                }

                //IConfiguration serviceConfigure = new DiUniversalAdapterConfigure(settings);

                //List<KeyValuePair<string, IConfiguration>> config = new List<KeyValuePair<string, IConfiguration>>();
                //config.Add(new KeyValuePair<string, IConfiguration>(CIPService.DiUniversalAdapter.ToString(), serviceConfigure));

                //IQueuingService queuingService = new QueuingService();
                //queuingService.InitQueuingService(config);
                var serviceConfigure = new DiUniversalAdapterConfigure(settings);
                List<KeyValuePair<string, ICIPConfiguration>> config = new List<KeyValuePair<string, ICIPConfiguration>>();
                config.Add(new KeyValuePair<string, ICIPConfiguration>(CIPServices.DiUniversalAdapter.ToString(), serviceConfigure));

                IQueuingService queuingService = new QueuingService();
                queuingService.InitQueuingService(config);
                return queuingService;

            }
            catch (DiCIPException)
            {
                throw;
            }
            catch (Exception sysEx)
            {
                throw new DiUniversalAdapterServiceException("Cannot establish connections to queues", sysEx);
            }

        }

        public void ProcessResult(RequestResult result)
        {
            //Using seperated thread to process result to improve performance
            using (ResultProcessingWorker processingWorker = new ResultProcessingWorker(result))
            {
                processingWorker.Start();
            }
        }

        //public void ProcessCollaborationResult(RequestResult result)
        //{

        //    //Using seperated thread to process result to improve performance
        //    ResultCollaborativeProcessingWorker processingWorker = new ResultCollaborativeProcessingWorker(result);
        //    processingWorker.Start();
        //}

        public void ProcessError(RequestError theError)
        {
            //Using seperated thread to process error to improve performance
            using (ResultProcessingWorker processingWorker = new ResultProcessingWorker(theError))
            {
                processingWorker.Start();
            }
        }

        //public void ProcessCollaborationError(RequestError theError)
        //{
        //    //Using seperated thread to process error to improve performance
        //    ResultCollaborativeProcessingWorker processingWorker = new ResultCollaborativeProcessingWorker(theError);
        //    processingWorker.Start();
        //}

    }
}
