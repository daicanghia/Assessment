﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DiUniversalAdapter.Runtime.TaskScheduler
{
    //==================================================================================================\\
    // Provides a task scheduler for long-running tasks that ensures a maximum concurrency level
    // while running on top of a custom thread pool.
    // The behavior is similar to TaskCreationOptions.LongRunning | TaskCreationOptions.PreferFairness.
    public sealed class LimitedConcurrencyLevelTaskScheduler : System.Threading.Tasks.TaskScheduler
    {

        // Indicates whether the current thread is processing work items.
        [ThreadStatic]
        private static bool _currentThreadIsProcessingItems;

        // The list of tasks to be executed
        private readonly LinkedList<Task> _tasks = new LinkedList<Task>(); // protected by lock(_tasks)

        // The custom pool of worker threads.
        private readonly List<Thread> _workingThreads = new List<Thread>();// protected by lock(_workingThreads)

        // The maximum concurrency level allowed by this scheduler.
        private readonly int _maxDegreeOfParallelism;

        // Indicates whether the scheduler is currently processing work items.
        private volatile int _delegatesQueuedOrRunning = 0;// volatile so that its latest value is available on all threads

        // Creates a new instance with the specified degree of parallelism.
        public LimitedConcurrencyLevelTaskScheduler(int maxDegreeOfParallelism)
        {
            if (maxDegreeOfParallelism < 1) throw new ArgumentOutOfRangeException("maxDegreeOfParallelism");

            _maxDegreeOfParallelism = maxDegreeOfParallelism;
        }

        // Gets a read-only list of currently working threads, so that we can call Abort() if really needed, when CancellationToken could not help.
        public IReadOnlyList<Thread> GetWorkingThreads()
        {
            List<Thread> result;
            lock (_workingThreads)
            {
                result = new List<Thread>(_workingThreads);
            }
            return result.AsReadOnly();
        }

        // Gets a read-only list of tasks remaining in the queue. 
        public IReadOnlyList<Task> GetQueuedTasks()
        {
            List<Task> result;
            lock (_tasks)
            {
                result = new List<Task>(_tasks);
            }
            return result.AsReadOnly();
        }

        // Queues a task to the scheduler.
        protected sealed override void QueueTask(Task task)
        {
            // Add the task to the list of tasks to be processed. If there aren't enough
            // delegates currently queued or running to process tasks, schedule another.
            bool shouldStartNewThread = false;
            lock (_tasks)
            {
                _tasks.AddLast(task);
                Trace.WriteLine(DateTime.UtcNow.ToString() + "\tTasks queued: " + _tasks.Count.ToString(), "LimitedConcurrencyLevelTaskScheduler");

                if (_delegatesQueuedOrRunning < _maxDegreeOfParallelism)
                {
                    Interlocked.Increment(ref _delegatesQueuedOrRunning);// This is the only place that we increase _delegatesQueuedOrRunning; other threads can decrease simultaneously.
                    shouldStartNewThread = true;
                }
            }

            if (shouldStartNewThread)
            {
                StartNewWorkerThread();

                // This may give the new thread a chance to activate.
                Thread.Yield();
            }
        }

        // Start a new worker thread to execute tasks queued for this scheduler.
        private void StartNewWorkerThread()
        {
            var thread = new Thread((state) =>
            {
                    // Note that the current thread is now processing work items.
                    // This is necessary to enable inlining of tasks into this thread.
                    _currentThreadIsProcessingItems = true;

                ThreadWriteTrace("Started\tdelegatesQueuedOrRunning: " + _delegatesQueuedOrRunning.ToString());

                try
                {
                        // Process all available items in the queue until cancel requested.
                        for (; ; )
                    {
                        Task item;
                        lock (_tasks)
                        {
                                // When there are no more items to be processed, we're done processing, so get out.
                                if (_tasks.Count == 0)
                            {
                                break;
                            }

                                // Get the next item from the queue
                                item = _tasks.First.Value;
                            _tasks.RemoveFirst();
                        }

                            // Execute the task we pulled out of the queue
                            if (!base.TryExecuteTask(item))
                        {
                            ThreadWriteTrace("Failed to TryExecuteTask.");
                                // https://docs.microsoft.com/en-us/dotnet/api/system.threading.tasks.taskscheduler.tryexecutetask?view=netframework-4.0
                                // A common reason for execution failure is that the task had previously been executed or is in the process of being executed by another thread.
                            }
                    }
                }
                catch (ThreadAbortException)
                {
                        //ignore
                    }
                catch (Exception ex)
                {
                    ThreadWriteTrace("EXCEPTION: " + ex.ToString());
                }
                    // We're done processing items on the current thread
                    finally
                {
                    _currentThreadIsProcessingItems = false;

                    Interlocked.Decrement(ref _delegatesQueuedOrRunning);// put in finally to ensure always decrease

                        lock (_workingThreads)
                    {
                        _workingThreads.Remove((Thread)state);// put in finally to ensure always remove
                        }

                    ThreadWriteTrace("Stop\tdelegatesQueuedOrRunning: " + _delegatesQueuedOrRunning.ToString());
                }
            })
            {
                IsBackground = true,
                Name = "Worker thread " + this._delegatesQueuedOrRunning.ToString()
            };

            try
            {
                thread.Start(thread);// may encounter OOM exception here if MaximumConcurrencyLevel is too high 

                lock (_workingThreads)
                {
                    _workingThreads.Add(thread);// only add if we can start
                }
            }
            catch
            {
                Interlocked.Decrement(ref this._delegatesQueuedOrRunning);
            }

            //Trace.WriteLine(DateTime.UtcNow.ToString() + "\tStarting\tdelegatesQueuedOrRunning: " + this._delegatesQueuedOrRunning.ToString(), "LimitedConcurrencyLevelTaskScheduler");
        }

        private void ThreadWriteTrace(string message)
        {
            Trace.WriteLine(DateTime.UtcNow.ToString() + "\t" + Thread.CurrentThread.ManagedThreadId.ToString() + "\t" + Thread.CurrentThread.Name + "\t" + message, "LimitedConcurrencyLevelTaskScheduler");
        }

        // Attempts to execute the specified task on the current thread.
        protected sealed override bool TryExecuteTaskInline(Task task, bool taskWasPreviouslyQueued)
        {
            // If this thread isn't already processing a task, we don't support inlining
            if (!_currentThreadIsProcessingItems) return false;

            // If the task was previously queued, remove it from the queue
            if (taskWasPreviouslyQueued)
                // Try to run the task.
                if (TryDequeue(task))
                    return base.TryExecuteTask(task);
                else
                    return false;
            else
                return base.TryExecuteTask(task);
        }

        // Attempt to remove a previously scheduled task from the scheduler.
        protected sealed override bool TryDequeue(Task task)
        {
            lock (_tasks) return _tasks.Remove(task);
        }

        // Gets the maximum concurrency level supported by this scheduler.
        public sealed override int MaximumConcurrencyLevel
        {
            get
            {
                return _maxDegreeOfParallelism;
            }
        }

        // Gets the number of Queued Or Working threads
        public int QueuedOrWorkingThreadCount
        {
            get
            {
                return _delegatesQueuedOrRunning;
            }
        }

        // Gets the number of working threads.
        public int WorkingThreadCount
        {
            get
            {
                lock (_workingThreads)
                {
                    return _workingThreads.Count;
                }
            }
        }

        // Gets the number of queued tasks.
        public int QueuedTaskCount
        {
            get
            {
                lock (_tasks)
                {
                    return _tasks.Count;
                }
            }
        }

        // Gets an enumerable of the tasks currently scheduled on this scheduler.
        protected sealed override IEnumerable<Task> GetScheduledTasks()
        {
            bool lockTaken = false;
            try
            {
                Monitor.TryEnter(_tasks, ref lockTaken);
                if (lockTaken) return _tasks;
                else throw new NotSupportedException();
            }
            finally
            {
                if (lockTaken) Monitor.Exit(_tasks);
            }
        }
    }

}
