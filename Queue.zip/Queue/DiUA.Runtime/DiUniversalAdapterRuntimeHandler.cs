﻿using DiCIP.Common.AppException;
using DiCIP.Services.QueuingService;
using DiUniversalAdapter.Common.Configuration;
using DiUniversalAdapter.Common.AppException;
using DiUniversalAdapter.Common.ExceptionHandler;
using DiUniversalAdapter.Common.Helper;
using DiUniversalAdapter.Common.Models;
using DiUniversalAdapter.Runtime.Worker;
using System;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using DiUniversalAdapter.Runtime.Helper;
using System.Configuration;
using DiUniversalAdapter.Runtime.TaskScheduler;
using System.Diagnostics;
using DiCIP.Common.Configuration;

namespace DiUniversalAdapter.Runtime
{
    /**
     * Class provides functionalities used to manage DiUniversalAdapterRuntime process.
     * DiUniversalAdapterRuntimeHandler is singleton class to ensure that the container is only initilized one time and there is only instance.
     */
    class DiUniversalAdapterRuntimeHandler : IDisposable
    {

        private static DiUniversalAdapterRuntimeHandler RuntimeHandler = null;
        private IQueuingService QueuingService { get; set; }

        public static bool IsDebug = false;

        public static string ProcessID;
        private bool Disposed { get; set; }

        /**
        * DiUniversalAdapter Runtime Process's settings
        */
        private static IProcessSettings RuntimeSettings { get; set; }

        /**
         * Use thread to keep the console app runnning
         */
        private Thread RunningThread = null;
        /// <summary>
        /// The request from Queue
        /// </summary>
        private Request theRequest;

        /// <summary>
        /// Loop Flag default = true
        /// </summary>
        private static volatile bool LoopFlag;

        /**
         * Processing code used to indicate which error occured while the process running
         */
        private int ProcessingCode = 0;

        private DiUniversalAdapterRuntimeHandler()
        {
            RuntimeSettings = null;
            this.QueuingService = null;
            this.Disposed = false;
        }
        ~DiUniversalAdapterRuntimeHandler()
        {
            Dispose(false);
        }

        public void Dispose()
        {
            Dispose(true);

        }
        protected virtual void Dispose(bool disposing)
        {
            if (!this.Disposed)
            {
                if (disposing)
                {
                    DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("DiUniversalAdapterRuntimeHandler disposing! "));
                    try
                    {
                        RuntimeSettings = null;
                        LoopFlag = false;
                        this.RunningThread.Abort();
                    }
                    catch (Exception)
                    {

                    }
                    DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("DiUniversalAdapterRuntimeHandler disposed! "));
                }
                this.Disposed = true;
            }
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public static DiUniversalAdapterRuntimeHandler GetInstance()
        {
            if (RuntimeHandler == null)
            {
                RuntimeHandler = new DiUniversalAdapterRuntimeHandler();
            }
            return RuntimeHandler;
        }

        public int Initialize(string[] args)
        {
            //Process inputs parametters passed and read from app configure file
            ProcessingCode = ProcessInputParams(args);
            ProcessID = RuntimeSettings.ProcessID;

            if (ProcessingCode != (int)RuntimeProcessExitCode.NoError)
            {
                return ProcessingCode;
            }

            //Connect to queues
            ProcessingCode = Connect2Queues();
            if (ProcessingCode != (int)RuntimeProcessExitCode.NoError)
            {
                return ProcessingCode;
            }

            //Everything is ok. It is now ready to start processing request
            ProcessingCode = StartProcessingRequests();

            if (ProcessingCode != (int)RuntimeProcessExitCode.NoError)
            {
                return ProcessingCode;
            }

            return ProcessingCode;
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public static void StartReceiving()
        {
            if (!LoopFlag)
            {
                LoopFlag = true;
            }
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public static void StopReceiving()
        {
            if (LoopFlag)
            {
                LoopFlag = false;
            }
        }

        #region Private Methods------------------------------------------------------

        /// <summary>
        /// StartNewThreadWorker
        /// </summary>
        /// <param name="request"></param>
        /// <param name="qtype"></param>
        private void StartNewThreadWorker(Request request, CIPMessageType qtype)
        {
            DiUniversalAdapterRuntimeLogger.LogInfo(ProcessID, string.Format("Request received: {0}", request.RequestGuid), DateTime.UtcNow, IsDebug);
            //Process the request.
            factory.StartNew(() =>
            {
                using (var processRequestWorker = new RequestProcessingWorker(request, qtype))
                {
                    processRequestWorker.Start();
                }
                Debug.WriteLine(DateTime.UtcNow.ToString() + "\t" + Thread.CurrentThread.ManagedThreadId.ToString() + " " + Thread.CurrentThread.Name + "\tFinished Task ");
            }, CancellationTokenSource.Token);
        }

        /// <summary>
        /// Process Request In Queue
        /// </summary>
        private void ProcessRequestInQueue()
        {
            try
            {
                var theHelper = DiUniversalAdapterQueuingHelper.GetQueuingHelperInstance();

                //Get request from the queue
                while (taskScheduler.QueuedOrWorkingThreadCount < MaximumConcurrency + 1)
                {
                    // Get request from Collaborative Queue
                    theRequest = theHelper.ReceiveCollaborativeRequest();

                    if (theRequest != null)
                    {
                        StartNewThreadWorker(theRequest, CIPMessageType.Collaboration);
                        continue;
                    }

                    // if there is no message in collaborative queue then start receiving message from inpound queue
                    //Get request from the inbound queue
                    theRequest = theHelper.ReceiveRequest();

                    if (theRequest != null)
                    {
                        StartNewThreadWorker(theRequest, CIPMessageType.Inbound);
                        continue;
                    }

                    //There is no request in queue. 
                    Debug.WriteLine("No request in queue! ...");
                    Thread.Sleep(10);
                    break;
                }
            }
            catch (DiCIPException cipEx)
            {
                //Logging the exception
                DiUniversalAdapterExceptionHandler.HandleException(null, cipEx);
            }
            catch (Exception sysEx)
            {
                //Logging the exception
                DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("Error while process request from inbound & collaborative queue! ", sysEx));
            }
        }
       
        private int StartProcessingRequests()
        {
            int processingCode = (int)RuntimeProcessExitCode.NoError;
            try
            {
#if DEBUG
                Trace.Listeners.Add(new TextWriterTraceListener(Console.Out));
#endif
                // Create task scheduler object
                MaximumConcurrency = (RuntimeSettings.RuntimeStartThreads * Environment.ProcessorCount);// 16 * 4 = 64
                CancellationTokenSource = new CancellationTokenSource();
                taskScheduler = new LimitedConcurrencyLevelTaskScheduler(MaximumConcurrency);
                factory = new TaskFactory(CancellationTokenSource.Token, TaskCreationOptions.None, TaskContinuationOptions.None, taskScheduler);
                // set loop flag default = true
                StartReceiving();
                // Start main application thread
                RunningThread = new Thread(ProcessRequestStart) { IsBackground = false, Name = "Main Processing thread" };
                RunningThread.Start();

            }
            catch (Exception ex)
            {
                //Logging the exeption
                DiUniversalAdapterExceptionHandler.HandleException(null,
                                                        new DiUniversalAdapterServiceException("Cannot start DiUniversalAdapter Runtime threads!", ex));
                ProcessingCode = (int)RuntimeProcessExitCode.CannotStartRuntimeThreads;
            }

            return processingCode;
        }



        /**
         * Establish conenctions to queues
         */
        private int Connect2Queues()
        {
            int processingCode = (int)RuntimeProcessExitCode.NoError;
            RuntimeProcessHelper theHelper = new RuntimeProcessHelper();
            //Connect to queues
            try
            {
                this.QueuingService = theHelper.EstablishConnections(RuntimeSettings);
            }
            catch (Exception ex)
            {
                //Logging the exception
                DiUniversalAdapterExceptionHandler.HandleException(null, ex);
                processingCode = (int)RuntimeProcessExitCode.ConnecttionError;
            }
            return processingCode;

        }

        /**
         * Parse inputs params passed and get app seetings from app configuration file
         */
        private int ProcessInputParams(string[] args)
        {
            int processingCode = (int)RuntimeProcessExitCode.NoError;
            RuntimeProcessHelper theHelper = new RuntimeProcessHelper();
            //Check parameters received
            try
            {
                RuntimeSettings = theHelper.ProcessReceivedParams(args);
                if (RuntimeSettings == null)
                {
                    //Invalid parametter, stop the process
                    processingCode = (int)RuntimeProcessExitCode.InvalidParamsReceived;

                    //Logging the exeption
                    DiUniversalAdapterExceptionHandler.HandleException(null,
                                                            new DiUniversalAdapterServiceException("Cannot start DiUniversalAdapter Runtime Process. Invalide parameters recceived!"));
                }

            }
            catch (Exception ex)
            {
                //Logging the exeption
                DiUniversalAdapterExceptionHandler.HandleException(null,
                                                        new DiUniversalAdapterServiceException("Cannot start DiUniversalAdapter Runtime Process. Invalide parameters recceived!", ex));
                processingCode = (int)RuntimeProcessExitCode.InvalidParamsReceived;
            }

            if (processingCode != (int)RuntimeProcessExitCode.NoError)
            {
                return processingCode;
            }

            try
            {
                //read parameters from app configure file
                int debug = Int32.Parse(ConfigurationManager.AppSettings[RuntimeAppSettings.Debug.ToString()]);
                IsDebug = (debug == 1);

            }
            catch (Exception sysEx)
            {
                //Logging the exeption
                DiUniversalAdapterExceptionHandler.HandleException(null,
                                                        new DiUniversalAdapterServiceException("Cannot log information for debugging. Invalide Debug setting reading from app configuration file!", sysEx));
            }

            //#region Get runtime  settings
            ////Get params from app configuration file. Currently does not supprot
            //try
            //{
            //    //read parameters from app configure file
            //    RuntimeSettings.RuntimeStartThreads = Int32.Parse(ConfigurationManager.AppSettings[RuntimeAppSettings.RuntimeStartThreads.ToString()]);
            //    //RuntimeSettings.RuntimeProcessTimeOutInMillisecons = Int32.Parse(ConfigurationManager.AppSettings[RuntimeAppSettings.RuntimeProcessTimeOutInMillisecons.ToString()]);

            //}
            //catch (Exception sysEx)
            //{
            //    //Logging the exeption
            //    DiUniversalAdapterExceptionHandler.HandleException(null,
            //                                            new DiUniversalAdapterServiceException("Cannot start DiUniversalAdapter Runtime Process. Invalide parameters reading from app configuration file!", sysEx));
            //    processingCode = (int)RuntimeProcessExitCode.InvalidAppSettings;
            //}
            //#endregion

            return processingCode;
        }

        #endregion Private Methods---------------------------------------------------

        #region Using Task scheduler


        //// TaskScheduler usage
        static int MaximumConcurrency = 0;// 16 * 4 = 64
        static CancellationTokenSource CancellationTokenSource;
        static LimitedConcurrencyLevelTaskScheduler taskScheduler;
        static TaskFactory factory;

        /// <summary>
        /// ProcessRequest start threads managed by TaskScheduler
        /// </summary>
        private void ProcessRequestStart()
        {
            while (LoopFlag)
            {
                if (taskScheduler.QueuedOrWorkingThreadCount >= MaximumConcurrency)
                {
                    Debug.WriteLine("All threads are currently busy ...");
                    Thread.Sleep(10);
                    continue;
                }

                // Process Request In Queue
                ProcessRequestInQueue();
            }
        }

        #endregion
    }
}
