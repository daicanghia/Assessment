﻿using DiCIP.Common.Configuration;
using DiUniversalAdapter.Common.AppException;
using DiUniversalAdapter.Common.Configuration;
using DiUniversalAdapter.Common.ExceptionHandler;
using DiUniversalAdapter.Common.Helper;
using DiUniversalAdapter.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;

namespace DiUniversalAdapter.Runtime
{
    class RuntimeProcessor
    {



        private static int ProcessingCode = (int)RuntimeProcessExitCode.NoError;

        public static AppDomain CurrentAppDomain { get; private set; }
        public static object RuntimeExceptionHandler { get; private set; }

        [SecurityPermission(SecurityAction.InheritanceDemand, Flags = SecurityPermissionFlag.ControlThread)]
        static void Main(string[] args)
        {
            try
            {
                CurrentAppDomain = AppDomain.CurrentDomain;
                CurrentAppDomain.UnhandledException += new UnhandledExceptionEventHandler(UnhandledExceptionHandler);

                //Initialize RuntimeHandler
                DiUniversalAdapterRuntimeHandler runtimeHandler = DiUniversalAdapterRuntimeHandler.GetInstance();
                ProcessingCode = runtimeHandler.Initialize(args);


                if (ProcessingCode == (int)RuntimeProcessExitCode.NoError)
                {
                    Console.Out.WriteLine("DiUniversalAdapter Runtime is running...");
                }

                //Send email notification
                try
                {
                    RuntimeProcessStatus status = RuntimeProcessStatus.Started;
                    if (ProcessingCode != (int)RuntimeProcessExitCode.NoError)
                    {
                        status = RuntimeProcessStatus.Failed2Start;
                    }

                    EmailNotificationHelper emailNotifier = new EmailNotificationHelper();
                    NotificationInfo notificationInfo = emailNotifier.GetProcessStatusNotification(DiUniversalAdapterRuntimeHandler.ProcessID, ProcessingCode, CIPService.DiUniversalAdapter, -1, status);
                    emailNotifier.NotifyUsingEmail(notificationInfo, emailNotifier.GetRecipients(""));
                }
                catch (Exception)
                {

                }

            }
            catch (Exception ex)
            {

                DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("DiUniversalAdapter Runtime Process Error: Innititalize  unhandled exception handler failed!", ex));
            }
        }
        static void UnhandledExceptionHandler(object sender, UnhandledExceptionEventArgs args)
        {
            try
            {
                Exception unhandledEx = (Exception)args.ExceptionObject;
                DiUniversalAdapterExceptionHandler.HandleException(null, new DiUniversalAdapterServiceException("DiUniversalAdapter Runtime Process Error: Unhandled exception cautch and logged!", unhandledEx));

                //Send email notification
                EmailNotificationHelper emailNotifier = new EmailNotificationHelper();

                string serviceName = emailNotifier.GetProcessName(CIPService.DiUniversalAdapter);
                string subject = string.Format("{0} >> {1}", serviceName, "Unhandled exception caught!");
                string logFile = "DiUniversalAdapterRuntimeProcessLog.txt";


                string message = emailNotifier.GetErrorEmailMessage(serviceName, logFile, unhandledEx, CIPNotficationType.UnhandledException);
                NotificationInfo notificationInfo = new NotificationInfo(serviceName, subject, message);
                emailNotifier.NotifyUsingEmail(notificationInfo, emailNotifier.GetRecipients(""));

            }
            catch (Exception)
            {
            }
        }

    }
}
