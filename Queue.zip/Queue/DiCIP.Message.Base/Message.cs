﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DiCIP.Messaging.Base
{
    public class Message
    {
        public int RequestSizeInMB { get; set; }
        public string MessageId { get; set; }
        public IDictionary<string, object> RequestBody { get; set; }
        public string RequestGuid { get; set; }
        public global::DiCIP.Common.Configuration.CIPMessagePriority RequestPriority { get; set; }
        public DateTime SentDateTime { get; set; }
    }
}
