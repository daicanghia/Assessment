﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DiCIP.Common.Configuration;


namespace DiCIP.Common.Models.Message
{
    /**
     * Based message. Messages used to exchange between products/services must extend this base class 
     */
    [Serializable]
    public abstract class CIPBaseMessage : IDisposable
    {
        private bool Disposed { get; set; }

        protected CIPMessagePriority Priority { get; set; }
        protected string MessageId { get; set; }
        protected string RequestId { get; set; }
        protected KeyValuePair<string, string> From { get; set; }
        protected List<KeyValuePair<string, string>> To { get; set; }
        protected CIPMessageBody Body { get; set; }

        public CIPBaseMessage()
        {
            this.Disposed = false;
        }
        public CIPBaseMessage(string id, CIPMessageBody body, CIPMessagePriority priority = CIPMessagePriority.Normal)
            : base()
        {
            this.Disposed = false;
            this.RequestId = id;
            this.MessageId = id;
            this.Body = body;
            this.Priority = priority;
        }
        protected CIPBaseMessage(string id, List<KeyValuePair<object, object>> body)
        {
            this.Disposed = false;
            this.RequestId = id;
            this.MessageId = id;
            this.Body = new CIPMessageBody(body);
        }
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }


        protected virtual void Dispose(bool disposing)
        {
            if (!this.Disposed)
            {

                if (disposing)
                {
                }
                this.Disposed = true;
            }
        }

    }
}
