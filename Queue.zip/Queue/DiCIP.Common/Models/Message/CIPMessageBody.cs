﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiCIP.Common.Models.Message
{
    /**
     * Base class for all classes created as entity class used within CIP
     */
    [Serializable]
    public class CIPMessageBody : object, IDisposable
    {
        private bool Disposed { get; set; }

        public object MessageBody { get; set; }

        public CIPMessageBody()
            : base()
        {

        }
        public CIPMessageBody(object messageBody)
            : base()
        {
            this.MessageBody = messageBody;
        }
        ~CIPMessageBody()
        {
            this.Dispose(true);
        }
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.Disposed)
            {

                if (disposing)
                {
                }
                this.Disposed = true;
            }
        }
    }
}
