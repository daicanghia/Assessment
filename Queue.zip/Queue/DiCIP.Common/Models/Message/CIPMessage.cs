﻿
using System;
using System.Collections.Generic;

namespace DiCIP.Common.Models.Message
{

    /**
     * Based message. Messages used to exchange between products/services must extend this base class 
     */
    [Serializable]
    public abstract class CIPMessage : IDisposable
    {
        private bool Disposed { get; set; }
        protected string MessageId { get; set; }
        protected string RequestId { get; set; }
        protected MessageBody Body { get; set; }

        protected KeyValuePair<string, string> From { get; set; }
        protected List<KeyValuePair<string, string>> To { get; set; }

        public CIPMessage()
        {
            this.Disposed = false;
        }
        public CIPMessage(string id, MessageBody body)
        {
            this.Disposed = false;
            this.RequestId = id;
            this.MessageId = id;
            this.Body = body;
        }
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disposing)
        {
            if (!this.Disposed)
            {

                if (disposing)
                {
                }
                this.Disposed = true;
            }
        }
    }
}
