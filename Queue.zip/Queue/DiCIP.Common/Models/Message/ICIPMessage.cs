﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiCIP.Common.Models.Message
{
    public interface ICIPMessage
    {
        string GetMessageID();
        void SetMessageID(string messageId);

        string GetRequestID();
        void SetRequestID(string requestId);

        MessagePriority GetMessagePriority();

        KeyValuePair<string, string> GetFrom();

        List<KeyValuePair<string, string>> GetTo();

        CIPMessageBody GetBody();

    }
}
