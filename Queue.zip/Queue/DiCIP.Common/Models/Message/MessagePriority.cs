﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiCIP.Common.Models.Message
{
    //
    // Summary:
    //     Specifies the priority Message Queuing applies to a message while it is en route
    //     to a queue, and when inserting the message into the destination queue.
    public enum MessagePriority
    {
        //
        // Summary:
        //     Lowest message priority.
        Lowest = 0,
        //
        // Summary:
        //     Between Low and Lowest message priority.
        VeryLow = 1,
        //
        // Summary:
        //     Low message priority.
        Low = 2,
        //
        // Summary:
        //     Normal message priority.
        Normal = 3,
        //
        // Summary:
        //     Between System.Messaging.MessagePriority.High and System.Messaging.MessagePriority.Normal
        //     message priority.
        AboveNormal = 4,
        //
        // Summary:
        //     High message priority.
        High = 5,
        //
        // Summary:
        //     Between Highest and High message priority.
        VeryHigh = 6,
        //
        // Summary:
        //     Highest message priority.
        Highest = 7
    }
}
