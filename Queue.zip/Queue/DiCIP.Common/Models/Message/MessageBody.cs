﻿using System;

namespace DiCIP.Common.Models.Message
{
    /**
     * Base class for all classes created as entity class used within CIP
     */
    [Serializable]
    public class MessageBody : object, IDisposable
    {

        private bool Disposed { get; set; }


        public MessageBody()
            : base()
        {

        }
        ~MessageBody()
        {
            this.Dispose(true);
        }
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.Disposed)
            {

                if (disposing)
                {
                }
                this.Disposed = true;
            }
        }
    }
}
