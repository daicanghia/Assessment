﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DiCIP.Common.Configuration;

namespace DiCIP.Common.Models.Message
{
    /**
     * Class defined to maanage messages DiUnite using to send/receive to from queueus
     */
    [Serializable]
    public class CIPMSMQMessage : CIPBaseMessage, ICIPMessage, IDisposable
    {
        private bool Disposed { get; set; }
        protected CIPMSMQMessage()
            : base()
        {

        }
        public CIPMSMQMessage(string id, CIPMessageBody body, CIPMessagePriority priority = CIPMessagePriority.Normal)
            : base(id, body, priority)
        {
            this.Disposed = false;
        }

        #region public Methods---------------------------------------------------------  
        public string GetMessageID()
        {
            return this.MessageId;
        }
        public void SetMessageID(string messageId)
        {
            this.MessageId = messageId;
        }

        public string GetRequestID()
        {
            return this.RequestId;
        }
        public void SetRequestID(string requestId)
        {
            this.RequestId = requestId;
        }

        public MessagePriority GetMessagePriority()
        {
            return (MessagePriority)this.Priority;
        }
        public KeyValuePair<string, string> GetFrom()
        {
            return this.From;
        }

        public List<KeyValuePair<string, string>> GetTo()
        {
            return this.To;
        }

        public CIPMessageBody GetBody()
        {
            return this.Body;
        }

        #endregion public Methods---------------------------------------------------------

        protected override void Dispose(bool disposing)
        {
            if (!this.Disposed)
            {

                if (disposing)
                {
                    //TODO: Dispose managed resources here if any
                }
                this.Disposed = true;
                base.Dispose(disposing);
            }
        }


    }
}
