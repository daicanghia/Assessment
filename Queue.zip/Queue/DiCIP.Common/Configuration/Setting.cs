﻿using System;
using System.Collections.Generic;

namespace DiCIP.Common.Configuration
{
    /*
     * Key-value pair setting
     */
    public class Setting : ISetting, IDisposable
    {
        private bool Disposed { get; set; }
        public KeyValuePair<string, string> Data { get; set; }

        public Setting(KeyValuePair<string, string> data)
        {
            this.Data = data;
        }
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }
        public KeyValuePair<string, string> GetData()
        {
            return this.Data;

        }
        public string GetKey()
        {
            return this.Data.Key;
        }

        public string GetValue()
        {
            return this.Data.Value;
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.Disposed)
            {

                if (disposing)
                {

                }
                this.Disposed = true;
            }
        }
    }
}
