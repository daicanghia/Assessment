﻿using System;
using System.Collections.Generic;

namespace DiCIP.Common.Configuration
{

    /**
      * Class defined to manage settings of CIP configuration.
      */
    public class CIPConfiguration : BaseConfiguration, ICIPConfiguration, IDisposable
    {
        private bool Disposed { get; set; }

        public CIPConfiguration()
            : base()
        {
            this.Disposed = false;
        }
        public CIPConfiguration(List<ISetting> settings)
            : base(settings)
        {
            this.Disposed = false;
        }

        public void Add(ISetting setting)
        {
            base.AddSetting(setting);
        }

        public void Remove(string key)
        {
            base.RemoveSetting(key);
        }
        public ISetting GetAt(int i)
        {
            return base.GetSettingAt(i);
        }
        public ISetting GetByKey(string key)
        {
            return base.GetSetting(key);
        }
        public List<ISetting> GetConfiguration()
        {
            return base.Getettings();
        }

        protected void Dispose(bool disposing)
        {
            if (!this.Disposed)
            {
                if (disposing)
                {

                }
                this.Disposed = true;
                base.Dispose(disposing);
            }
        }
    }
}
