﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiCIP.Common.Configuration
{
    public interface ICIPConfiguration
    {
        void Add(ISetting setting);
        void Remove(string key);
        ISetting GetByKey(string key);
        ISetting GetAt(int i);
        List<ISetting> GetConfiguration();
    }
}
