﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiCIP.Common.Configuration
{

    /**
     * Class defined to manage settings of DiUniversalAdapter Services. The settings ecpected are in key-pair values as folowing
     * InboundQueue, OutboundQueue, ErrorQueue, CollaborativeQueue
     */
    public class DiUniversalAdapterConfigure : BaseConfiguration, ICIPConfiguration, IDisposable
    {
        private bool Disposed { get; set; }

        public DiUniversalAdapterConfigure()
            : base()
        {
            this.Disposed = false;
        }
        public DiUniversalAdapterConfigure(List<ISetting> settings)
            : base(settings)
        {
            this.Disposed = false;
        }

        public void Add(ISetting setting)
        {
            base.AddSetting(setting);
        }

        public void Remove(string key)
        {
            base.RemoveSetting(key);
        }
        public ISetting GetAt(int i)
        {
            return base.GetSettingAt(i);
        }
        public ISetting GetByKey(string key)
        {
            return base.GetSetting(key);
        }
        public List<ISetting> GetConfiguration()
        {
            return base.Getettings();
        }


        protected override void Dispose(bool disposing)
        {
            if (!this.Disposed)
            {
                if (disposing)
                {

                }
                this.Disposed = true;
                base.Dispose(disposing);
            }
        }

    }
}
