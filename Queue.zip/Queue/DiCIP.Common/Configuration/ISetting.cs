﻿using System.Collections.Generic;

namespace DiCIP.Common.Configuration
{
    /**
     *  ISetting
     */
    public interface ISetting

    {
        KeyValuePair<string, string> GetData();
        string GetKey();
        string GetValue();

    }
}
