﻿using System.Collections.Generic;

namespace DiCIP.Common.Configuration
{
    public interface IConfiguration
    {
        void Add(ISetting setting);
        void Remove(string key);
        ISetting GetByKey(string key);
        ISetting GetAt(int i);
        List<ISetting> GetConfiguration();
    }
}
