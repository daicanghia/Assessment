﻿using DiCIP.Common.AppException;
using DiCIP.Common.Models.Message;
using System;
using System.Collections.Generic;

namespace DiCIP.Common.Configuration
{
    /**
      * Base classes define for managing CIP configuration and seetings
      */
    [Serializable]
    public class BaseConfiguration : IDisposable
    {
        private bool Disposed { get; set; }
        protected List<ISetting> Settings { get; set; }

        protected BaseConfiguration()
        {
            this.Disposed = false;
            this.Settings = new List<ISetting>();
        }
        protected BaseConfiguration(List<ISetting> settings)
        {
            this.Disposed = false;
            this.Settings = settings;
        }
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disposing)
        {
            if (!this.Disposed)
            {

                if (disposing)
                {
                    foreach (ISetting item in this.Settings)
                    {
                        if (item is IDisposable)
                        {
                            ((IDisposable)item).Dispose();
                        }
                    }
                }
                this.Disposed = true;
            }
        }
        protected virtual void AddSetting(ISetting setting)
        {
            try
            {
                if (!this.Contains(setting.GetKey()))
                {
                    this.Settings.Add(setting);
                }
                else
                {
                    throw new DiCIPException("An element with the same key already exists!", QueuingServiceErrorCode.A2AR99999999999E);
                }
            }
            catch (Exception ex)
            {
                //Throw the exception as we don't handle it i the common lib
                throw new DiCIPException(ex);
            }
        }
        protected virtual void RemoveSetting(string key)
        {
            try
            {
                int count = this.Settings.Count;
                ISetting removedItem = null;
                for (int i = 0; i < count; i++)
                {
                    removedItem = this.Settings[i];
                    if (removedItem.GetKey() == key)
                    {
                        this.Settings.RemoveAt(i);
                        i = count;
                    }
                }
            }
            catch (Exception ex)
            {
                //Throw the exception as we don't handle it i the common lib
                throw new DiCIPException(ex);
            }
        }

        protected virtual ISetting GetSettingAt(int i)
        {
            return this.Settings[i];
        }
        protected virtual ISetting GetSetting(string key)
        {
            ISetting returnValue = null;
            try
            {
                List<ISetting> foundSettings = this.Settings.FindAll(x => x.GetKey() == key);

                if ((foundSettings != null) && foundSettings.Count > 0)
                {
                    returnValue = foundSettings[0];
                }

            }
            catch (Exception ex)
            {
                //Throw the exception as we don't handle it i the common lib
                throw new DiCIPException(ex);

            }
            return returnValue;
        }

        protected virtual List<ISetting> Getettings()
        {
            return this.Settings;
        }

        protected virtual bool Contains(string key)
        {
            bool returnValue = false;
            try
            {
                ISetting foundSetting = this.Settings.Find(x => x.GetKey() == key);
                returnValue = ((foundSetting != null) && (foundSetting.GetKey() == key));
            }
            catch (Exception ex)
            {
                //Throw the exception as we don't handle it i the common lib
                throw new DiCIPException(ex);
            }
            return returnValue;
        }
    }


    /**
     * DiUniversalAdapterRuntimeProcessStatus
     */
    public enum QueueType
    {
        DataBase,
        Mememory,
        MSMQ,
    }
    public enum CIPService
    {
        DiConnect,
        DiUniversalAdapter,
        DiTranslator,
        DiTest,
        DiWeb,
        Unknown
    }
    public enum CIPMessageType
    {
        Inbound = 1,    // Indicate that message is a request and should be sent to Inbound queue
        Outbound,       // Indicate that message is a request result and should be sent to Oundbound queue
        Error,          // Indicate that message is a request error and should be sent to Error  queue 
        Collaboration,   // Indicate that message is a collaborative request and should be sent to collaborative queue
        Unknown
    }
    /**
   * Each service has 4 queues defined as CIPMessageType
   */
    public enum CIPQueues
    {
        Inbound = 1,    // Indicate that message is a request and should be sent to Inbound queue
        Outbound,       // Indicate that message is a request result and should be sent to Oundbound queue
        Error,          // Indicate that message is a request error and should be sent to Error  queue 
        Collaboration,   // Indicate that message is a collaborative request and should be sent to collaborative queue
        Notification
    }
    public enum CIPMessageProperty
    {
        RecoverableMessage = 1,
        BinaryFormat,
        XMLFormat
    }

    public enum CIPMessagePriority
    {
        Lowest = MessagePriority.Lowest,
        Low = MessagePriority.Low,
        Normal = MessagePriority.Normal,
        High = MessagePriority.High,
        Highest = MessagePriority.Highest,
    }
    public enum DefaultQueueSettings
    {
        PeakTimeout = 100,                       // In millisecond
        ReceiveTimeout = 100,                   // In millisecond
        ReceiveRequestMessageInterval = 200,    // In millisecond
        ReceiveControlMessageInterval = 1000,   // In millisecond
    }

    public sealed class CIPQueuingServiceConsts
    {
        /**
         * Subqueue naming convenrion
         */
        public static readonly string SubQueueNamingConvention = @"{0}_{1}";
        public static readonly string ProcessSubQueueCollaborationNamingConvention = @"{0}_{1}";
        public static readonly string ContainerSubQueueCollaborationNamingConvention = @"{0}";
        public static readonly string QueuePrefix = @"FormatName:";
        public static readonly char SubQueueSeparator = ';';

        /**
         * Connection string used for local queue
         */
        public static readonly string LocalConnectionString = @"{0}\Private$\{1}";

        /**
        * Connection string using machine IP
        */
        public static readonly string MachineIPConnectionString = @"FormatName:Direct=TCP:{0}\private$\{1}";

        /**
        * Connection string using machine name
        */
        public static readonly string MachineNameConnectionString = @"FormatName:Direct=OS:{0}\private$\{1}";
    }



    #region CIP Services
    public enum CIPServices
    {
        DiCIPInbound = 0,
        DiCIPOutbound,
        DiConnect,
       // DiUnite,
        DiUniversalAdapter,
        DiTranslator,
        DiTest,
        DiWeb,
        DiDropShip,
        ProcessCollaboration,
        Unknown
    }
    #endregion CIP Services


    #region CIP Caching Service
    public sealed class CIPCachingServiceConsts
    {
        /**
         * Key fortmated as <serverId>_<FileTransferClientId> used to cache server capacity.
         */
        public static readonly string FileDeliveryKey = @"{0}_{1}";

        /*
        * Stored procedure used to capacity of a user
        */
        public static readonly string ps_UpdateClientUserCapacity = "UpdateClientUserCapacity";
        public static readonly string param_ClientServerId = "@ClientServerId";
        public static readonly string param_ClientUserServerId = "@ClientUserServerId";
        public static readonly string param_Increase = "@Increase";
        public static readonly string param_OutMessage = "@OutMessage";
        public static readonly string param_UpdatedCurrentCapacity = "@UpdatedCurrentCapacity";
        public static readonly string param_Return = "@ErrorCode";

    }

    public enum CIPCacheType
    {
        NotDefined = 1,
        AppFabricCache,
        DatabaseCache,
    }
    public enum CIPDefaultCachingSettings
    {
        Timeout = 60000,                        // In millisecond. 1 minute timeout to ensure the lock is still obtained until oeration completes
        Retry = 3                               //Try to get data cached three times if failed.  
    }
    public enum CIPGlobalCachingKey
    {
        CIPInboundService = 1,                              //Used to cache status of Inbound Service
        CIPDiUniteService,                                  //Used to cache status of DiUnite Service
        CIPOutboundClientServerUserCapacities,              // Used to cache Client Server User Capacities. See class ClientServerUserCapacities for details.

    }

    public enum CIPGlobalMutexName
    {
        CIPOutboundDeliveryPreprocess = 1,                  //Used to increase capacity
        CIPOutboundDeliveryPostprocess,                     //Used to decrease capacity
    }

    #endregion CIP Caching Service


    #region CIP Runtime Process
    public enum CIPRuntimeSettings
    {
        //Settings defined for Runtime Process
        ProcessID,
        Debug,
        LogFolder,
        RuntimeProcessFileName,
        MaxRuntimeProcesses,
        RuntimeProcesses,
        RuntimeProcessesBackgroundMode,

        //Settings defined for MSMQ
        ServerMSMQ,
        InboundQueue,
        OutboundQueue,
        ErrorQueue,
        CollaborativeQueue,
        ReceivingResultTimerInMillisecons,
        ReceivingRequestTimerInMillisecons,
        ReceivingCommandTimerInMillisecons,

        //Settings defined for SB
        ServerSB,

        //Setting defined for Caching 
        AppFabricCacheEnable,
        AppFabricCacheServer,
        AppFabricCacheServerPort,

        DatabaseCacheEnable,
        DatabaseCacheConnString,

        CacheTimeoutInMiliseconds,
        CacheRetry,

    }
    #endregion CIP Runtime Process
}
