﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace DiCIP.Common.AppException
{
    public enum QueueErrorCode
    {
        NoError = 0,
        EmptyQueue = 1,
        MessageNotFound = 2,
        QueueError = 3
    }
    public enum CachingStatusCode
    {
        NotDefined = 0,
        NoObjectCached,
        ObjectCached,
        ObjectFound,
        ObjectOverrided,
        ObjectLocked,
        ObtainLockSuccess,
        ObtainLockFailed,
        ObjectCachedSuccess,
        ObjectLockedOrTimeout,
        UnlockSucess
    }

    //public enum QueueErrorCode
    //{
    //    NoError = 0,
    //    EmptyQueue = 1,
    //    MessageNotFound = 2,
    //    QueueError = 3
    //}

    public enum ProcessExitCode
    {
        NoError = 0,
        InvalidParams,
        ConnecttionError,
        ProcessStopped,

    }

    /// <summary>
    /// Queuing Service Error Code
    /// </summary>
    public enum QueuingServiceErrorCode
    {
        NoError,
        A2AR01001001001E,
        A2AR01002001001W,
        A2AR01002001002W,
        A2AR01002001003W,
        A2AR01002001004W,
        A2AR01002001005W,
        A2AR01002002001W,
        A2AR01002002002W,
        A2AR01002002003W,
        A2AR01002002004E,
        A2AR01002002005W,
        A2AR01002002006W,
        A2AR01003001001E,
        A2AR01003001002E,
        A2AR01003001003E,
        A2AR01003002001E,
        A2AR01004001001E,
        A2AR01004002001E,
        A2AR01004002002E,
        A2AR01004003001E,
        A2AR01004003002E,
        A2AR01004003003E,
        A2AR01004004001E,
        A2AR01004005001E,
        A2AR01004006001E,
        A2AR01004006002E,
        A2AR01004006003E,
        A2AR01004006004E,
        A2AR01004007001E,
        A2AR01004008001E,
        A2AR01004008002E,
        A2AR01004009001E,
        A2AR01004009002E,
        A2AR01005001001E,
        A2AR01005002001E,
        A2AR01006001001E,
        A2AR01006002001E,
        A2AR01006003001E,
        A2AR01006003002E,
        A2AR01006003003E,
        A2AR01006004001E,
        A2AR01006005001E,
        A2AR01006005002E,
        A2AR01006006001E,
        A2AR01007001001E,
        A2AR01007002001E,
        A2AR01007003001E,
        A2AR01007004001E,
        A2AR01007005001E,
        A2AR01007006001E,
        A2AR01007007001E,
        A2AR01007008001E,
        A2AR99999999999E
    }

    [Serializable]
    public class DiCIPException : System.Exception
    {
        public string ErrorMessage { get; set; }
        public QueueErrorCode MessageQueueErrorCode { get; set; }
        public QueuingServiceErrorCode QueuingServiceErrorCode { get; set; }
        protected List<DiCIPException> InnerErrors { get; set; }
        public string SystemMessage
        {
            get
            {
                return base.Message;
            }
        }
        public string ErrorStackTrace
        {
            get
            {
                if (base.StackTrace != null)
                {
                    return base.StackTrace.ToString();
                }
                else
                {
                    return "";
                }
            }
        }
        public DiCIPException()
            : base()
        {

        }
        public DiCIPException(string errorMessage)
        {
            this.ErrorMessage = errorMessage;
        }
        public DiCIPException(string errorMessage, QueuingServiceErrorCode queuingServiceErrorCode)
        {
            this.ErrorMessage = errorMessage;
            this.QueuingServiceErrorCode = queuingServiceErrorCode;
        }

        public DiCIPException(System.Exception sysEx)
            : base("CIP Error: ", sysEx)
        {

        }

        public DiCIPException(string errorMessage, System.Exception sysEx)
           : base("CIP Error: ", sysEx)
        {
            this.ErrorMessage = errorMessage;
        }

        public DiCIPException(string errorMessage, QueuingServiceErrorCode queuingServiceErrorCode, System.Exception sysEx)
            : base("CIP Error: ", sysEx)
        {
            this.ErrorMessage = errorMessage;
            this.QueuingServiceErrorCode = queuingServiceErrorCode;
        }
        public DiCIPException(QueueErrorCode errorCode, string errorMessage, QueuingServiceErrorCode queuingServiceErrorCode, System.Exception sysEx)
      : base("CIP Error: ", sysEx)
        {
            this.MessageQueueErrorCode = errorCode;
            this.ErrorMessage = errorMessage;
            this.QueuingServiceErrorCode = queuingServiceErrorCode;
        }

        public DiCIPException(QueueErrorCode errorCode, string errorMessage, System.Exception sysEx)
           : base(sysEx.Message, sysEx)
        {
            this.MessageQueueErrorCode = errorCode;
            this.ErrorMessage = errorMessage;
        }
        public DiCIPException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {

        }
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            if (this.InnerErrors != null)
            {
                info.AddValue(this.ErrorMessage, InnerErrors);
            }
            base.GetObjectData(info, context);
        }
        public void AddInnerError(DiCIPException error)
        {
            if (this.InnerErrors == null)
            {
                this.InnerErrors = new List<DiCIPException>();
            }
            this.InnerErrors.Add(error);
        }
        public List<DiCIPException> GetInnerErrors()
        {
            return this.InnerErrors;

        }
    }
}