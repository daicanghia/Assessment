﻿using DiCIP.Common.AppException;
using System;

namespace DiCIP.Common.ExceptionHandler
{

    /**
     * Place holder for exception handling code
     */
    public class DiCIPExceptionHandler
    {
        public static void HandleExceptionExt(DiCIPException ex)
        {
            //Console.Out.WriteAsync(ex.Message);
        }
        public static void HandleExceptionExt(Exception ex)
        {
            //Console.Out.WriteAsync(ex.Message);
        }

    }
}