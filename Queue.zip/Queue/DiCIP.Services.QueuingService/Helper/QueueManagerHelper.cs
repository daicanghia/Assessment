﻿
using DiCIP.Common.AppException;
using System;
using System.Configuration;

namespace DiCIP.Services.QueingService.Helper
{
    public class QueueManagerHelper
    {

        public string GenerateQueueName(String serviceName, String messageType)
        {
            return String.Format("{0}.{1}", serviceName, messageType);
        }

        public string ReadAppSettings(string appSetting)
        {
            string serverMSMQ = "";

            //Read ServerSB
            try
            {
                //try getting server from config file
                serverMSMQ = ConfigurationManager.AppSettings[appSetting];
            }
            catch (Exception sysEx)
            {
                throw new DiCIPException(string.Format("Cannot read application setting {0}", appSetting), QueuingServiceErrorCode.A2AR99999999999E, sysEx);
            }
            return serverMSMQ;
        }

        #region Private Methods---------------------------------------------------------
        private bool IsIPAddress(string serverMSMQ)
        {
            bool retVal = false;
            System.Net.IPAddress ipAddress = null;
            try
            {
                retVal = System.Net.IPAddress.TryParse(serverMSMQ, out ipAddress);
            }
            catch (Exception)
            {
                //Just need to ensure the system does not crash.
            }
            return retVal;
        }
        #endregion Private Methods---------
    }
}
