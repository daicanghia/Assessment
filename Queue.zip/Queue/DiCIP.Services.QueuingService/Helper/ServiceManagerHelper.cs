﻿
using System;


using DiCIP.Common.AppException;
using DiCIP.Common.Configuration;
using DiCIP.Services.QueuingService;
using DiCIP.Services.QueuingService.Queue.DiUniversalAdapter;
using DiCIP.Services.QueuingService.Queue;
using DiCIP.Services.QueuingService.Queue.ServiceBus;

namespace DiCIP.Services.QueingService.Helper
{
    /**
     * Helper class provides functionalities to help managing Queue Service Manager. It is stateless for thread-safe
     */
    internal class ServiceManagerHelper
    {
        internal IQueueManager InitializeQueueManager(string queueServerAddress, CIPServices service)
        {
            IQueueManager queueManager = null;
            ICIPConfiguration config = null;
            IMSMQQueueServiceConfiguration configBuider = null;

            QueueManagerHelper managerHelper = new QueueManagerHelper();
            if (string.IsNullOrEmpty(queueServerAddress))
            {
                queueServerAddress = managerHelper.ReadAppSettings(CIPRuntimeSettings.ServerMSMQ.ToString());
            }
            // thinh : bool isRemoteQueue = managerHelper.IsRemoteQueue(queueServerAddress);
            switch (service)
            {
                case CIPServices.DiUniversalAdapter:
                    configBuider = new DiUniversalAdapterQueueServiceConfiguration();
                    config = configBuider.GetDefautConfiguration(queueServerAddress, service);
                    // thinh : queueManager = new DiUniteQueuesManager(queueServerAddress, config, isRemoteQueue);
                    queueManager = new DiUniversalAdapterQueuesManager(queueServerAddress, config);//thinh added
                    break;
                case CIPServices.DiConnect:
                    throw new DiCIPException("CIP Queuing Service Error: Current version does not support DiConnect!");
                case CIPServices.DiTest:
                    throw new DiCIPException("CIP Queuing Service Error: Current version does not support DiTest!");
                case CIPServices.DiTranslator:
                    throw new DiCIPException("CIP Queuing Service Error:Current version does not support DiTranslator!");
                case CIPServices.DiWeb:
                    throw new DiCIPException("CIP Queuing Service Error:Current version does not support DiWeb!");
                default:
                    throw new DiCIPException("CIP Queuing Service Error: No Service specyfied!");

            }
            if (queueManager != null)
            {
                queueManager.Start();
            }

            return queueManager;

        }
        internal IQueueManager InitializeQueueManager(CIPServices service, ICIPConfiguration config)
        {
            //Support local queues only
            IQueueManager queueManager = null;
            switch (service)
            {
                case CIPServices.DiUniversalAdapter:
                    queueManager = new DiUniversalAdapterQueuesManager(null, config);
                    queueManager.Start();
                    break;
                case CIPServices.DiConnect:
                    throw new DiCIPException("CIP Queuing Service Error: Current version does not support DiConnect!");
                case CIPServices.DiTest:
                    throw new DiCIPException("CIP Queuing Service Error: Current version does not support DiTest!");
                case CIPServices.DiTranslator:
                    throw new DiCIPException("CIP Queuing Service Error: Current version does not support DiTranslator!");
                case CIPServices.DiWeb:
                    throw new DiCIPException("CIP Queuing Service Error: Current version does not support DiWeb!");
                default:
                    throw new DiCIPException("CIP Queuing Service Error: No Service specyfied!");

            }
            return queueManager;
        }
        internal void StopQueueManager(CIPServices service)
        {
            IQueueManager queueManager = null;

            try
            {
                queueManager = CentralQueueManager.GetCentralQueueManager().GetQueuingService(service);
                if (queueManager != null)
                {
                    queueManager.Stop();

                }
                else
                {
                    throw new DiCIPException(String.Format("CIP Queuing Service warning: Cannot stop service manager for  {0} Service. Service not found!", service.ToString()));
                }
            }
            catch (DiCIPException)
            {
                throw;
            }
            catch (Exception sysEx)
            {
                throw new DiCIPException(String.Format("CIP Queuing Service Error: Cannot stop service manager for {0} Service", service.ToString()), sysEx);
            }
        }
    }
}
