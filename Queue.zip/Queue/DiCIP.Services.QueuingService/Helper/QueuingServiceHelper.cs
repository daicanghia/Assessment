﻿using DiCIP.Common.AppException;
using DiCIP.Common.Configuration;
using DiCIP.Services.QueuingService;
using DiCIP.Services.QueuingService.Queue;

namespace DiCIP.Services.QueingService.Helper
{
    internal class QueuingServiceHelper
    {
        internal ICIPQueue GetQueue(CIPServices service, CIPQueues messageType)
        {
            ICIPQueue theQueue = null;

            IQueueManager queueManager = CentralQueueManager.GetCentralQueueManager().GetQueuingService(service);
            if (queueManager == null)
            {
                string errorMessage = string.Format("Queuing Service for {0} ! is not available!", service.ToString());
                throw new DiCIPException(errorMessage);
            }
            else
            {
                theQueue = queueManager.GetQueueByType(messageType);
            }

            return theQueue;
        }
    }
}
