﻿using DiCIP.Common.Configuration;
using DiCIP.Common.Models.Message;
using System.Collections.Generic;

namespace DiCIP.Services.QueuingService
{
    public interface IQueuingService
    {
        void InitQueuingService(List<KeyValuePair<string, ICIPConfiguration>> services2Start);

        void InitQueuingService(string queueServerAddress, List<CIPServices> services2Start);

        void StopQueuingService(List<CIPServices> services2Stop);

        List<string> GetSubQueues(CIPServices service, CIPQueues messageType);
        void SendMessages(CIPServices service, CIPQueues messageType, List<ICIPMessage> messages);
        string SendMessage(CIPServices service, CIPQueues messageType, ICIPMessage message);
        string SendMessage(CIPServices service, CIPQueues messageType, ICIPMessage message, string subQueue);
        ICIPMessage PeakMessage(CIPServices service, CIPQueues messageType);
        ICIPMessage ReceiveMessage(CIPServices service, CIPQueues messageType);
        ICIPMessage ReceiveMessage(CIPServices service, CIPQueues messageType, string subQueue);
        ICIPMessage RetrieveMessage(CIPServices service, CIPQueues messageType, string requestId);
        ICIPMessage RetrieveMessageByRequestId(CIPServices service, CIPQueues messageType, string requestId);
        ICIPMessage RetrieveMessageByMesssageId(CIPServices service, CIPQueues messageType, string messageId);


    }
}
