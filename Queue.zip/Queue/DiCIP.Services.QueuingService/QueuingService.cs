﻿

using DiCIP.Common.AppException;
using DiCIP.Common.Configuration;
using DiCIP.Common.Models.Message;
using DiCIP.Services.QueingService.Helper;
using DiCIP.Services.QueuingService.Queue;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace DiCIP.Services.QueuingService
{
    public class QueuingService : IQueuingService
    {
        public QueuingService()
        {

        }
        /**
        * Start CIP Queuing Service using default configuration 
        */
        public void InitQueuingService(string queueServerAddress, List<CIPServices> services2Start)
        {
            try
            {
                CentralQueueManager.InitCentralQueueManager().StartQueuingService(queueServerAddress, services2Start);

            }
            catch (DiCIPException)
            {
                throw;

            }
            catch (Exception sysEx)
            {
                throw new DiCIPException("CIP Queuing Service errors: Cannot start CIP Queuing Service!", sysEx);
            }
        }

        /**
         * Start CIP Queuing Service per given configuration 
         */
        public void InitQueuingService(List<KeyValuePair<string, ICIPConfiguration>> services2Start)
        {
            try
            {
                CentralQueueManager.InitCentralQueueManager().StartQueuingService(services2Start);

            }
            catch (DiCIPException)
            {
                throw;

            }
            catch (Exception sysEx)
            {
                throw new DiCIPException("CIP Queuing Service errors: Cannot start CIP Queuing Service!", sysEx);
            }
        }


        public string SendMessage(CIPServices service, CIPQueues messageType, ICIPMessage message)
        {

            try
            {
                string messageSentId = null;
                QueuingServiceHelper theHelper = new QueuingServiceHelper();
                ICIPQueue theQueue = theHelper.GetQueue(service, messageType);
                messageSentId = theQueue.Send(message);
                return messageSentId;

            }
            catch (DiCIPException)
            {
                throw;
            }
            catch (Exception sysEx)
            {
                string errorMessage = string.Format("{0} Queuing Service cannot send message to queue!", service.ToString());
                throw new DiCIPException(errorMessage, sysEx);
            }
        }
        public string SendMessage(CIPServices service, CIPQueues messageType, ICIPMessage message, string subQueue)
        {
            try
            {
                string messageSentId = null;
                QueuingServiceHelper theHelper = new QueuingServiceHelper();
                ICIPQueue theQueue = theHelper.GetQueue(service, messageType);
                messageSentId = theQueue.Send(message, subQueue);
                return messageSentId;

            }
            catch (DiCIPException)
            {
                throw;
            }
            catch (Exception sysEx)
            {

                string errorMessage = string.Format("Queuing Service cannot send message to queue {0},{1}!", service.ToString(), subQueue);
                throw new DiCIPException(errorMessage, sysEx);
            }
        }
        public ICIPMessage PeakMessage(CIPServices service, CIPQueues messageType)
        {
            ICIPMessage message = null;
            try
            {
                QueuingServiceHelper theHelper = new QueuingServiceHelper();
                ICIPQueue theQueue = theHelper.GetQueue(service, messageType);
                message = theQueue.Peak();
            }
            catch (DiCIPException)
            {
                throw;
            }
            catch (Exception sysEx)
            {
                QueueManagerHelper managerHelper = new QueueManagerHelper();
                string errorMessage = string.Format("Cannot peak message from queue {0} !",
                    managerHelper.GenerateQueueName(service.ToString(), messageType.ToString()));
                DiCIPException appEx = new DiCIPException(errorMessage, sysEx);
                throw appEx;
            }

            return message;
        }

        public ICIPMessage ReceiveMessage(CIPServices service, CIPQueues messageType)
        {
            ICIPMessage message = null;
            try
            {
                QueuingServiceHelper theHelper = new QueuingServiceHelper();
                ICIPQueue theQueue = theHelper.GetQueue(service, messageType);
                message = theQueue.Receive();
            }
            catch (DiCIPException)
            {
                throw;
            }
            catch (Exception sysEx)
            {
                QueueManagerHelper managerHelper = new QueueManagerHelper();
                string errorMessage = string.Format("Cannot receive message from queue {0} !",
                    managerHelper.GenerateQueueName(service.ToString(), messageType.ToString()));
                DiCIPException appEx = new DiCIPException(errorMessage, sysEx);
                throw appEx;
            }

            return message;
        }

        public ICIPMessage ReceiveMessage(CIPServices service, CIPQueues messageType, string subQueue)
        {
            ICIPMessage message = null;
            try
            {
                QueuingServiceHelper theHelper = new QueuingServiceHelper();
                ICIPQueue theQueue = theHelper.GetQueue(service, messageType);
                message = theQueue.Receive(subQueue);
            }
            catch (DiCIPException)
            {
                throw;
            }
            catch (Exception sysEx)
            {
                QueueManagerHelper managerHelper = new QueueManagerHelper();
                string errorMessage = string.Format("Cannot receive message from queue {0};{1}!",
                    managerHelper.GenerateQueueName(service.ToString(), messageType.ToString()), subQueue);
                DiCIPException appEx = new DiCIPException(errorMessage, sysEx);
                throw appEx;
            }

            return message;
        }
        public ICIPMessage RetrieveMessage(CIPServices service, CIPQueues messageType, string requestId)
        {
            ICIPMessage message = null;
            try
            {

                QueuingServiceHelper theHelper = new QueuingServiceHelper();
                ICIPQueue theQueue = theHelper.GetQueue(service, messageType);
                message = theQueue.RetrieveResult(messageType, requestId);
                return message;
            }
            catch (DiCIPException)
            {

                throw;
            }
            catch (Exception sysEx)
            {
                QueueManagerHelper managerHelper = new QueueManagerHelper();
                string errorMessage = string.Format("Cannot receive message from queue {0} !",
                    managerHelper.GenerateQueueName(service.ToString(), messageType.ToString()));
                DiCIPException appEx = new DiCIPException(errorMessage, sysEx);
                throw appEx;
            }
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public ICIPMessage RetrieveMessageByMesssageId(CIPServices service, CIPQueues messageType, string messageId)
        {
            ICIPMessage message = null;
            try
            {

                QueuingServiceHelper theHelper = new QueuingServiceHelper();
                ICIPQueue theQueue = theHelper.GetQueue(service, messageType);
                message = theQueue.RetrieveResultByMessageId(messageType, messageId);
                return message;

            }
            catch (DiCIPException)
            {

                throw;
            }
            catch (Exception sysEx)
            {
                QueueManagerHelper managerHelper = new QueueManagerHelper();
                string errorMessage = string.Format("Cannot retrieve message from queue {0} !",
                    managerHelper.GenerateQueueName(service.ToString(), messageType.ToString()));
                DiCIPException appEx = new DiCIPException(errorMessage, sysEx);
                throw appEx;
            }
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public ICIPMessage RetrieveMessageByRequestId(CIPServices service, CIPQueues messageType, string requestId)
        {
            ICIPMessage message = null;
            try
            {
                QueuingServiceHelper theHelper = new QueuingServiceHelper();
                ICIPQueue theQueue = theHelper.GetQueue(service, messageType);
                message = theQueue.RetrieveResultByRequestId(messageType, requestId);

            }
            catch (DiCIPException)
            {

                throw;
            }
            catch (Exception sysEx)
            {
                QueueManagerHelper managerHelper = new QueueManagerHelper();
                string errorMessage = string.Format("Cannot retrieve message from queue {0} !",
                    managerHelper.GenerateQueueName(service.ToString(), messageType.ToString()));
                DiCIPException appEx = new DiCIPException(errorMessage, sysEx);
                throw appEx;
            }

            return message;
        }
        public void StopQueuingService(List<CIPServices> services2Stop)
        {
            try
            {
                CentralQueueManager.GetCentralQueueManager().StopQueuingService(services2Stop);
                CentralQueueManager.UninitCentralQueueManager();


            }
            catch (DiCIPException)
            {
                throw;
            }
            catch (Exception sysEx)
            {
                throw new DiCIPException("Cannot stop CIP Queuing Service!", sysEx);
            }
        }
        public List<string> GetSubQueues(CIPServices service, CIPQueues messageType)
        {
            List<string> subQueues = null;
            try
            {
                QueuingServiceHelper theHelper = new QueuingServiceHelper();
                ICIPQueue theQueue = theHelper.GetQueue(service, messageType);
                subQueues = theQueue.GetSubQueues();

            }
            catch (DiCIPException)
            {
                throw;
            }
            catch (Exception sysEx)
            {
                throw new DiCIPException("Cannot stop CIP Queuing Service!", sysEx);
            }
            return subQueues;
        }

        public void SendMessages(CIPServices service, CIPQueues messageType, List<ICIPMessage> messages)
        {
            try
            {
                //string messageSentId = null;
                QueuingServiceHelper theHelper = new QueuingServiceHelper();
                ICIPQueue theQueue = theHelper.GetQueue(service, messageType);
                theQueue.Send(messages);

            }
            catch (DiCIPException)
            {
                throw;
            }
            catch (Exception sysEx)
            {

                string errorMessage = string.Format("Queuing Service cannot send message to queue {0}!", service.ToString());
                throw new DiCIPException(errorMessage, sysEx);
            }
        }
    }
}
