﻿using DiCIP.Common.Configuration;
using System;

namespace DiCIP.Services.QueuingService.Queue
{
    /**
     * Base class. A queue can be either MSMS queue, database queue or memory/file
     */
    public abstract class BaseQueue : IDisposable
    {
        protected ISetting ConnectionString { get; set; }
        protected string QueueID { get; set; }

        private bool Disposed { get; set; }
        ~BaseQueue()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        public BaseQueue(ISetting connectionStrings)
        {
            this.QueueID = Guid.NewGuid().ToString();
            this.Disposed = false;
            this.ConnectionString = connectionStrings;
        }
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disposing)
        {
            if (!this.Disposed)
            {

                if (disposing)
                {
                    //TODO: Code to dispose managed resources
                }
                this.Disposed = true;
            }
        }


    }
}
