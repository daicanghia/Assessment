﻿using DiCIP.Common.AppException;
using DiCIP.Common.Configuration;
using System;
using System.Collections.Generic;

namespace DiCIP.Services.QueuingService.Queue
{
    /**
    * Class provides functionalities to manage a set of CIP queues
    */
    abstract class QueuesManager : IDisposable
    {
        internal class ServiceQueue
        {
            internal CIPQueues QueueType { get; set; }
            internal string QueueGuid { get; set; }
            internal ISetting ConnectionString { get; set; }
            internal ServiceQueue(CIPQueues queueType, string queueGuid, ISetting connectionString)
            {
                this.QueueType = queueType;
                this.QueueGuid = queueGuid;
                this.ConnectionString = connectionString;
            }
        }

        private bool Disposed { get; set; }


        protected ICIPConfiguration ConnectionStrings;


        protected IDictionary<CIPQueues, ServiceQueue> ServiceQueues { get; set; }


        protected bool QueueCreated { get; set; }
        /**
         * Service Name, it is unique within CIP
         */
        public string ServiceName { get; set; }

        public QueuesManager()
        {
            this.ServiceQueues = new Dictionary<CIPQueues, ServiceQueue>();
        }
        public QueuesManager(ICIPConfiguration connectionStrings)
        {
            this.ServiceQueues = new Dictionary<CIPQueues, ServiceQueue>();
            this.ConnectionStrings = connectionStrings;
        }

        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }
        public abstract ICIPQueue GetQueueByType(CIPQueues queueType);
        protected abstract void CreateQueue();
        protected abstract void Disconnect();

        protected ISetting GetQueueServiceConfiguration(CIPQueues queueType)
        {
            ISetting queueConfig = null;
            try
            {
                ServiceQueue queueService = this.ServiceQueues[queueType];
                if (queueService != null)
                {
                    queueConfig = queueService.ConnectionString;
                }
            }
            catch (Exception sysEx)
            {
                throw new DiCIPException(String.Format("CIP Inbound Queueing Service error. Cannot get configuration for queue service {0}", queueType.ToString()), sysEx);
            }
            return queueConfig;
        }

        protected void AddQueueService(CIPQueues queueType, string guid, ISetting queueSetting)
        {
            try
            {
                if (!this.ServiceQueues.ContainsKey(queueType))
                {
                    this.ServiceQueues.Add(queueType, new ServiceQueue(queueType, guid, queueSetting));
                }
            }
            catch (Exception sysEx)
            {
                throw new DiCIPException(String.Format("CIP Inbound Queueing Service error. Cannot add queue service {0}", queueType.ToString()), sysEx);
            }
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.Disposed)
            {
                if (disposing)
                {
                    if (ServiceQueues != null)
                    {
                        ServiceQueues.Clear();
                    }
                }
                this.Disposed = true;
            }
        }
    }
}
