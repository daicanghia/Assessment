﻿using DiCIP.Common.Configuration;
using DiCIP.Services.QueuingService.Queue.ServiceBus;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiCIP.Services.QueuingService.Queue.DiUniversalAdapter
{
    class DiUniversalAdapterQueueServiceConfiguration : MSMQQueueServiceConfiguration, IMSMQQueueServiceConfiguration
    {
        public DiUniversalAdapterQueueServiceConfiguration()
            : base()

        {
            base.QueueList.Add(CIPQueues.Error);
        }

        public ICIPConfiguration GetDefautConfiguration(string serverSB, CIPServices service)
        {
            return this.CreateDefautConfiguration(serverSB, service);
        }

        #region Private Methods---------------------------------------------------------


        #endregion Private Methods------------------------------------------------------

    }
}
