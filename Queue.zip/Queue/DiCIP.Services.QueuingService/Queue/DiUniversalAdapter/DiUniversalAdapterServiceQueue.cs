﻿using DiCIP.Common.AppException;
using DiCIP.Common.Configuration;
using DiCIP.Common.Models.Message;
using DiCIP.Services.QueingService.Helper;
using DiCIP.Services.QueuingService.Queue.ServiceBus;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Messaging;

namespace DiCIP.Services.QueuingService.Queue.DiUniversalAdapter
{
    /**
     * DiUniversalAdapterServiceQueue  class provide functionalities to acces MSMQ queues
     */

    class DiUniversalAdapterServiceQueue : MSMQNontransactionalQueueService
    {
        private bool Disposed { get; set; }

        public DiUniversalAdapterServiceQueue(ISetting connectionString)
            : base(connectionString, CIPServices.DiUniversalAdapter)
        {
            this.Disposed = false;
        }

        protected override void Dispose(bool disposing)
        {
            if (!this.Disposed)
            {

                if (disposing)
                {

                }
                this.Disposed = true;
                base.Dispose(disposing);
            }
        }

        #region Private Methods---------------------------------------------------------

        #endregion Private Methods------------------------------------------------------

    }
}
