﻿using System;
using System.IO;
using System.Collections.Generic;
using DiCIP.Common.AppException;
using DiCIP.Common.Configuration;
using DiCIP.Services.QueingService.Helper;
using DiCIP.Services.QueuingService.Queue.ServiceBus;

namespace DiCIP.Services.QueuingService.Queue.DiUniversalAdapter
{
    class DiUniversalAdapterQueuesManager : MSMQQueuesManager
    {
        private bool Disposed { get; set; }

        /**
         * Default constructor used for default settings
         */
        public DiUniversalAdapterQueuesManager(string msmqServer, ICIPConfiguration connectionStrings)
            : base(msmqServer, connectionStrings, CIPServices.DiUniversalAdapter)

        {
            this.Disposed = false;

        }

        public override ICIPQueue GetQueueByType(CIPQueues queueType)
        {
            DiUniversalAdapterServiceQueue theQueue = null;
            QueueManagerHelper theHelper = new QueueManagerHelper();
            ISetting queueSetting = this.GetQueueServiceConfiguration(queueType);
            if (queueSetting != null)
            {
                theQueue = new DiUniversalAdapterServiceQueue(queueSetting);
            }
            else
            {
                throw new DiCIPException(String.Format("DiUniversal Adapter Queuing Service error. Queue {0} does not exist!", queueType.ToString()), null);
            }
            return theQueue;
        }

        protected override void CreateQueue()
        {
            try
            {
                
                List<ISetting> connectionStrings = this.ConnectionStrings.GetConfiguration();
                int count = connectionStrings.Count;
                

                ICIPQueue servicesQueue = null;
                DiCIPException serviceExceptions = null;

                for (int i = 0; i < count; i++)
                {
                    try
                    {
                        //GetSetting setting for each queue
                        ISetting connectionString = connectionStrings[i];
                        //Connect to the queue
                        servicesQueue = new DiUniversalAdapterServiceQueue(connectionString);

                        //Add the queue to supported queues
                        this.AddQueueService(servicesQueue.GetQueueServiceType(), servicesQueue.GetQueueServiceId(), connectionString);

                    }
                    catch (DiCIPException appEx)
                    {
                        if (serviceExceptions == null)
                        {
                            serviceExceptions = new DiCIPException("DiUniversal Adapter queueing Service errors!");
                        }
                        serviceExceptions.AddInnerError(appEx);
                    }
                    catch (Exception sysEx)
                    {
                        if (serviceExceptions == null)
                        {
                            serviceExceptions = new DiCIPException("DiUniversal Adapter Queueing Service errors!");
                        }
                        serviceExceptions.AddInnerError(new DiCIPException("Error occures while initializing DiUnite queuing Service!", sysEx));
                    }

                }
                if (serviceExceptions != null)
                {
                    throw serviceExceptions;
                }
                else
                {
                    this.QueueCreated = true;

                }
            }
            catch (Exception ex)
            {
                //
                throw new DiCIPException("DiUniversal Adapter Queueing Service error. Cannot create queues", ex);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (!this.Disposed)
            {

                if (disposing)
                {


                }
                this.Disposed = true;
                base.Dispose(disposing);
            }
        }

        #region Private Methods---------------------------------------------------------


        #endregion Private Methods------------------------------------------------------
    }
}
