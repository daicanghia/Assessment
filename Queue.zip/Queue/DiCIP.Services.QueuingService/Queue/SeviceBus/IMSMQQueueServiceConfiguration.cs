﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DiCIP.Common.Configuration;

namespace DiCIP.Services.QueuingService.Queue.ServiceBus
{
    public interface IMSMQQueueServiceConfiguration
    {
        ICIPConfiguration GetDefautConfiguration(string serverMSMQ, CIPServices service);
    }
}
