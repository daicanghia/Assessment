﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DiCIP.Common.Configuration;
using DiCIP.Common.AppException;

namespace DiCIP.Services.QueuingService.Queue.ServiceBus
{
    /**
      * SBQueuesManager provides functionalities to manage SB queues
      */
    class MSMQQueuesManager : QueuesManager, IQueueManager, IDisposable
    {

        private bool Disposed { get; set; }

        protected bool Connected { get; set; }

        //IDictionary <CIPMessageype, ISetting>
        protected IDictionary<string, ISetting> QueueConfiguration { get; set; }

        protected string MSMQServer { get; set; }

        /**
         * Default constructor used when using default settings
         */

        public MSMQQueuesManager()
        {
            this.Disposed = false;
            this.Connected = false;
        }

        public MSMQQueuesManager(string MSMQServer, ICIPConfiguration connectionStrings, CIPServices service)
             : base(connectionStrings)

        {
            this.Disposed = false;
            this.MSMQServer = MSMQServer;
            this.Connected = false;
            this.ServiceName = service.ToString();
            this.QueueConfiguration = new Dictionary<string, ISetting>();
        }

        public string GetServiceName()
        {
            return base.ServiceName;
        }

        public override ICIPQueue GetQueueByType(CIPQueues queueType)
        {
            return null;
        }

        public virtual string GetQueueServer()
        {
            return MSMQServer;
        }
        public virtual void Stop()
        {
            if (this.Connected)
            {
                this.Disconnect();
            }
        }
        public virtual void Start()
        {
            if (!this.Connected)
            {
                this.CreateQueue();
            }
        }
        /**
         * Create queues. drived classe must implement this method
         */
        protected override void CreateQueue()
        {

        }
        protected override void Disconnect()
        {
            try
            {
                if (QueueConfiguration != null)
                {
                    this.QueueConfiguration.Clear();
                }
                this.Connected = false;
            }
            catch (Exception ex)
            {
                throw new DiCIPException("Cannot disconnect to DiUnit queueus", ex);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (!this.Disposed)
            {
                if (disposing)
                {
                    if (this.QueueConfiguration != null)
                    {
                        this.QueueConfiguration.Clear();
                        this.QueueConfiguration = null;
                    }

                }
                this.Disposed = true;
                base.Dispose(disposing);
            }
        }

        #region Private Methods---------------------------------------------------------
        private ISetting GetQueueSetting(string queueMessageType)
        {
            return this.QueueConfiguration[queueMessageType];
        }

        private void AddQueueSetting(string queueMessageType, ISetting queueSetting)
        {
            if (!this.QueueConfiguration.ContainsKey(queueMessageType))
            {
                this.QueueConfiguration.Add(queueMessageType, queueSetting);
            }
        }

        #endregion Private Methods------------------------------------------------------
    }
}
