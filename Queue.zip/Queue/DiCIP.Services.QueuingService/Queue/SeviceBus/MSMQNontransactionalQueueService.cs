﻿using System;
using System.Collections.Generic;
using DiCIP.Common.Configuration;
using DiCIP.Common.AppException;
using DiCIP.Common.Models.Message;
using System.Runtime.CompilerServices;
using DiCIP.Messaging.ServiceBus;
using System.IO;
using DiCIP.Services.QueingService.Helper;

namespace DiCIP.Services.QueuingService.Queue.ServiceBus
{
    /**
     * SBNontransactionalQueueService  class provide functionalities to acces SB queue
     */

    public class MSMQNontransactionalQueueService : BaseQueue, ICIPQueue, IDisposable
    {
        private bool Disposed { get; set; }

        protected ServiceBusQueueClient TheMessageQueue { get; set; }

        //thinh : protected bool IsRemoteQueue { get; set; }
        protected CIPQueues QueueType { get; set; }

        //ServiceName formated as <CIPService>.<CIPMessageType>. For example "DiUnite.Outbound"
        protected string ServiceName { get; set; }

        protected bool RecoverableMessage { get; set; }

        //thinh : protected IMessageFormatter MessageFormater { get; set; }

        public MSMQNontransactionalQueueService(ISetting connectionString, CIPServices cipService)
            : base(connectionString)
        {
            this.Disposed = false;
            try
            {
                CIPQueues messageType;
                Enum.TryParse(connectionString.GetKey(), out messageType);
                this.QueueType = messageType;

                //Default to recoverable message
                this.RecoverableMessage = true;
                this.TheMessageQueue = null;

                QueueManagerHelper theHelper = new QueueManagerHelper();
                this.ServiceName = theHelper.GenerateQueueName(cipService.ToString(), this.QueueType.ToString());

                this.Connect();

            }
            catch (Exception sysEx)
            {
                throw new DiCIPException("Error occurs when initialize MSMQ queue!", sysEx);
            }
        }

        public string GetQueueServiceId()
        {
            return this.QueueID;
        }
        public CIPQueues GetQueueServiceType()
        {
            return this.QueueType;
        }
        public string GetQueueServiceName()
        {
            return this.ServiceName;
        }

        /**
         * This is special method and drived class must implement it.
         */
        public virtual List<string> GetSubQueues()
        {
            NotImplementedException ex = new NotImplementedException("GetSubqueues has not been implemented");
            throw new DiCIPException("CIP Queuing Service Error", ex);

        }

        public virtual string Send(ICIPMessage message)
        {
            Connect();
            return this.TheMessageQueue.SendMessage(message);
        }

        public virtual void Send(List<ICIPMessage> messages)
        {
            Connect();
            this.TheMessageQueue.SendMessages(messages);
        }

        /**
         * This is special method and drived class must implement it.
         */
        [MethodImpl(MethodImplOptions.Synchronized)]
        public virtual string Send(ICIPMessage message, string subQueue)
        {
            string errorMessage = string.Format("An error occurred when sending message to queue {0}", this.ServiceName + "_sub_" + subQueue);
            try
            {
                Connect(subQueue);
                this.TheMessageQueue.SendMessage(message);
                return message.GetMessageID();
            }
            catch (Exception sysEx)
            {
                throw new DiCIPException(QueueErrorCode.QueueError, errorMessage, sysEx);
            }
        }
        public virtual ICIPMessage Peak()
        {
            ICIPMessage theMessage = null;
            QueueErrorCode queueErrorCode = QueueErrorCode.NoError;
            try
            {
                Connect();
                //Check if there is message in queue
                theMessage = this.TheMessageQueue.PeekMessage(); // there is no timespan in service bus <> msmq
                if (theMessage == null)
                {
                    throw new QueueEmptyException();
                }
            }
            catch (QueueEmptyException queueEx)
            {
                string errorMessage = "";
                //There is no message in given queue
                errorMessage = string.Format("Queue {0} is empty", this.ServiceName);
                queueErrorCode = QueueErrorCode.EmptyQueue;
                throw new DiCIPException(queueErrorCode, errorMessage, queueEx);
            }
            catch (Exception sysEx)
            {
                queueErrorCode = QueueErrorCode.QueueError;
                string errorMessage = string.Format("An error occurred when peaking message from queue {0}", this.ServiceName);
                throw new DiCIPException(queueErrorCode, errorMessage, sysEx);
            }
            return theMessage;
        }

        public virtual ICIPMessage Receive()
        {
            ICIPMessage theMessage = null;
            QueueErrorCode queueErrorCode = QueueErrorCode.NoError;
            try
            {
                Connect();
                //Check if there is message in queue
                //theMessage  = this.TheMessageQueue.PeekMessage();
                //if (theMessage == null)
                //{
                //    throw new QueueEmptyException();
                //}
                theMessage = this.TheMessageQueue.ReceiveMessage(new TimeSpan(0, 0, 5));// (int)DefaultQueueSettings.ReceiveTimeout));
            }
            catch (QueueEmptyException queueEx)
            {
                string errorMessage = "";
                //There is no message in given queue
                errorMessage = string.Format("Queue {0} is empty", this.ServiceName);
                queueErrorCode = QueueErrorCode.EmptyQueue;
                throw new DiCIPException(queueErrorCode, errorMessage, queueEx);
            }
            catch (TimeoutException queueEx)
            {
                string errorMessage = "";
                //There is no message in given queue
                errorMessage = string.Format("Queue {0} is empty", this.ServiceName);
                queueErrorCode = QueueErrorCode.EmptyQueue;
                throw new DiCIPException(queueErrorCode, errorMessage, queueEx);
            }
            catch (Exception sysEx)
            {
                queueErrorCode = QueueErrorCode.QueueError;
                string errorMessage = string.Format("An error occurred when receiving message from queue {0}", this.ServiceName);
                throw new DiCIPException(queueErrorCode, errorMessage, sysEx);
            }
            return theMessage;
        }

        /**
         * This is special method and drived class must implement it.
         */
        public virtual ICIPMessage Receive(string subQueue)
        {
            NotImplementedException ex = new NotImplementedException("Receive message from subqueue has not been implemented");
            throw new DiCIPException("CIP Queuing Service Error", ex);
        }
        public virtual ICIPMessage RetrieveResult(CIPQueues messageType, string requestGuid)
        {
            return Retrieve(messageType, requestGuid);
        }
        public virtual ICIPMessage RetrieveResultByRequestId(CIPQueues messageType, string requestId)
        {
            return this.RetrieveByRequest(messageType, requestId);
        }
        public virtual ICIPMessage RetrieveResultByMessageId(CIPQueues messageType, string messageId)
        {
            return RetrieveByMessage(messageType, messageId);
        }
        protected override void Dispose(bool disposing)
        {
            if (!this.Disposed)
            {

                if (disposing)
                {
                    if (this.TheMessageQueue != null)
                    {
                        try
                        {
                            //Close and free resources
                            this.TheMessageQueue.Dispose();

                        }
                        catch (Exception sysEx)
                        {
                            string errorMessage = String.Format("Cannot close the queue {0} !", this.ConnectionString.GetValue());
                            throw new DiCIPException(errorMessage, sysEx);
                        }
                    }
                }
                this.Disposed = true;
                base.Dispose(disposing);
            }
        }
        protected virtual ICIPMessage Retrieve(CIPQueues messageType, string requestGuid)
        {
            //try
            //{
            //    Connect();
            //    TimeSpan timeout = new TimeSpan(0, 0, 1);

            //    IDictionary<string, string> messages = new Dictionary<string, string>();
            //    //MessageEnumerator queueIterator = this.TheMessageQueue.GetMessageEnumerator2();

            //    //while (queueIterator.MoveNext(timeout))
            //    //{
            //    //    queueMessage = queueIterator.Current;
            //    //    messages.Add(queueMessage.Label, queueMessage.Id);
            //    //}

            //    Message[] allMessages = this.TheMessageQueue.GetAllMessages();
            //    // Parallel.ForEach(allMessages, (message, loopState) =>
            //    //{
            //    //    //messages.Add(message.Label, message.Id);
            //    //    if (message.Label.Equals(requestGuid)){
            //    //        loopState.Stop();
            //    //    }

            //    //});


            //    //string messageId = "";
            //    //if (messages.TryGetValue(requestGuid, out messageId))
            //    //{
            //    //    queueMessage = this.TheMessageQueue.ReceiveById(messageId);
            //    //    theMessage = (ICIPMessage)queueMessage.Body;
            //    //}
            //}
            //catch (MessageQueueException queueEx)
            //{
            //    string errorMessage = "";
            //    if (queueEx.MessageQueueErrorCode == MessageQueueErrorCode.IOTimeout)
            //    {
            //        errorMessage = string.Format("Queue {0} is empty", this.ServiceName);
            //        queueErrorCode = QueueErrorCode.EmptyQueue;
            //        throw new DiCIPException(queueErrorCode, errorMessage, queueEx);
            //    }
            //    else
            //    {
            //        //Let give it one more try,
            //        return null;
            //    }


            //}
            //catch (Exception)
            //{
            //    //Let give it one more try,
            //    return null;
            //}

            return null;

        }
        protected virtual ICIPMessage RetrieveByRequest(CIPQueues messageType, string requestGuid)
        {
            ICIPMessage theMessage = null;
            QueueErrorCode queueErrorCode = QueueErrorCode.NoError;
            /* thinh :
            try
            {
                Connect();

                //this.TheMessageQueue.Peek(new TimeSpan((int)DefaultQueueSettings.PeakTimeout));

                var messageQuery = (from Message message in this.TheMessageQueue
                                    where message.Label.Equals(requestGuid)
                                    select message).ToList();

                if (messageQuery.Count > 0)
                {
                    Message messageReceived = messageQuery[0];
                    //Remove the message from queue
                    theMessage = (ICIPMessage)this.TheMessageQueue.ReceiveById(messageReceived.Id).Body;
                }
                else
                {
                    //No message found
                }
                return theMessage;

            }
            catch (MessageQueueException queueEx)
            {
                string errorMessage = "";
                if (queueEx.MessageQueueErrorCode == MessageQueueErrorCode.IOTimeout)
                {
                    errorMessage = string.Format("Queue {0} is empty", this.ServiceName);
                    queueErrorCode = QueueStatusCode.EmptyQueue;
                    throw new DiCIPException(queueErrorCode, errorMessage, queueEx);
                }
                else
                {
                    //Let give it one more try,
                    return null;
                }
            }
            catch (Exception)
            {
                //Let give it one more try,
                return null;
            } */
            return null;
        }

        protected virtual ICIPMessage RetrieveByMessage(CIPQueues messageType, string messageId)
        {
            ICIPMessage theMessage = null;
            QueueErrorCode queueErrorCode = QueueErrorCode.NoError;
            /* thinh :
            try
            {
                Connect();
                this.TheMessageQueue.Peek(new TimeSpan((int)DefaultQueueSettings.PeakTimeout));
                Message messagereceived = this.TheMessageQueue.ReceiveById(messageId);
                messagereceived.Formatter = this.MessageFormater;

                if (messagereceived != null)
                {
                    theMessage = (ICIPMessage)messagereceived.Body;
                }


            }
            catch (MessageQueueException queueEx)
            {
                string errorMessage = "";
                if (queueEx.MessageQueueErrorCode == MessageQueueErrorCode.IOTimeout)
                {
                    errorMessage = string.Format("Queue {0} is empty", this.ServiceName);
                    queueErrorCode = QueueStatusCode.EmptyQueue;
                }
                else if (queueEx.MessageQueueErrorCode == MessageQueueErrorCode.MessageNotFound)
                {
                    errorMessage = string.Format("Message {0} not found", messageId);
                    queueErrorCode = QueueStatusCode.MessageNotFound;
                }
                else
                {
                    errorMessage = string.Format("An error occurred when retrieving message from queue {0}", this.ServiceName);
                    queueErrorCode = QueueStatusCode.QueueError;
                }

                throw new DiCIPException(queueErrorCode, errorMessage, queueEx);
            }
            catch (Exception sysEx)
            {
                string errorMessage = string.Format("An error occurred when retrieving message from queue {0}", this.ServiceName);
                throw new DiCIPException(errorMessage, sysEx);
            }
            return theMessage; */
            return null;
        }
        /**
         * Check and create queue if it does not exist
         */
        protected virtual void Create()
        {
            string queueName = "";
            string connString = "";
            try
            {
                ServiceBusManager sbManager = new ServiceBusManager();
                connString = this.ConnectionString.GetValue();
                queueName = Path.GetFileName(connString);
                sbManager.CreateQueue(queueName);
            }
            catch (Exception ex)
            {
                throw new DiCIPException(String.Format("Cannot create queue {0} ", queueName), ex);
            }
        }

        /**
         * Conenect to queue
         */
        protected virtual void Connect(string subQueue)
        {
            // Subqueue => queuename_sub_subqueuename
            string queueName = "";
            string connString = "";
            try
            {
                //Get connection string for the queue
                connString = this.ConnectionString.GetValue();
                // Remove ./private$/ to get queuename --> cannot get from this.ServiceName (look at ColaborationQueuingHelper)
                queueName = Path.GetFileName(connString) + "_sub_" + subQueue;
                //Now we create queue for service bus
                ServiceBusManager sbManager = new ServiceBusManager();
                TheMessageQueue = sbManager.CreateQueue(queueName);
            }
            catch (DiCIPException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw new DiCIPException(String.Format("Cannot connect to queue {0}", queueName), ex);
            }
        }
        protected virtual void Connect()
        {
            string connString = "";
            string queueName = "";
            try
            {
                //Get connection string for the queue
                connString = this.ConnectionString.GetValue();
                // Remove ./private$/ to get queuename --> cannot get from this.ServiceName (look at ColaborationQueuingHelper)
                queueName = Path.GetFileName(connString);
                //Now we create queue for service bus
                ServiceBusManager sbManager = new ServiceBusManager();
                TheMessageQueue = sbManager.CreateQueue(queueName);
            }
            catch (DiCIPException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw new DiCIPException(String.Format("Cannot connect to queue {0}", queueName), ex);
            }

        }
        #region Private Methods---------------------------------------------------------

        #endregion Private Methods------------------------------------------------------
        internal class QueueEmptyException : Exception
        {
        } 
    }
}
