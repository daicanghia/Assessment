﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DiCIP.Common.Configuration;
using DiCIP.Services.QueingService.Helper;
using DiCIP.Common.AppException;

namespace DiCIP.Services.QueuingService.Queue.ServiceBus
{
    class MSMQQueueServiceConfiguration
    {
        protected List<CIPQueues> QueueList { get; set; }
        public MSMQQueueServiceConfiguration()
        {
            //Support CIPQueues.Inboundqueue and CIPQueues.Collaborativequeue by default
            this.QueueList = new List<CIPQueues>();
            this.QueueList.Add(CIPQueues.Inbound);
            //this.QueueList.Add(CIPQueues.Collaborativequeue); // moved to CIPInboundQueueServiceConfiguration
        }
        /**
         * Get default settings of queue service. Use this class to simplyapplication configuration and settings
         * Each service has 4 queues by default. Overide this class to customize default configuration 
         */
        protected virtual ICIPConfiguration CreateDefautConfiguration(string serverMSMQ, CIPServices service)
        {
            ICIPConfiguration defautConfig = null;
            try
            {
                string queueName = "";
                // thinh : string queuePath = "";

                List<ISetting> settings = new List<ISetting>();
                foreach (CIPQueues queue in this.QueueList)
                {
                    QueueManagerHelper helper = new QueueManagerHelper();
                    //Only need InboundQueue
                    CIPQueues messageType = queue;
                    queueName = helper.GenerateQueueName(service.ToString(), messageType.ToString());
                    // thinh : queuePath = helper.GenerateQueuePath(serverMSMQ, queueName);
                    //thinh : ISetting setting = new Setting(new KeyValuePair<string, string>(messageType.ToString(), queuePath));
                    ISetting setting = new Setting(new KeyValuePair<string, string>(messageType.ToString(), queueName)); // thinh added
                    settings.Add(setting);
                }
                defautConfig = new CIPConfiguration(settings);

            }
            catch (Exception ex)
            {
                throw new DiCIPException(string.Format("Cannot create default config for service {0}. CIP Queuing Service cannot started!", service.ToString()), ex);
            }
            return defautConfig;

        }
        #region Private Methods---------------------------------------------------------


        #endregion Private Methods------------------------------------------------------

    }
}
