﻿using DiCIP.Common.Configuration;

namespace DiCIP.Services.QueuingService.Queue
{
    public interface IQueueManager
    {

        string GetServiceName();
        ICIPQueue GetQueueByType(CIPQueues queueType);
        string GetQueueServer();

        void Stop();
        void Start();

    }
}
