﻿using System.Collections.Generic;
using DiCIP.Common.Configuration;
using DiCIP.Common.Models.Message;

namespace DiCIP.Services.QueuingService.Queue
{
    /**
     * TODO: rename file name to IQueue
     */
    public interface ICIPQueue
    {
        string GetQueueServiceId();

        CIPQueues GetQueueServiceType();

        string GetQueueServiceName();

        List<string> GetSubQueues();


        string Send(ICIPMessage message);
        void Send(List<ICIPMessage> message);
        string Send(ICIPMessage message, string subQueue);

        ICIPMessage Peak();

        ICIPMessage Receive();
        ICIPMessage Receive(string subQueue);

        ICIPMessage RetrieveResult(CIPQueues messageType, string requestGuid);

        ICIPMessage RetrieveResultByRequestId(CIPQueues messageType, string RequestId);

        ICIPMessage RetrieveResultByMessageId(CIPQueues messageType, string messageId);

    }
}
