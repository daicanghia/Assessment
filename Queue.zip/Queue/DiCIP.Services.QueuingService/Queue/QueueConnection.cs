﻿using System.Messaging;

namespace DiCIP.Services.QueuingService.Queue
{
    class QueueConnection
    {
        public bool Availalble { get; set; }
        public QueueConnection(bool available)
        {
            this.Availalble = available;
        }
    }

    class MSMQConnection : QueueConnection
    {
        public MessageQueue TheConenction { get; set; }
        public MSMQConnection(MessageQueue theConnection, bool available)
            : base(available)
        {
            this.TheConenction = theConnection;
        }
    }

}
