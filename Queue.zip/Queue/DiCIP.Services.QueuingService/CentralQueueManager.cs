﻿using DiCIP.Common.AppException;
using DiCIP.Common.Configuration;
using DiCIP.Services.QueingService.Helper;
using DiCIP.Services.QueuingService.Queue;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace DiCIP.Services.QueuingService
{
    /**
     * CentralQueueManager provide functionalities to manage CentralQueue. It is singleton class
     */
    class CentralQueueManager : IDisposable
    {

        private static CentralQueueManager TheCentralQueueManager = null;
        private bool Disposed { get; set; }

        private bool IsInitialized { get; set; }
        private IDictionary<string, IQueueManager> ServiceManagers { get; set; }

        private CentralQueueManager()
        {
            this.Disposed = false;
            this.IsInitialized = false;
            this.ServiceManagers = new Dictionary<string, IQueueManager>();
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public static CentralQueueManager InitCentralQueueManager()
        {
            if (TheCentralQueueManager == null)
            {
                TheCentralQueueManager = new CentralQueueManager();
            }
            return TheCentralQueueManager;
        }


        [MethodImpl(MethodImplOptions.Synchronized)]
        public static void UninitCentralQueueManager()
        {
            if (TheCentralQueueManager != null)
            {
                TheCentralQueueManager.Dispose();
                TheCentralQueueManager = null;
            }
        }

        public static CentralQueueManager GetCentralQueueManager()
        {
            if (TheCentralQueueManager == null)
            {
                InitCentralQueueManager();
                //throw new DiCIPException("CIP Queuing Service Error: Central Queue Manager has not been initialized!. Must call CentralQueueManager.InitCentralQueueManager() to innitialize the service first");
            }
            return TheCentralQueueManager;
        }
        ~CentralQueueManager()
        {
            this.Dispose(true);
        }
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        /**
         * Get queuing service specified by service name. For example "DiUnite"
         */
        public IQueueManager GetQueuingService(CIPServices service)
        {
            IQueueManager theService = null;
            try
            {
                if (this.ServiceManagers.ContainsKey(service.ToString()))
                {
                    theService = this.ServiceManagers[service.ToString()];
                }
                else
                {
                    //Innitialize CIP Queuing Service.
                    List<CIPServices> service2Start = new List<CIPServices>();
                    service2Start.Add(service);
                    this.StartQueuingService("", service2Start);
                    theService = this.ServiceManagers[service.ToString()];
                }
            }
            catch (Exception ex)
            {
                throw new DiCIPException(string.Format("CIP Queuing Services Error: Queuing Service for {0} Service not found!", service.ToString()), ex);

            }
            return theService;
        }

        /**
         * Start Queuing Service for given services using default configuration
         */
        [MethodImpl(MethodImplOptions.Synchronized)]
        public void StartQueuingService(string queueServerAddress, List<CIPServices> services2Start)
        {
            DiCIPException cipServicesExceptions = null;
            if (services2Start == null || services2Start.Count <= 0)
            {
                throw new DiCIPException("CIP Queuing Service errors. Cannot start CIP Queuing Service. No Service given!");
            }

            foreach (CIPServices service in services2Start)
            {
                try
                {
                    this.Start(queueServerAddress, service);

                }
                catch (DiCIPException appEx)
                {
                    if (cipServicesExceptions == null)
                    {
                        cipServicesExceptions = new DiCIPException("CIP Queuing Service errors!");
                    }
                    cipServicesExceptions.AddInnerError(appEx);
                }
                catch (Exception sysEx)
                {
                    if (cipServicesExceptions == null)
                    {
                        cipServicesExceptions = new DiCIPException("CIP Queuing Service errors");
                    }
                    cipServicesExceptions.AddInnerError(new DiCIPException(string.Format("Cannot start Queuing Service for {0} Service!", service.ToString()), sysEx));
                }
            }

            if (cipServicesExceptions != null)
            {
                throw cipServicesExceptions;
            }
            else
            {
                this.IsInitialized = true;
            }
        }
        /**
          * Start Queuing Service for given services based on given configuration
          */

        [MethodImpl(MethodImplOptions.Synchronized)]
        public void StartQueuingService(List<KeyValuePair<string, ICIPConfiguration>> services2Start)
        {
            DiCIPException cipServicesExceptions = null;
            CIPServices service = CIPServices.Unknown;

            foreach (KeyValuePair<string, ICIPConfiguration> serviceConfig in services2Start)
            {

                Enum.TryParse(serviceConfig.Key, out service);

                try
                {
                    this.Start(service, serviceConfig.Value);
                }
                catch (DiCIPException appEx)
                {
                    if (cipServicesExceptions == null)
                    {
                        cipServicesExceptions = new DiCIPException("CIP Queuing Service errors!");
                    }
                    cipServicesExceptions.AddInnerError(appEx);

                }
                catch (Exception sysEx)
                {
                    if (cipServicesExceptions == null)
                    {
                        cipServicesExceptions = new DiCIPException("CIP Queuing Service errors");
                    }
                    cipServicesExceptions.AddInnerError(new DiCIPException(string.Format("Cannot start Queuing Service for {0} Service!", service.ToString()), sysEx));
                }
            }

            if (cipServicesExceptions != null)
            {
                throw cipServicesExceptions;
            }
        }


        /**
         * Stop Queuing Service for a given service
         */
        [MethodImpl(MethodImplOptions.Synchronized)]
        public void StopQueuingService(List<CIPServices> services2Stop)
        {
            foreach (CIPServices service in services2Stop)
            {
                try
                {
                    this.Stop(service);
                }
                catch (DiCIPException)
                {
                    throw;
                }
                catch (Exception sysEx)
                {
                    string errorMessage = string.Format("CIP Queuing Service errors: Cannot stop Queuing Service for {0} Service!", service.ToString());
                    throw new DiCIPException(errorMessage, sysEx);
                }
            }

        }
        #region Private Methods---------------------------------------------------------
        /**
          * Start Queuing Service using given configuration
          */

        private void Start(CIPServices service, ICIPConfiguration config)
        {
            IQueueManager queueManager = null;
            try
            {
                ServiceManagerHelper myHelper = new ServiceManagerHelper();
                queueManager = myHelper.InitializeQueueManager(service, config);
                this.ServiceManagers.Add(queueManager.GetServiceName(), queueManager);

            }
            catch (DiCIPException)
            {
                throw;

            }
            catch (ArgumentException duplicatedKeyEx)
            {
                string sMsg = String.Format("CIP Queuing Service errors: Service {0} already exists", service.ToString());
                throw new DiCIPException(sMsg, duplicatedKeyEx);
            }
            catch (Exception sysEx)
            {
                string sMsg = String.Format("CIP Queuing Service errors: Cannot start Queuing Service for {0} Service", service.ToString());
                throw new DiCIPException(sMsg, sysEx);
            }

        }

        /**
         * Start Queuing Service using default configuration
         */
        private void Start(string queueServerAddress, CIPServices service)
        {
            IQueueManager queueManager = null;
            try
            {
                ServiceManagerHelper myHelper = new ServiceManagerHelper();
                queueManager = myHelper.InitializeQueueManager(queueServerAddress, service);
                if (!this.ServiceManagers.ContainsKey(queueManager.GetServiceName()))
                {
                    this.ServiceManagers.Add(queueManager.GetServiceName(), queueManager);
                }

            }
            catch (DiCIPException)
            {
                throw;

            }
            catch (ArgumentException duplicatedKeyEx)
            {
                string sMsg = String.Format("CIP Queuing Service errors: Service {0} already exists", service.ToString());
                throw new DiCIPException(sMsg, duplicatedKeyEx);
            }
            catch (Exception sysEx)
            {
                string sMsg = String.Format("CIP Queuing Service errors: Cannot start Queuing Service for {0} Service", service.ToString());
                throw new DiCIPException(sMsg, sysEx);
            }

        }
        private void Stop(CIPServices service)
        {
            try
            {
                ServiceManagerHelper myHelper = new ServiceManagerHelper();
                myHelper.StopQueueManager(service);

            }
            catch (DiCIPException)
            {
                throw;

            }
            catch (Exception sysEx)
            {
                string sMsg = String.Format("CIP Queuing Service errors: Cannot stop manager for {0} Service", service.ToString());
                throw new DiCIPException(sMsg, sysEx);
            }

        }

        #endregion Private Methods------------------------------------------------------

        protected virtual void Dispose(bool disposing)
        {
            if (!this.Disposed)
            {
                if (disposing)
                {
                    ServiceManagers.Clear();
                }
                this.Disposed = true;
            }
        }
    }
}
